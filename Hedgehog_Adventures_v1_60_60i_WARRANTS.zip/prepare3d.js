// Install pinned Three.js in an isolated npm workspace.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=__dirname,vendor=path.join(root,'vendor'),target=path.join(vendor,'three.module.js');
const valid=p=>{try{
 const stat=fs.statSync(p);if(!stat.isFile()||stat.size<500000||stat.size>10000000)return false;
 const source=fs.readFileSync(p,'utf8');if(!/const REVISION = '160';/.test(source)||!source.includes('WebGLRenderer')||!source.includes('Scene'))return false;
 // Parse as ESM without executing downloaded code. Size/version alone accepts truncated modules.
 const checked=spawnSync(process.execPath,['--input-type=module','--check'],{input:source,encoding:'utf8',timeout:15000});
 return !checked.error&&checked.status===0;
 }catch{return false;}};
const candidates=()=>[path.join(root,'node_modules','three'),path.join(root,'.dc-runtime','node_modules','three')];
function main(){
 if(valid(target)){console.log('Three.js r160 already installed. Offline start is available.');return;}
 let src=candidates().find(p=>valid(path.join(p,'build','three.module.js'))&&fs.existsSync(path.join(p,'LICENSE')))||candidates()[0];
 if(!valid(path.join(src,'build','three.module.js'))||!fs.existsSync(path.join(src,'LICENSE'))){
  const tmp=path.join(root,'.dc-runtime');fs.mkdirSync(tmp,{recursive:true});
  // Always repair the dedicated manifest, including leftovers from old launchers.
  fs.writeFileSync(path.join(tmp,'package.json'),JSON.stringify({name:'dc-runtime',version:'1.0.0',private:true,dependencies:{three:'0.160.0'}},null,2)+'\n');
  src=path.join(tmp,'node_modules','three');
  if(!valid(path.join(src,'build','three.module.js'))||!fs.existsSync(path.join(src,'LICENSE'))){
   const args=['install','--ignore-scripts','--no-audit','--no-fund','--fetch-retries=0','--fetch-timeout=30000'];
   // cwd is passed to the OS; no user directory is interpolated into a shell command.
   const r=spawnSync(process.platform==='win32'?'npm.cmd':'npm',args,{cwd:tmp,stdio:'inherit',shell:process.platform==='win32',timeout:120000});
   if(r.error||r.status!==0)throw new Error('npm failed: '+(r.error?.message||'exit '+r.status)+'. See npm output above, or copy vendor from a working version.');
  }
 }
 if(!valid(path.join(src,'build','three.module.js')))throw new Error('Invalid Three.js r160 module.');
 // Verify and read the licence before replacing the installed module.
 const license=fs.readFileSync(path.join(src,'LICENSE'));
 fs.mkdirSync(vendor,{recursive:true});fs.writeFileSync(path.join(vendor,'THREE-LICENSE.txt'),license);const staged=target+'.tmp-'+process.pid;try{fs.copyFileSync(path.join(src,'build','three.module.js'),staged);if(!valid(staged))throw new Error('Invalid staged Three.js module');fs.renameSync(staged,target);}finally{if(fs.existsSync(staged))fs.unlinkSync(staged);}
 console.log('Three.js r160 ready. Subsequent offline starts use vendor/three.module.js.');
}
if(require.main===module)try{main();}catch(e){console.error('Setup failed: '+e.message);process.exitCode=1;}

module.exports={valid,candidates};
