// Local-only static server: exposes only the game and pinned Three.js module.
const http=require('node:http'), fs=require('node:fs'), path=require('node:path');
const routes={'/':['index.html','text/html; charset=utf-8'],'/index.html':['index.html','text/html; charset=utf-8'],'/vendor/three.module.js':['vendor/three.module.js','text/javascript; charset=utf-8'],'/node_modules/three/build/three.module.js':['node_modules/three/build/three.module.js','text/javascript; charset=utf-8']};
const publicBuild=process.argv.includes('--public');
const port=process.env.SOLO_PORT===undefined?8000:Number(process.env.SOLO_PORT);
if(!Number.isInteger(port)||port<1||port>65535){console.error('SOLO_PORT must be an integer 1–65535.');process.exit(1);}
const server=http.createServer((req,res)=>{if(!["127.0.0.1:"+port,"localhost:"+port].includes(req.headers.host?.toLowerCase()) && !(port===80&&['127.0.0.1','localhost'].includes(req.headers.host?.toLowerCase()))){res.writeHead(421,{'Connection':'close'});return res.end('Invalid Host');}let url;try{url=new URL(req.url,'http://localhost');}catch{res.writeHead(400);return res.end('Bad request');}const route=Object.hasOwn(routes,url.pathname)?routes[url.pathname]:null;if(!['GET','HEAD'].includes(req.method)||!route){res.writeHead(404);return res.end('Not found');}const [file,type]=route;fs.readFile(path.join(__dirname,file),(err,data)=>{if(err){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});return res.end('Файл не найден. Выполните node prepare3d.js в папке игры.');}if(publicBuild&&file==='index.html'){const marker='const PUBLIC1658E=false; // PUBLIC_BUILD_SWITCH1658E';const html=data.toString('utf8');if(!html.includes(marker)){res.writeHead(500);return res.end('Public build marker missing');}data=Buffer.from(html.replace(marker,'const PUBLIC1658E=true; // PUBLIC_BUILD_SWITCH1658E'));}res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:data);});});
server.headersTimeout=10000;
server.requestTimeout=15000;
server.keepAliveTimeout=3000;
server.setTimeout(15000,socket=>socket.destroy());
server.maxHeadersCount=64;
let retries=0;
const busy=()=>{console.error('Port '+port+' is busy. Close the previous game server; changing the port changes the browser save location.');process.exitCode=1;};
server.on('error',err=>{
 if(err.code!=='EADDRINUSE'){console.error('Local server failed: '+err.message);process.exitCode=1;return;}
 if(retries>=4){busy();return;}
 // FIN_WAIT/CLOSE_WAIT do not imply a listening server. Probe only after a failed real bind.
 const probe=require('node:net').createConnection({host:'127.0.0.1',port});
 let settled=false;const finish=active=>{if(settled)return;settled=true;probe.destroy();if(active){busy();return;}retries++;setTimeout(()=>server.listen(port,'127.0.0.1'),350*retries);};
 probe.once('connect',()=>finish(true));probe.once('error',e=>finish(e.code!=='ECONNREFUSED'));probe.setTimeout(500,()=>finish(true));
});
server.listen(port,'127.0.0.1',()=>{const address='http://127.0.0.1:'+port+'/index.html';console.log('Ежиные похождения v1.60.60a: '+address+' (одиночная игра)');if(process.platform==='win32'&&process.argv.includes('--open')){const child=require('node:child_process').spawn('rundll32.exe',['url.dll,FileProtocolHandler',address],{detached:true,stdio:'ignore',windowsHide:true});child.on('error',err=>console.error('Cannot open browser automatically: '+err.message+'. Open '+address+' manually.'));child.unref();}});
