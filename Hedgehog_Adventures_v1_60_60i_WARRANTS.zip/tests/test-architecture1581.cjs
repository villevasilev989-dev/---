process.chdir(require("node:path").resolve(__dirname,".."));
// Isolated generation test: actual parcel, entrance, paths and service code; geometry engine mocked.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const slice=(a,b)=>h.slice(h.indexOf(a),h.indexOf(b,h.indexOf(a)+a.length));
const house=slice('  // v1.14: persistent estate','  function buildingInterior('), coll=slice('  function addCollider(','  function clearZone('), village=slice('  function buildingInterior(','  /* ---- проработанный город'),city=slice('  function buildCityComplex(','  function buildMiniCity('),path=slice('  function residentClear(','  function residentDoorOccupied(');
let mock=fs.readFileSync(__dirname+'/test-walkin.cjs','utf8').split('const mock=`')[1].split('`;')[0];
mock+=`
V.prototype.clone=function(){return new V(this.x,this.y,this.z)};V.prototype.setScalar=function(s){return this.set(s,s,s)};
for(const k of ['SphereGeometry','ConeGeometry','OctahedronGeometry','MeshLambertMaterial','MeshBasicMaterial','MeshToonMaterial'])THREE[k]=G;
THREE.TorusGeometry=G;THREE.PointLight=N; const fake=()=>new N(), buildMarket=fake,buildForge=fake,buildTavern=fake,buildTemple=fake,buildBank=fake,buildGuild=fake,buildTownHouse=fake,buildElfHouse=fake,buildFarmhouse=fake,buildMountainHut=fake,buildFishHut=fake,buildHut=fake,buildRoundTree=fake,buildFountain=fake,buildLamp=fake,buildPerson=fake,makeLabel=fake;
const HOUSE_BY_BIOME={},BLD={villageKinds:{},make:fake,makeProp:fake,pickKind:()=> 'town',PROP_POOLS:{town:['bench']}};
const PERSONALITIES=[{}], BS=2, CITY_MECH={}, scene=new N(),cityZones=[],clearZone2=()=>{},batchCityStatic=()=>{},lakeNear=()=>false,deepWater=()=>false, footOf=()=>[0,0,.4,.4],DIVINE_LOCAL={}, professionRole=()=> 'Фермер';
const factionForCity=c=>originalOwners[c]||'Нейтралы';let menu=null;const openMenu=(title,build)=>{menu={title,build}},log=()=>{};
`;
// The mock already defines footOf after coll extraction, use the production version + geometry mock.
mock=mock.replace(', footOf=()=>[0,0,.4,.4]','');mock+=`G.prototype.attributes={position:{count:0}};THREE.Box3=class{setFromObject(){this.min={x:-.4,z:-.4};this.max={x:.4,z:.4};return this}};`;
const biome=h.match(/^const BIOMES = .*$/m)[0]+h.match(/^  const CHUNK = .*$/m)[0]+slice('  function hashBiome(','  function noise(');
vm.runInNewContext(mock+biome+slice('  const CITY_FACTION=','  const realm=')+coll+house+path+village+city+`
function reset(){doors.length=0;settlementBoards158.length=0;farmPlots1583.length=0;colGrid.clear();scene.clear();for(const k of Object.keys(estateRecords))delete estateRecords[k];}
let vcount=0,ccount=0;
for(const b of ['равнины','леса','горы','пустыня','снега','болота','вулканы'])for(let i=0;i<8;i++){
 reset();const name='Деревня '+b+' '+i,g=buildVillage(b,1000,2000,name);const roles=g.userData.npcs.map(n=>n.name);for(const r of ['Торговец','Кузнец','Трактирщик','Жрец','Банкир','Глава гильдии'])assert(roles.includes(r),name+' '+r);assert.equal(doors.length,roles.length);assert.equal(farmPlots1583.length,1);assert.equal(farmPlots1583[0].city,name);assert.equal(settlementBoards158.length,1);for(const d of doors)assert(Number.isFinite(d.x+d.z+d.top)&&d.displayName&&d.W>0);const id=doors.map(estateId).join('|');reset();buildVillage(b,1000,2000,name);assert.equal(doors.map(estateId).join('|'),id);vcount++;
}
for(const name of Object.keys(originalOwners)){
 reset();const out=buildCityComplex(name,0x987654,1000,2000,name==='Тенеград'?12:9); for(const k of ['guard','arsenal','supply','officers','watch','stable'])assert(doors.some(d=>d.kind===k),name+' missing '+k);assert(out.group.userData.drill1581,name+' missing drill yard');assert.equal(farmPlots1583.length,1);const lib=doors.find(d=>d.kind==='library');assert(lib&&lib.inter.filter(q=>q.n.startsWith('Стеллаж')).length===4&&lib.inter.some(q=>q.n.includes('архив')));for(const k of ['shop','craft','inn','temple','bank','guild'])assert(doors.some(d=>d.kind===k),name+' '+k);assert(out.npcs.length>=20);assert.equal(settlementBoards158.length,1);assert(doors.length>=12);const board=settlementBoards158[0];playerMesh.position.set(board.x,0,board.z);settlementBoardAction158(playerMesh.position).f();const rows=menu.build();assert(rows.some(q=>q.t.startsWith('Банк ·')));rows.find(q=>q.t.startsWith('Банк ·')).f();assert(settlementTarget158.name.startsWith('Банк ·'));ccount++;
}
console.log('Settlement generator: '+vcount+' villages / '+ccount+' cities; six civilian services, six military buildings and drill yard in each mock city, deterministic village IDs, finite doors and local directory verified (geometry mock, no WebGL).');
`,{assert,console});
const roofCode=slice('  function roofProfile1581(','  const MILITARY_NAMES1581=');
const testRoofMock=`class Geometry{constructor(){this.attrs={}}setAttribute(k,v){this.attrs[k]=v}setIndex(v){this.idx=v}computeVertexNormals(){}} class Attr{constructor(array,size){this.array=array;this.itemSize=size}}class Mesh{constructor(g,m){this.geometry=g;this.material=m;this.position={set(){}};this.rotation={}}}const THREE={BufferGeometry:Geometry,Float32BufferAttribute:Attr,Mesh,BoxGeometry:Geometry};const parent={children:[],add(q){this.children.push(q)}};`;
vm.runInNewContext(testRoofMock+roofCode+`
const geo=eastRoof1581(parent,6,5,3,1.7,{},{}).geometry,p=geo.attrs.position.array,idx=geo.idx;assert.equal(p.length/3,4*8*13);assert.equal(idx.length,4*7*12*6);assert(p.every(Number.isFinite));assert(idx.every(i=>i>=0&&i<p.length/3));assert(roofProfile1581(0,1,1.7)>roofProfile1581(0,0,1.7));for(let n=0;n<idx.length;n+=3){const [a,b,c]=idx.slice(n,n+3).map(i=>p.slice(i*3,i*3+3));const normalY=(b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2]);assert(normalY>0,'roof face winding must point upward');}for(let side=0;side<4;side++)for(let j=0;j<8;j++){const a=(side*104+j*13+12)*3,b=(((side+1)%4)*104+j*13)*3;assert(Math.hypot(p[a]-p[b],p[a+1]-p[b+1],p[a+2]-p[b+2])<1e-8,'joined corners');}console.log('Curved roof: 416 vertices, 672 triangles, finite coords, joined corners, upward face normals.');`,{assert,console});
