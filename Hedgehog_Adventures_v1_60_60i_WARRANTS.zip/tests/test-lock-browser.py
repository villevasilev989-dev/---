"""Isolated real Chromium DOM test of production menu and rune puzzle; no WebGL."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
root=Path(__file__).resolve().parent.parent
h=(root/'index.html').read_text()
def part(a,b): return h[h.index(a):h.index(b)]
css=h.split('<style>',1)[1].split('</style>',1)[0]
source=part('  /* UNDER152-BEGIN','  /* UNDER152-END')+part('  function underPickMenu152','  function underContactRows152')+part('  /* SHADOW150-BEGIN','  /* SHADOW150-END')+part('  /* CRIME148-BEGIN','  /* CRIME148-END')+part('  function openMenu(title','  function closeAllPanels()')
stub="""const player={alive:true,gold:30,stamina:100},realm={day:3},d={seed:452,city:'A'},record={owner:'resident',locked:true,open:false};let menuState=null,inDungeon=false,saves=0;const NetworkTransport={isOpen:()=>false},estateId=()=> 'home',estateFor=()=>record,estateNearby=()=>d,underWitness152=()=>0,estateRestore=()=>{},log=()=>{},updateHud=()=>{},save15=()=>saves++,civicFine=()=>10,seedCity=n=>[...n].reduce((a,c)=>(Math.imul(a,31)+c.charCodeAt(0))>>>0,7);"""
content='<html><style>'+css+'</style><body><div id="npcMenu" class="panel hidden"></div><script>'+stub+source+'; underPickMenu152(d);</script></body></html>'
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1000,'height':740}); errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(content)
    page.get_by_text('Рунический замок',exact=True).wait_for()
    if os.getenv('LOCK_SCREENSHOT'):page.screenshot(path=os.environ['LOCK_SCREENSHOT'])
    steps=page.evaluate('underPuzzle152(d.seed,realm.day)').copy()
    for i in range(3):
        for j in range((steps['goal'][i]-steps['n'][i])%4):page.get_by_role('button',name='Повернуть',exact=True).nth(i).click()
    assert page.get_by_text('Печать совпала.',exact=True).is_visible()
    page.get_by_role('button',name='Проверить печать').click()
    assert page.evaluate('!record.locked && player.stamina===82 && shadow150(player).xp===1 && saves===1')
    page.evaluate('record.locked=true; underPickMenu152(d)');assert page.get_by_role('button',name='Проверить печать').is_disabled()
    page.evaluate('realm.day++; underPickMenu152(d)');page.get_by_role('button',name='Проверить печать').click()
    assert page.evaluate('record.locked && player.stamina===64 && shadow150(player).xp===2 && crimeRecord148(player,"A").fine===10')
    assert not errors,errors
    print('Chromium: production rune menu, disk rotation, successful unlock, daily cooldown, failed attempt and crime record; no JS errors.')
    browser.close()
