const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(h.slice(h.indexOf('  function dgEncounterPlan1656f'),h.indexOf('  function buildDungeonFloor'))+`
const rooms=[{id:1,kind:'combat',tx:3,tz:4},{id:2,kind:'combat',tx:5,tz:6}],site={catalog1653:1};
for(const [r,k] of [[0,'prisoner'],[.1,'merchant'],[.2,'wanderer']])assert.equal(dgEncounterPlan1656f(rooms,site,r).kind,k);
assert.equal(dgEncounterPlan1656f(rooms,site,.24),null);assert.equal(dgEncounterPlan1656f(rooms,{catalog1653:64},0),null);assert.equal(dgEncounterPlan1656f(rooms,site,0,1).room,2);
let dg={encounter1656f:{kind:'merchant',room:1,stock:2,model:{position:{}}}},player={alive:true,gold:50,hp:50,maxHp:100,inventory:[]},enemies=[],online=false;const NetworkTransport={isOpen:()=>online},near=()=>true,log=()=>{},updateHud=()=>{};let ids=0;const netUid=()=>++ids;
const buy=dgEncounterAction1656f(near);enemies.push({isDungeon:true,hp:10,roomId:1});buy.f();assert.equal(player.gold,50);enemies.length=0;buy.f();buy.f();buy.f();assert.equal(player.gold,0);assert.equal(player.inventory.length,2);assert(dg.encounter1656f.used);
dg.encounter1656f={kind:'prisoner',room:1,bars:[{}],model:{position:{}}};const rescue=dgEncounterAction1656f(near);rescue.f();rescue.f();assert.equal(player.hp,65);assert.equal(dg.encounter1656f.bars[0].visible,false);
dg={encounter1656f:{kind:'merchant',room:1,stock:2,model:{position:{}}}};player.gold=50;const old=dgEncounterAction1656f(near);dg={};old.f();assert.equal(player.gold,50);
dg={encounter1656f:{kind:'wanderer',room:1,x:0,z:0}};const playerMesh={position:{}},dgLocal=()=>[0,0],dgLineWorld=()=>true,dgPos=()=>({});const dgExtraSpawn1656e=()=>{enemies.push({maxHp:100,atk:10,scale:1,mesh:{scale:{setScalar(){}}}});return true;};dgEncounterTick1656f();dgEncounterTick1656f();assert.equal(enemies.length,1);assert.equal(enemies[0].hp,250);assert.equal(enemies[0].atk,14);assert.equal(enemies[0].scale,1.25);
console.log('Encounter distribution, exclusions, combat gate, limited stock, rescue and stale callback OK');`,{assert,console});
