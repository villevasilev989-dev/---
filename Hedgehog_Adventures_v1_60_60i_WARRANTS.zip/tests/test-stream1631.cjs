const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>{const i=h.indexOf(a),j=h.indexOf(b,i+a.length);assert(i>=0&&j>i);return h.slice(i,j)};
vm.runInNewContext(`
const CHUNK=40,RADIUS=3,chunks=new Map();let builds=0,writes=0;
const document={getElementById(){return {set textContent(v){writes++}}}};
function ensureNearbyCities(){} function makeChunk(x,z){assert(!chunks.has(x+','+z));builds++;chunks.set(x+','+z,{biome:'лес'})} function dropChunk(k){chunks.delete(k)}
${part('  function updateChunks(','  /* ---- MODEL BUILDERS')}
updateChunks(0,0,true);assert.equal(builds,11);assert.equal(chunks.size,11);
for(let x=-1;x<=1;x++)for(let z=-1;z<=1;z++)assert(chunks.has(x+','+z));
for(let i=0;i<19;i++){const n=builds;updateChunks(0,0,true);assert(builds-n<=2)}assert.equal(chunks.size,49);assert.equal(writes,1);
updateChunks(40,0,true);assert.equal(updateChunks.pending1631.length,5);updateChunks(8000,-8000,true);assert(chunks.has('200,-200'));assert(!chunks.has('0,0'));assert.equal(chunks.size,11);updateChunks(8000,-8000);assert.equal(chunks.size,49);assert.equal(updateChunks.pending1631.length,0);
chunks.delete('200,-200');updateChunks.dirty1630=true;updateChunks(8000,-8000,true);assert(chunks.has('200,-200'));console.log('Streaming: immediate 3x3, two outer chunks per frame, stationary drain, teleport cancellation, sync completion, invalidation.');
${part('  function nearestCombatTarget1631(','  function populationTick(')}
const pos={},make=(d,b=false,extra={})=>({hp:10,isBoss:b,mesh:{position:{distanceTo:()=>d}},...extra});
let seed=42;const rng=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
for(let i=0;i<500;i++){const list=Array.from({length:100},()=>make(Math.floor(rng()*25),rng()<.2,{war:rng()<.1,hp:rng()<.1?0:10,isDungeon:rng()<.3}));const dungeon=i%2===0,house=i%17===0;const expected=list.filter(e=>!e.war&&e.hp>0&&!!e.isDungeon===dungeon&&!house&&e.mesh.position.distanceTo(pos)<(e.isBoss?20:7)).sort((a,b)=>Number(!!b.isBoss)-Number(!!a.isBoss)||a.mesh.position.distanceTo(pos)-b.mesh.position.distanceTo(pos))[0];assert.equal(nearestCombatTarget1631(list,pos,dungeon,house),expected)}console.log('Target selection: 500 randomized equivalence cases.');
`,{assert,console});
