const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>h.split(a)[1].split(b)[0];
vm.runInNewContext(part('/* RACE1627-BEGIN */','/* RACE1627-END */')+`
assert.equal(raceRelation1627('angel','demon'),-2);assert.equal(raceRelation1627('demon','angel'),-2);assert.equal(raceRelation1627('elf','dwarf'),-1);assert.equal(raceRelation1627('human','beast'),-1);assert.equal(raceStanding1627('angel','demon',0),-500);assert.equal(raceStanding1627('angel','demon',1000),500);assert.equal(raceTrade1627({resident:{race:'demon'}},false),1.24);assert.equal(raceTrade1627({resident:{race:'demon'}},true),.84);assert.equal(raceTrade1627({resident:{race:'angel'}},false),.88);`,{assert,player:{race:'angel'},NetworkTransport:{isOpen:()=>false}});
vm.runInNewContext(part('/* MOB1621-BEGIN */','/* MOB1621-END */')+`
for(const floor of [100,300,1000,10000]){const p=mobProfile1621({name:'Волк',shape:'quadruped'},'равнины',true,false,{level:20},floor,()=>.5);assert(p.level>floor);assert(Number.isFinite(p.hpFactor));}`,{assert});
console.log('RACE1627: symmetric relations, reputation, prices, levels beyond 100.');
