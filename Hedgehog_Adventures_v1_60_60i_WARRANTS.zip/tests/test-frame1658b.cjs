const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');const ctx={};vm.createContext(ctx);vm.runInContext(h.slice(h.indexOf('/* PERF1658B-BEGIN */'),h.indexOf('/* PERF1658B-END */')),ctx);
let seed=58;const random=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
for(let k=0;k<200;k++){
 const p={x:random()*100,z:random()*100};const nodes=Array.from({length:250},(_,i)=>({x:p.x+(random()-.5)*10,z:p.z+(random()-.5)*10,mesh:{visible:i%4!==0,parent:i%7?{position:{x:random()*300,z:random()*300}}:null,position:{x:random()*30,z:random()*30}}}));
 const old=nodes.filter(n=>n.mesh.visible&&Math.hypot(n.x-p.x,n.z-p.z)<2.6).sort((a,b)=>Math.hypot(a.x-p.x,a.z-p.z)-Math.hypot(b.x-p.x,b.z-p.z))[0]||null;
 assert.equal(ctx.nearestResource1658b(nodes.values(),p),old);
 const active=nodes.filter(n=>{const a=n.mesh.parent;return a&&Math.hypot(a.position.x+n.mesh.position.x-p.x,a.position.z+n.mesh.position.z-p.z)<88;});assert.deepEqual(Array.from(ctx.nearNPCs1658b(nodes.slice(0,200),nodes.slice(200),p)),active);
}
const p={x:0,z:0},a={x:1,z:0,mesh:{visible:true}},b={x:-1,z:0,mesh:{visible:true}};assert.equal(ctx.nearestResource1658b([a,b],p),a);assert.equal(ctx.nearestResource1658b([],p),null);assert.equal(ctx.nearestResource1658b([{x:2.6,z:0,mesh:{visible:true}}],p),null);
console.log('200 randomized equivalence cases, stable ties, empty and boundary checks passed');
