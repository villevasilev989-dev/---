process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const code=h.slice(h.indexOf('  function residentSegment('),h.indexOf('  function residentPath('))+h.slice(h.indexOf('  function residentSlot('),h.indexOf('  let residentPathBudget=0;'));
vm.runInNewContext(code+`
const clear=(x,z)=>Math.abs(x)<9&&Math.abs(z)<9&&!(x>1&&x<2&&z>-2&&z<2);
const used=[];for(let i=0;i<48;i++){const p=residentSlot({x:0,z:0},used,clear,7);assert(p);assert(clear(p.x,p.z));assert(used.every(q=>Math.hypot(q.x-p.x,q.z-p.z)>=.78));used.push(p);}
const onlyInside=p=>Math.abs(p.x)<1.6&&Math.abs(p.z)<1.6;const room=[];for(let i=0;i<100;i++){const p=residentSlot({x:0,z:0},room,clear,4,onlyInside);if(!p)break;assert(onlyInside(p));room.push(p);}assert(room.length>1&&room.length<25);
assert.equal(residentSlot({x:0,z:0},[],()=>false),null);
let a={x:0,z:0},b={x:0,z:0};for(let i=0;i<40;i++)a=residentSeparate(a,b,clear,1/60);assert(Math.hypot(a.x-b.x,a.z-b.z)>=.75);
a={x:.05,z:0};b={x:.2,z:0};const wall=(x,z)=>x>=0;for(let i=0;i<40;i++)a=residentSeparate(a,b,wall,1/60);assert(a.x>=0);assert(Math.hypot(a.x-b.x,a.z-b.z)>.15);
`,{assert});
assert(h.includes('homeUse.get(a)'));assert(h.includes('residentSlot(base,used,residentClear'));assert(h.includes('residentSeparate(pos,b,residentClear'));assert(h.includes('residentTurn++'));
console.log('NPC crowd: 48 distinct destinations, room capacity, coincident actors, wall-safe displacement, fair path scheduling wiring OK (logic only).');
