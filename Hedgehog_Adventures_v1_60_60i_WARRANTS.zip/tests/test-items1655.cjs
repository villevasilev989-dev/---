const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const code=h.slice(h.indexOf('/* ITEMS1655-BEGIN */'),h.indexOf('/* ITEMS1655-END */'));
vm.runInNewContext(`const RARITIES=Array.from({length:6},(_,i)=>({n:String(i)}));const rarityIndexByName=n=>Number(n);const GEAR_NAMES={helmet:'Шлем',shield:'Щит',ring:'Кольцо',amulet:'Амулет'};`+code+`
assert.equal(FORMS1655.sword.length,60);assert.equal(MATERIALS1655.length,25);assert.equal(ENCHANT1655.length,15);
assert.equal(Object.values(FORMS1655).slice(0,1).length,1);
let offset=0;for(const [name,p,type,def] of JOKES1655){const j=joke1655(()=>offset+p/2);assert.equal(j.name,name);assert.equal(j.def,def);offset+=p;}assert.equal(joke1655(()=>.99),null);
assert.equal(lootChance1655(false,true,true),0);assert.equal(lootChance1655(true,false,false),.15);assert.equal(lootChance1655(true,false,true),.25);assert.equal(lootChance1655(false,false,true),0);assert.equal(bossRarity1655(.9999).n,'5');assert.equal(bootSpeed1655({bootR:{joke:true},bootL:{joke:true}}),.7*.8*.9);
const ids=new Set();for(let i=0;i<10000;i++){const x=components1655({id:String(i),type:'weapon',rarity:'5',atk:1,def:1},100);assert(!ids.has(x.id));ids.add(x.id);assert(x.material&&x.form&&x.enchantment);assert(!x.form.includes('🦔'));assert(Number.isFinite(x.mass));}
console.log('10000 component records, 6 joke intervals, boss-only equipment, rarity and boots: PASS');`,{assert,console});
assert(!h.includes('!target.isBoss && Math.random()<0.3'));assert(h.includes('item=chestLoot1655(dungeonFloor)'));assert(h.includes('it=chestLoot1655()'));

assert(h.includes('if(Math.random()<(target.mimic1656b===6?.15:lootChance1655(target.isBoss,target.elite,target.guardian))'));
