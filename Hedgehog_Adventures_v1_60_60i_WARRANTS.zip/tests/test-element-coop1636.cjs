const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/server.js','utf8'),h=fs.readFileSync(root+'/index.html','utf8');
const cut=(s,a,b)=>s.slice(s.indexOf(a),s.indexOf(b,s.indexOf(a)+a.length));
const ctx={};vm.createContext(ctx);vm.runInContext(cut(s,'function elementalDamage1636(','function attack(')+cut(h,'const MOB_ELEMENTS1622=','function mobPhase1622('),ctx);
for(const affinity of ['fire','frost','storm','shadow','venom',null,'constructor'])for(const tags of [[],['fire'],['ice'],['storm'],['shadow'],['death'],['curses'],['poison'],['fire','ice'],[null,{}],null])for(const dmg of [1,10,100,999])assert.equal(ctx.elementalDamage1636({affinity},dmg,tags),ctx.mobDamage1622({affinity1622:affinity},dmg,tags));
assert(h.includes("tags:Array.isArray(tags)?tags.filter"));assert(s.includes('damage = Math.min(cap, elementalDamage1636(e, damage, p.tags));'));
console.log('COOP1636: 308 elemental parity cases and packet wiring');

const hits=[];
const sandbox={hits,assert};vm.createContext(sandbox);
vm.runInContext(`const LIMITS={adminHit:25000},maxHit=()=>100,take=()=>true,num=(v,d)=>Number.isFinite(v)?v:d,refill=()=>{},broadcast=(r,k,p)=>hits.push(p),markKilled=()=>{};`+cut(s,'function elementalDamage1636(','function handle(')+`
const e={id:'m',hp:1000,maxHp:1000,x:0,y:0,z:0,affinity:'fire'},r={worldReady:true,worldAt:Date.now(),entities:new Map([['m',e]])},p={stateAt:Date.now(),state:{hp:100,zone:'w',x:0,y:0,z:0},dmgBucket:{t:1000},nick:'test'};
attack(r,p,{targetId:'m',damage:80,tags:['fire']});assert.equal(e.hp,940);assert.equal(p.dmgBucket.t,940);
attack(r,p,{targetId:'m',damage:80,tags:['ice']});assert.equal(e.hp,844);assert.equal(p.dmgBucket.t,844);
attack(r,p,{targetId:'m',damage:100,tags:['ice']});assert.equal(e.hp,744);assert.equal(p.dmgBucket.t,744);
p.dmgBucket.t=5;attack(r,p,{targetId:'m',damage:80,tags:['ice']});assert.equal(e.hp,739);assert.equal(p.dmgBucket.t,0);
assert.equal(hits.length,4);assert.equal(hits[3].damage,5);
`,sandbox);
console.log('COOP1636: actual attack handler respects final cap, budget and HP');
