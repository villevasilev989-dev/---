process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8'),server=fs.readFileSync(__dirname+'/../server.js','utf8');
const block=(s,a,b)=>{const i=s.indexOf(a),j=s.indexOf(b,i+a.length);assert(i>=0&&j>i);return s.slice(i,j)};
vm.runInNewContext(block(html,'// SAVE-VALIDATION1615-BEGIN','// SAVE-VALIDATION1615-END')+`
const good={v:1,data:{hp:30,inventory:[{id:'i1'}]},sky:['hub'],equip:{},quests:[{id:'q1',stages:[{}]}],realm:{day:1,owners:{A:'B'},relations:{},stock:{A:{ore:30,food:20,cloth:10}},caravans:[]}};
assert.equal(validateSave1615(good),good);
for(const invalid of [{pos:[1]},{quests:[null]},{quests:[{id:'q'}]},{data:{inventory:[null]}},{data:{body:{parts:{}}}},{data:{attributes:null}},{data:{customSpells:[{}]}},{realm:{...good.realm,markets:{A:null}}},{realm:{...good.realm,stock:{A:{ore:-5,food:0,cloth:0}}}},{herbHarvest:{}}])assert.throws(()=>validateSave1615({...good,...invalid}));
assert.throws(()=>validateSave1615(JSON.parse(JSON.stringify(good).replace('"hp":30','"__proto__":{"bad":true}'))));
let stored={main:'{bad',main_backup:JSON.stringify(good)};const storage={getItem:k=>stored[k]??null};assert.equal(readSave1615(storage,'main').data.hp,30);delete stored.main;assert.equal(readSave1615(storage,'main').data.hp,30);stored.main='{bad';stored.main_backup='null';assert.throws(()=>readSave1615(storage,'main'));delete stored.main;delete stored.main_backup;assert.equal(readSave1615(storage,'main'),null);
`,{assert});
vm.runInNewContext(`const clean=(s,n)=>(typeof s==='string'?s:'').slice(0,n),num=(v,d=0)=>Number.isFinite(v)?v:d;`+block(server,'function netMobProfile1635(','function leave(')+`
const a={id:'e1',name:'x',x:1,y:0,z:2,hp:10,maxHp:10,atk:2};const room={entities:new Map(),killed:new Map()};assert.equal(sanitizeEntities([a,a,{...a,id:'e2',hp:-1},{...a,id:'e3',x:null}]).length,1);assert(mergeWorld(room,[a],100));room.entities.get('e1').hp=4;assert(mergeWorld(room,[{...a,atk:999,maxHp:999,hp:999}],110));assert.equal(room.entities.get('e1').hp,4);assert.equal(room.entities.get('e1').maxHp,10);assert.equal(room.entities.get('e1').atk,2);room.entities.delete('e1');markKilled(room,'e1',120);assert(mergeWorld(room,[a],130));assert(!room.entities.has('e1'));assert(mergeWorld(room,[{...a,id:'e2'}],140));assert(room.entities.has('e2'));assert(!mergeWorld(room,[null],150));assert(room.entities.has('e2'));
`,{assert});
assert(html.includes('saveBlocked1615=true'));assert(html.includes('BLD.unregister(root)'));assert(html.includes('disposeChunkGroup1630(c?.group)'));assert(html.includes('pruneHerbs1615();'));
console.log('FIX1615: malformed save preflight, backup fallback, bad entity rejection, HP reconciliation, tombstones, save and chunk guards OK (VM/static, not live browser/network)');
