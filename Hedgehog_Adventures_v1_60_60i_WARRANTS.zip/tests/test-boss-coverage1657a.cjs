const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const catalog=JSON.parse(h.match(/const DG_CATALOG1653=(\[.*?\]);/)[1]);
const names=[...new Set(catalog.filter((r,i)=>i!==62&&i!==64).map(r=>r[4]))];
vm.runInNewContext(h.split('/* MOB1621-BEGIN */')[1].split('/* MOB1621-END */')[0]+`
assert.equal(names.length,62);assert.equal(Object.keys(BOSS_SIGNATURE1657).length,62);
assert.equal(new Set(Object.values(BOSS_SIGNATURE1657).map(v=>v[1])).size,62);
for(const name of names){assert(Object.hasOwn(BOSS_SIGNATURE1657,name),name);const [key,label,mul,adds]=BOSS_SIGNATURE1657[name];assert(Object.hasOwn(MOB_SKILLS1621,key));assert(mul>=1&&mul<=1.35);assert(Number.isInteger(adds)&&adds>=0&&adds<=3);
for(const prefix of ['', 'Аспект: ']){const e={name:prefix+name,isBoss:true,isDungeon:true,catalogBoss1657:true,skills1621:[],specialCd1621:0};bossInit1657(e);assert.equal(mobSelect1621(e,0,()=>0),key);assert.equal(bossLabel1657(e,key),label);assert.equal(bossPower1657(e,key),mul);}}
console.log('62 names, 62 distinct labels, 124 normal/aspect profiles; empty skill pool recovery OK');`,{assert,console,names});
