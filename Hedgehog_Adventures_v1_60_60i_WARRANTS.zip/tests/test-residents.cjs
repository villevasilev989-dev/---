process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
const code=html.slice(html.indexOf('  /* v1.13: resident identities'),html.indexOf('  let residentPathBudget=0;'));
vm.runInNewContext(code+`
assert.equal(residentPhase(120,0),'sleep');assert.equal(residentPhase(390,0),'meal');assert.equal(residentPhase(600,0),'work');assert.equal(residentPhase(750,0),'meal');assert.equal(residentPhase(1150,0),'leisure');assert.equal(residentPhase(1300,0,true),'rest');
const r={hunger:30,fatigue:30};residentNeeds(r,60,'work');assert(r.hunger>30&&r.fatigue>30);residentNeeds(r,60,'meal');assert.equal(r.hunger,0);residentNeeds(r,600,'sleep');assert.equal(r.fatigue,0);residentNeeds(r,1e6,'travel');assert.equal(r.hunger,100);assert.equal(r.fatigue,100);
// Two rooms separated by a wall with one doorway; also require an external detour.
const clear=(x,z)=>Math.abs(x)<30&&Math.abs(z)<30&&!(Math.abs(x)<.55&&Math.abs(z-4)>1.05&&Math.abs(z)<12);
for(let i=0;i<24;i++) {const a={x:-6,z:-4+i*.5},b={x:7,z:2};const route=residentPath(a,b,clear,3000);assert(route.length,'no path '+i);let p=a;for(const q of route){assert(residentSegment(p,q,clear),'colliding path');p=q;}assert.equal(p.x,b.x);assert.equal(p.z,b.z);}
assert.equal(residentPath({x:-1,z:0},{x:1,z:0},(x,z)=>x<-.5||x>.5,100).length,0);
`,{assert});
assert(html.includes('residents:residentRecords'));assert(html.includes('residentRecords[id]=r'));assert(html.includes('npc.resident.met++'));assert(html.includes('npc.residentId||npc.mesh.uuid'));
console.log('Residents: schedule, needs, 24 obstacle routes, impossible route and save/meeting wiring OK (logic only).');
