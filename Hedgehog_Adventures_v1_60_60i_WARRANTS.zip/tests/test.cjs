process.chdir(require("node:path").resolve(__dirname,".."));
// Автономная проверка графа по настоящему коду из index.html (без Three.js).
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const {execFileSync} = require('node:child_process');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const code=html.slice(html.indexOf('  const SKY_C='), html.indexOf('  // Слой совместимости:'));
vm.runInNewContext(code+`
for (const id of Object.keys(CLASS_SKY)) {
 const ns=getSkyNodes(id), by=new Map(ns.map(n=>[n.id,n])), learned=new Set(['hub']), counts={};
 assert.equal(ns.length,10001); assert.equal(by.size,ns.length);
 let links=0;
 for(const n of ns)for(const p of n.l){assert(by.has(p),id+' missing dependency '+p);links++;}
 // Model unlock rule: every required talent, one parent, branch counts, level cap fulfilled.
 let changed=true;
 while(changed){changed=false;for(const n of ns){if(learned.has(n.id))continue;if(n.route.some(i=>learned.has(i))&&n.required.every(i=>learned.has(i))&&(!n.need||n.need.every(([b,c])=>(counts[b]||0)>=c))){learned.add(n.id);if(n.branchId&&!n.secret)counts[n.branchId]=(counts[n.branchId]||0)+1;changed=true;}}}
 assert.equal(learned.size,ns.length,id+' unreachable nodes');
 if(id==='mage'){const n=ns.find(n=>n.n==='Цепная вода');assert(n.required.some(x=>x.includes(':ice:')));assert(n.required.some(x=>x.includes(':storm:')));console.log('  Цепная вода:',n.required.map(x=>by.get(x).n).join(' + '));}
 console.log(id+': '+(ns.length-1)+' nodes, '+links+' links, '+Object.keys(ns.spells).length+' spells; all reachable');
}`,{assert,console});
execFileSync(process.execPath,['--check',path.join(__dirname,'../server.js')]);
// Gate clearance of both wall profiles (geometric check, not a 3D collision test).
for(const power of [1,.65]){let min=Infinity;for(let i=0;i<96;i++){const p=a=>[Math.sign(Math.cos(a))*Math.pow(Math.abs(Math.cos(a)),power)*48,Math.sign(Math.sin(a))*Math.pow(Math.abs(Math.sin(a)),power)*48];const [x,z]=p(i*Math.PI/48),[xx,zz]=p((i+1)*Math.PI/48);if(Math.abs((x+xx)/2)<6.8||Math.abs((z+zz)/2)<6.8)continue;min=Math.min(min,Math.abs(x),Math.abs(xx));}assert(min>4);console.log('Wall profile',power,'half-gate opening',min.toFixed(2));}
console.log('OK — graph and gate geometry checks only; not a WebGL or network test.');
// Test the actual procedural generator and collision from index.html (no WebGL dependency).
const generator=html.slice(html.indexOf('  const DUNGEON_TILE='),html.indexOf('  /* ---- Runtime dungeon ---- */'));
vm.runInNewContext(generator+`
let tested=0,loops=0,maxRooms=0;
for(let seed=1;seed<=80;seed++)for(const floor of [1,2,3,4,5,6,9,10,11,15,20,40]){
 const d=generateDungeon(seed,floor);assert(d.rooms.length>=9&&d.rooms.length<=14);maxRooms=Math.max(maxRooms,d.rooms.length);assert.equal(d.rooms[0].kind,'entry');assert.equal(d.rooms[d.exit].kind,floor%10===0?'boss':floor%5===0?'elite':'guardian');
 assert.equal(d.rooms.filter(r=>r.kind==='treasure').length,1);assert.equal(d.rooms.filter(r=>r.kind==='shrine').length,1);assert(d.rooms.some(r=>r.kind==='trap'));
 const seen=new Set(['0,0']),queue=['0,0'];for(let i=0;i<queue.length;i++){const [x,z]=queue[i].split(',').map(Number);for(const [dx,dz] of DG_DIR){const k=dgKey(x+dx,z+dz);if(d.tiles.has(k)&&!seen.has(k)){seen.add(k);queue.push(k);}}}assert.equal(seen.size,d.tiles.size,'disconnected floor');
 for(const r of d.rooms){assert(dgWalkable(d.tiles,r.tx*2,r.tz*2,.5));const path=dgPath(d.tiles,'0,0',dgKey(r.tx,r.tz));if(r.id!==0){assert(path.length>0);assert.deepEqual(path.at(-1),[r.tx,r.tz]);let x=0,z=0;for(const [xx,zz] of path){assert.equal(Math.abs(x-xx)+Math.abs(z-zz),1);assert(dgLine(d.tiles,x*2,z*2,xx*2,zz*2,.5));x=xx;z=zz;}}}
 const e=d.rooms[d.exit];assert(dgWalkable(d.tiles,e.tx*2,e.tz*2+3,.45),'unreachable gate');
 for(const k of d.tiles){const [x,z]=k.split(',').map(Number);for(const [dx,dz] of DG_DIR)if(!d.tiles.has(dgKey(x+dx,z+dz))){assert(!dgWalkable(d.tiles,(x+dx)*2,(z+dz)*2,.45));assert(!dgLine(d.tiles,x*2,z*2,(x+dx)*2,(z+dz)*2,.45));}}
 const again=generateDungeon(seed,floor);assert.equal(JSON.stringify(d.rooms),JSON.stringify(again.rooms));assert.equal(JSON.stringify([...d.tiles]),JSON.stringify([...again.tiles]));if(d.links.length>d.rooms.length-1)loops++;tested++;
}
console.log('Dungeon generator: '+tested+' layouts; '+loops+' with loops; max rooms '+maxRooms+'; connected, deterministic, walls/path/exit verified.');
`,{assert,console});
const script=html.split('<script type="module">')[1].split('</script>')[0];
const os=require('node:os'), tmp=fs.mkdtempSync(path.join(os.tmpdir(),'dungeon-check-'));
try{const f=path.join(tmp,'client.mjs');fs.writeFileSync(f,script);execFileSync(process.execPath,['--check',f]);}finally{fs.rmSync(tmp,{recursive:true,force:true});}
console.log('Client and server JS syntax: OK. Not a browser or network playtest.');
// Headless gameplay smoke test with a minimal mesh/DOM double (not real Three.js rendering).
const runtime=html.slice(html.indexOf('  const DUNGEON_TILE='),html.indexOf('  /* ---- Hedgehog statue'));
const mock=`
class Vec{constructor(x=0,y=0,z=0){this.set(x,y,z)}set(x,y,z){Object.assign(this,{x,y,z});return this;}copy(p){return this.set(p.x,p.y,p.z)}clone(){return new Vec(this.x,this.y,this.z)}distanceTo(p){return Math.hypot(this.x-p.x,this.y-p.y,this.z-p.z)}}
class Node{constructor(g,m){this.geometry=g;this.material=m;this.children=[];this.position=new Vec();this.rotation=new Vec();this.scale=new Vec(1,1,1);this.scale.setScalar=x=>this.scale.set(x,x,x);this.instanceMatrix={};}add(...ns){this.children.push(...ns)}remove(n){this.children=this.children.filter(x=>x!==n)}traverse(f){f(this);for(const n of this.children)n.traverse(f)}updateMatrix(){}setMatrixAt(){}}
class Geo{dispose(){}}class Color{constructor(c){this.c=c}setHex(c){this.c=c}multiplyScalar(){return this}}class Mat{constructor(o){Object.assign(this,o);this.color=new Color(o.color)}dispose(){}}
const THREE={Vector3:Vec,Group:Node,Mesh:Node,InstancedMesh:Node,Object3D:Node,BoxGeometry:Geo,RingGeometry:Geo,OctahedronGeometry:Geo,ConeGeometry:Geo,MeshBasicMaterial:Mat,MeshLambertMaterial:Mat,Color,PointLight:Node,DoubleSide:2};
// PointLight in the mock must not expose number arguments as disposable materials.
THREE.PointLight=class extends Node{constructor(){super()}};
const DUNGEON_ORIGIN=new Vec(3000,0,3000),DUNGEON_ROOM=28,dungeonRoomObjects=[],enemies=[],scene=new Node(),playerMesh=new Node(),player={lvl:20,gold:0,inventory:[],hp:50,maxHp:100,mp:20,maxMp:100,alive:true};
const DG_SITES=[{name:'Test',level:1,theme:0,mul:1,biomes:['test']},{name:'Other',level:5,theme:3,mul:2,biomes:['test']}];let activeSite=DG_SITES[0];const guardDamage=d=>d;
const model={biomes:['test'],name:'Test',color:1,hp:30,atk:5,shape:'humanoid',scale:1},ENEMY_TYPES=[model],BOSS_TYPES=[model],SHAPE_BUILD={humanoid:()=>new Node()},adminState={god:false},travelReset=()=>{};
let roomHalf=13,houseCtx=null,inDungeon=false,dungeonFloor=1,overworldPos=null,dungeonStairs=null,jumpY=0,jumpV=0,playerYaw=0,yawDelta=0;let events=[],uid=0;
const el={textContent:'',classList:{add(){},remove(){}},style:{}};const document={getElementById:()=>el,body:el};
const applyVariant=()=>{},netUid=()=>String(++uid),log=()=>{},questProgress=t=>events.push(t),updateMaps=()=>{},updateHud=()=>{},rollItem=()=>({name:'Loot'}),fxRing=()=>{},fxFrom=()=>new Vec(),fxBurst=()=>{},totalDef=()=>0,resolveCollide=()=>{};
`;
vm.runInNewContext(mock+html.split("/* MOB1621-BEGIN */")[1].split("/* MOB1621-END */")[0]+runtime+`
const chestLoot1655=()=>({name:'Loot'});
playerMesh.position.set(12,0,20);enterDungeon();assert(inDungeon);assert.equal(dungeonFloor,1);assert.equal(dg.visited.size,1);assert.equal(enemies.filter(x=>x.guardian).length,1);
const treasure=dg.rooms.find(r=>r.kind==='treasure');playerMesh.position.copy(treasure.prop.pos);let act=dgNearest();act.f();const gold=player.gold;act.f();assert.equal(player.gold,gold);assert.equal(player.inventory.length,1);assert.equal(dgNearest(),null);
const shrine=dg.rooms.find(r=>r.kind==='shrine');playerMesh.position.copy(shrine.prop.pos);act=dgNearest();act.f();assert.equal(player.hp,100);assert.equal(player.mp,85);act.f();assert.equal(player.mp,85);
playerMesh.position.copy(dg.gate.pos);dgNearest().f();assert.equal(dungeonFloor,1);spawnStairs();spawnStairs();assert(dg.key);dgNearest().f();assert.equal(dungeonFloor,2);assert.equal(dg.visited.size,1);assert(!dg.key);assert.equal(playerMesh.position.x,3000);assert.equal(playerMesh.position.z,3000);
dungeonFloor=10;buildDungeonFloor();assert.equal(enemies.filter(e=>e.isBoss).length,1);assert(enemies.find(e=>e.isBoss).guardian);dgTick(.05);exitDungeon();assert(!inDungeon);assert.equal(dg,null);assert.equal(enemies.length,0);assert.equal(playerMesh.position.x,12);assert.equal(playerMesh.position.z,20);assert.equal(dungeonRoomObjects.length,0);assert(events.includes('floor'));assert(events.includes('dungeonChest'));assert(events.includes('dungeonShrine'));enterDungeon(DG_SITES[1]);assert.equal(dg.theme,3);assert.equal(activeSite.name,'Other');exitDungeon();player.lvl=1;enterDungeon(DG_SITES[1]);assert(!inDungeon);console.log('Dungeon smoke test: entry, locked gate, one-time chest and shrine, floor transition, boss spawn, exit & cleanup OK.');
`,{assert,console});
const houses=html.slice(html.indexOf('  function enterHouse(d)'),html.indexOf('  function renderSkillTreeOld()'));
vm.runInNewContext(mock+html.split("/* MOB1621-BEGIN */")[1].split("/* MOB1621-END */")[0]+runtime+`
THREE.MeshToonMaterial=Mat;THREE.PlaneGeometry=Geo;THREE.CircleGeometry=Geo;
const CG=12,colGrid=new Map();
${html.slice(html.indexOf('  function addCollider('),html.indexOf('  function footOf('))}
${html.slice(html.indexOf('  function removeCampCols1614('),html.indexOf('  function campClear156('))}
const buildPerson=()=>new Node(),closeMenu=()=>{},openMenu=()=>{},openHouse=()=>{},openRoleMenu=()=>{},factionForCity=()=> 'Нейтралы',pickR=l=>l[0];
`+houses+`
for(const kind of ['home','herb','craft','shop','inn','temple','bank','guild','library','guard','mill','storage','manor','farm','fish'])for(let seed=0;seed<3;seed++){
 playerMesh.position.set(12,0,20);const d={kind,seed,name:'Test',city:'Test'};enterHouse(d);assert(inDungeon&&houseCtx);assert(houseCtx.inter.some(x=>x.n==='Выйти из дома'));assert(houseCtx.cols.length>=5);assert(dungeonRoomObjects.length>45);const before=[...houseCtx.cols];exitHouse();assert(!houseCtx&&!inDungeon);assert(before.every(c=>c.dead));assert.equal(colGrid.size,0);assert.equal(playerMesh.position.x,12);assert.equal(dungeonRoomObjects.length,0);
}console.log('House smoke test: 45 type/layout combinations; entry, furniture, exit and collision cleanup OK (mock).');`,{assert,console});
