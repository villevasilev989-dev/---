const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const cut=(a,b)=>{const x=h.indexOf(a),y=h.indexOf(b,x+1);assert(x>=0&&y>x);return h.slice(x,y)};
vm.runInNewContext(cut('  function exploration1655e','  function drawMap')+`
const player={lvl:1000000},CITY_POS={x:45,z:45},knownSites={},discoveredSettlements=[],chests=[],GAME_SETTINGS={cityAtlas:true},settlementTarget158=null,playerMesh={position:{x:45,z:45}};
const d={name:'Финал',catalog1653:60,x:1000,z:1000,level:120},pr={name:'prison',prison:true,x:2000,z:2000},r={name:'ruin',ruin:{id:'r'},x:3000,z:3000};const DG_SITES=[d,pr,r],c={id:'s:1,1',name:'Город',x:500,z:500};const getCityPlan=()=>new Map([[c.id,c]]),airRoute=()=>[{x:12,z:34,city:"Тестовая пристань"}],railRoute=()=>[{x:56,z:78,city:"Тестовая станция",kind:"rail"}],WAR_STORIES=[{id:'warPrison'}];let gate=false;const storyGate=()=>gate,log=()=>{};
assert.equal(mapMarks(true).length,0);assert.equal(mapMarks(false).length,0);
player.lvl=1;mapExplore1655e(player,{x:955,z:1000},DG_SITES,[c]);assert.equal(mapState1655e(player,'dungeon',d),2);assert(mapMarks(true).some(m=>m.x===1000));
mapLearn1655e(player,'dungeon',d,3);mapLearn1655e(player,'dungeon',d,4);assert(!mapLearn1655e(player,'dungeon',d,2));assert(mapMarks().some(m=>m.l.includes('✓')));
mapLearn1655e(player,'city',c,1);assert(mapMarks(true).some(m=>m.s==='rumor'&&m.x!==c.x));mapExplore1655e(player,{x:390,z:500},DG_SITES,[c]);assert(mapMarks().some(m=>m.x===500&&m.s==='sq'));mapExplore1655e(player,{x:500,z:500},DG_SITES,[c]);assert.equal(mapState1655e(player,'city',c),3);
mapExplore1655e(player,pr,DG_SITES,[c]);assert.equal(mapState1655e(player,'dungeon',pr),0);gate=true;mapExplore1655e(player,pr,DG_SITES,[c]);assert.equal(mapState1655e(player,'dungeon',pr),2);
mapExplore1655e(player,r,DG_SITES,[c]);assert.equal(mapState1655e(player,'dungeon',r),2);
const copy=JSON.parse(JSON.stringify(player));assert.equal(mapState1655e(copy,'dungeon',d),4);assert.equal(mapState1655e(copy,'city',c),3);assert.equal(mapState1655e({},'city',c),0);
knownSites['s:2,2']={visited:true};discoveredSettlements.push({id:'s:2,2',visited:true,type:'village',name:'Деревня',pos:{x:800,z:800}});assert(mapMarks().some(m=>m.l==='Деревня'));
GAME_SETTINGS.cityAtlas=false;assert(!mapMarks().some(m=>m.l.includes('Пристань:')));mapLearn1655e(player,'station',airRoute()[0],2);mapLearn1655e(player,'station',railRoute()[0],2);for(const full of [true,false]){assert(mapMarks(full).some(m=>m.l==='Пристань: Тестовая пристань'));assert(mapMarks(full).some(m=>m.l==='Станция: Тестовая станция'));}
console.log('Exploration: level-independent discovery, persistence, rumor, atlas, legacy villages, story gate, completion OK');`,{assert,console});
assert(h.includes("const savedFields=['exploration1655e'"));assert(h.includes('mapExploreTick1655e(); updateMaps()'));assert(h.includes("mapLearn1655e(player,'dungeon',activeSite,4)"));
vm.runInNewContext(cut('  function validateSave1615','  // Lossless UTF-16')+`
const original={v:1,data:{lvl:1},sky:['hub'],equip:{},quests:[]};assert(validateSave1615(original));const valid={...original,data:{...original.data,exploration1655e:{'dungeon:60':4,'terrain:-1,2':2}}};assert(validateSave1615(valid));for(const bad of [[],{'dungeon:60':0},{'dungeon:60':5},{'dungeon:60':'4'}])assert.throws(()=>validateSave1615({...original,data:{...original.data,exploration1655e:bad}}));console.log('New save state validated; old save supported.');`,{assert,console});
