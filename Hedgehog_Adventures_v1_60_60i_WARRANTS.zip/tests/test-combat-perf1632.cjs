const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const a=h.indexOf('// PERF1632-BEGIN'),b=h.indexOf('// PERF1632-END');assert(a>=0&&b>a);
const {petTarget1632,cachedSight1632}=vm.runInNewContext(h.slice(a,b)+'\n;({petTarget1632,cachedSight1632})');
let seed=42;const rng=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
const pos={};
for(let i=0;i<1000;i++){
 const dungeon=i%2===0,house=i%13===0,list=Array.from({length:100},()=>{const d=Math.floor(rng()*15);return {hp:rng()<.1?0:5,war:rng()<.1,isDungeon:rng()<.5,mesh:{position:{distanceTo:()=>d,visible:rng()<.6}}}});
 let old=null,td=9;for(const e of list){if(house||e.hp<=0||e.war||!!e.isDungeon!==dungeon)continue;const d=e.mesh.position.distanceTo(pos);if(d<td&&e.mesh.position.visible){old=e;td=d;}}
 const r=petTarget1632(list,pos,dungeon,house,(_,p)=>p.visible);assert.equal(r.target,old);assert.equal(r.distance,td);
}
let checks=0;const list=Array.from({length:8},(_,i)=>({hp:1,mesh:{position:{distanceTo:()=>8-i}}}));assert.equal(petTarget1632(list,pos,false,false,()=>{checks++;return true}).target,list[7]);assert.equal(checks,1);
for(const expected of [true,false]){let n=0;const sight=cachedSight1632(()=>{n++;return expected},pos,pos);assert.equal(n,0);for(let j=0;j<3;j++)assert.equal(sight(),expected);assert.equal(n,1);}
assert(h.includes('=petTarget1632(enemies,pp,inDungeon,houseCtx,dgLineWorld)'));assert(h.includes('const sight=cachedSight1632(dgLineWorld,en.mesh.position,tp)'));
console.log('1000 randomized pet-target cases, nearest-first visibility, lazy cached true/false line checks, integration markers passed.');
