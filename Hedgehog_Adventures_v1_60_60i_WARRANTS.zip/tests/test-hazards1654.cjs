const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8'),b=fs.readFileSync(__dirname+'/test.cjs','utf8');
const cut=(a,z)=>h.slice(h.indexOf(a),h.indexOf(z,h.indexOf(a)+a.length));
const mock=b.slice(b.indexOf('const mock=`')+12,b.indexOf('`;\nvm.runInNewContext(mock+'));
vm.runInNewContext(mock+cut('  function exploration1655e','  function mapGate1655e')+cut('/* MOB1621-BEGIN */','/* MOB1621-END */')+cut('  const DUNGEON_TILE=','  /* ---- Hedgehog statue')+`
const NetworkTransport={isOpen:()=>false},soundVoice1625=()=>{},bioPlayerHit=()=>{};
ENEMY_TYPES.push(...Array.from({length:12},()=>model));
for(let style=0;style<10;style++)for(const roll of [0,.499,.5,.999])assert(DG_HAZARDS1654[dgHazardKind1654(style,roll)]);
for(const kind of Object.keys(DG_HAZARDS1654)){
 const a={kind,state:'hidden'};assert.equal(dgHazardStep1654(a,.1,1,false,true),'');assert.equal(dgHazardStep1654(a,.1,1,true,false),'');assert.equal(dgHazardStep1654(a,.1,1,true,true),'arm');assert.equal(dgHazardStep1654(a,2,1,true,true),'hit');assert.equal(dgHazardStep1654(a,2,0,true,true),'');
 const c={kind,state:'hidden'};dgHazardStep1654(c,.1,1,true,true);assert.equal(dgHazardStep1654(c,2,99,true,true),'miss');
 const d={kind,state:'disabled'};assert.equal(dgHazardStep1654(d,2,0,true,true),'');
}
const site=dgMakeSites1653()[0];site.theme=0;player.lvl=100;enterDungeon(site);assert(dg.traps.length>=2);const a=dg.traps[0];assert.equal(a.ring.visible,false);playerMesh.position.copy(dgPos(a.x+1.5,a.z));const action=dgNearest();action.f();assert(a.detected);dgNearest().f();assert.equal(a.state,'disabled');playerMesh.position.copy(dgPos(a.x,a.z));dgTick(.1);assert.equal(a.state,'disabled');
const treasure=dg.rooms.find(r=>r.kind==='treasure');treasure.prop.mimic=true;treasure.prop.mimicKind=0;playerMesh.position.copy(treasure.prop.pos);const open=dgNearest(),count=enemies.length,gold=player.gold;open.f();open.f();assert.equal(enemies.length,count+1);assert.equal(player.gold,gold);assert.equal(player.inventory.length,0);assert.equal(enemies.at(-1).name,'Сундук-мимик');assert.deepEqual(enemies.at(-1).skills1621,['claw','venom']);exitDungeon();assert.equal(enemies.length,0);assert.equal(dg,null);console.log('40 thematic selections; 4 hazard state machines; detection, disarming, single mimic spawn, no duplicate loot, cleanup OK (mock).');`,{assert,console});
