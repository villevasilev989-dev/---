const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>{const i=h.indexOf(a),j=h.indexOf(b,i+a.length);assert(i>=0&&j>i);return h.slice(i,j)};
vm.runInNewContext(`const player={gold:1000,reputation:{}},residentRecords={};${part('  const CITY_FACTION=','  function realmSend(')}${part('  /* v1.16 economy','  function realmRows(')}
const loc=new Map([['A',{x:0,z:0}],['B',{x:1120,z:0}],['C',{x:2240,z:0}]]);
function reset(){Object.assign(realm,{day:10,owners:{A:'F',B:'G',C:'F'},relations:{[pair('F','G')]:0},stock:{},markets:{},civic:{},military:{},armies:[],armySerial:0,treaties:{},chronicle:[]});for(const c of loc.keys()){civic(c).treasury=500;supply(c).food=100;supply(c).ore=100;Object.assign(military(c),{troops:0,reserve:0,fort:100});}}
reset();let a={phase:'march',origin:'A',target:'B',faction:'F',troops:24,depart:10,due:14};warReturn(a,loc);assert.equal(a.due,11);assert.equal(a.returnFrom.x,85);realm.armies=[a];realm.day=11;const before=supply('A').food;militaryDay(loc);assert.equal(military('A').troops,24);assert.equal(supply('A').food,before-2);assert.equal(realm.armies.length,0);
reset();a={phase:'return',origin:'A',target:'B',faction:'F',troops:24,depart:10,due:14,destination:'A',returnFrom:{x:1000,z:0}};realm.armies=[a];realm.day=11;realm.owners.A='G';militaryDay(loc);assert.equal(a.destination,'C');assert.equal(a.returnFrom.x,750);assert.equal(a.due,17);assert.equal(a.strategy155.suppliedDays,1);
reset();realm.relations[pair('F','G')]=-1;Object.assign(military('A'),{troops:60,fort:100});realm.armies=[{phase:'siege',origin:'B',target:'A',faction:'G',troops:20,depart:8,due:9,siegeDays:1}];militaryDay(loc);assert(!realm.armies.some(a=>a.faction==='F'&&a.origin==='A'));assert(military('A').troops>12);
console.log('Retreat: real distance, rerouting after capture, supply on arrival, besieged garrison stays home.');`,{assert,console});
