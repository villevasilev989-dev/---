const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');const h=fs.readFileSync(__dirname+'/../index.html','utf8');const code=h.slice(h.indexOf('  function professionSpecs()'),h.indexOf('  function economyDay()'));
vm.runInNewContext(code+`
const r={name:'A',city:'C',profession:'Кузнец',age:40,money:0,justice149:{detained:3}},m={cash:100,consumed:{},produced:{}},st={ore:5},make=(t,rank,id,day)=>({id:id+day,type:t,name:'Sword'});
assert(!professionDay(r,'a',m,st,1,make));assert.equal(r.tradeSkill.last,'Под стражей');assert.equal(m.cash,100);assert.equal(st.ore,5);
const world={},p={gold:300};assert(enterpriseOpen144(world,'b','C',p));assert(enterpriseHire144(world,'b','a',{a:r}));const b=enterpriseStore144(world).b;b.cash=100;
assert(!enterpriseDay144(b,'b',{a:r},m,st,2,make));assert.equal(b.workers.length,1);assert.equal(b.cash,100);assert.equal(r.money,0);
assert(enterpriseDay144(b,'b',{a:r},m,st,3,make));assert.equal(r.money,6);assert.equal(st.ore,4);assert(!professionDay(r,'a',m,st,3,make));assert(!professionDay(r,'a',m,st,2,make));
b.closed=true;assert(!enterpriseDay144(b,'b',{a:r},m,st,4,make));b.closed=false;
assert(!enterpriseDay144(b,'b',{a:r},m,{},4,make));assert.equal(b.cash,91);assert(!professionDay(r,'a',m,{},5,make));assert.equal(r.tradeSkill.last,'Нет сырья');
r.hunger=95;assert(!professionDay(r,'a',m,st,6,make));assert.equal(r.tradeSkill.last,'Голод');r.hunger=0;r.fatigue=95;assert(!professionDay(r,'a',m,st,7,make));assert.equal(r.tradeSkill.last,'Усталость');
`,{assert});console.log('Shift eligibility, detention, retained contract, release, duplicate/backdated work, closed firms, absent stock and diagnostic reasons OK');
