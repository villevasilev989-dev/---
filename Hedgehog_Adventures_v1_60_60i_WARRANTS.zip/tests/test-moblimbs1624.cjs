const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(html.split('/* MOBLIMBS1624-BEGIN */')[1].split('/* MOBLIMBS1624-END */')[0]+`
let effectsEnabled=true,houseCtx=null,inDungeon=false,dg=null,disposed=0;
function disposeWild(e){assert.ok(e.mesh);disposed++;}
const part=()=>({rotation:{x:0,y:0,z:0}});
function enemy(shape='humanoid'){const u={armL:part(),armR:part(),legL:part(),legR:part(),legs:Array.from({length:8},part),headPart:part(),tailRig:part(),claws:[part(),part()]};return {shape,mesh:{visible:true,userData:u,rotation:{x:0,y:1,z:0},position:{y:2},scale:{x:1,y:1,z:1,set(x,y,z){Object.assign(this,{x,y,z});}}},wind:.2,windMax:1};}
const poses=new Set();for(const key of Object.keys(MOB_LIMBS1624)){const e=enemy();e.special1621=key;for(let i=0;i<100;i++){mobLimbReset1624(e);mobLimbPose1624(e);}const u=e.mesh.userData;poses.add([u.armR.rotation.x,u.armL.rotation.x,u.headPart.rotation.z].join(','));assert.ok(Math.abs(u.armR.rotation.x)<2);mobLimbReset1624(e);assert.ok(Math.abs(u.armR.rotation.x)<1e-12);e.stun=1;mobLimbPose1624(e);assert.equal(e.limbOffsets1624.length,0);}
assert.equal(poses.size,8);
for(const shape of ['humanoid','quadruped','spider','scorpion','blob']){const e=enemy(shape);mobDeath1624(e);mobCorpseTick1624(.6);assert.ok(shape==='blob'?e.mesh.scale.y<1:Math.abs(e.mesh.rotation.x)+Math.abs(e.mesh.rotation.z)>0);mobCorpseTick1624(2);assert.equal(mobCorpses1624.length,0);}
assert.equal(disposed,5);for(let i=0;i<30;i++)mobDeath1624(enemy());assert.equal(mobCorpses1624.length,24);assert.equal(disposed,11);houseCtx={};mobCorpseTick1624(.01);assert.equal(disposed,35);assert.equal(mobCorpses1624.length,0);houseCtx=null;inDungeon=true;dg={};const e=enemy();e.isDungeon=true;mobDeath1624(e);dg={};mobCorpseTick1624(.01);assert.equal(disposed,36);effectsEnabled=false;mobDeath1624(enemy());assert.equal(disposed,37);
`,{assert});assert.ok(html.includes('mobLimbReset1624(en)'));assert.ok(html.includes('mobLimbPose1624(en)'));assert.ok(html.includes('mobCorpseTick1624(dt)'));console.log('MOBLIMBS1624: eight profiles, nonaccumulation, stun, five death shapes, zone cleanup, cap and disabled effects');
