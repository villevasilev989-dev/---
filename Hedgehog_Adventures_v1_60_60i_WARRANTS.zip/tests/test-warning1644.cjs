const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const s=fs.readFileSync(__dirname+'/../server.js','utf8');
const events=[];const ctx={broadcast:(r,t,p)=>events.push({t,p}),sendTo:(peer,r,t,p)=>events.push({to:peer.id,t,p}),rid:()=> 'cast'};
vm.createContext(ctx);vm.runInContext(s.slice(s.indexOf('const NET_SKILLS1637='),s.indexOf('setInterval(()=>{for(const room of rooms.values())tickMobAttacks1637')),ctx);
const peer=id=>({id,stateAt:10000,state:{zone:'w',hp:100,x:1,y:0,z:0}});
const a=peer('a'),b=peer('b'),c=peer('c');const room={hostId:'a',worldReady:true,worldAt:10000,peers:new Map([['a',a],['b',b]]),entities:new Map([['m',{id:'m',x:0,y:0,z:0,hp:100,maxHp:100,atk:20,skills:['fire']}]])};
function tick(t){room.worldAt=t;for(const p of room.peers.values())p.stateAt=t;ctx.tickMobAttacks1637(room,t,()=>0);}
tick(10000);tick(12000);assert.equal(events[0].t,'mob_warning');room.peers.set('c',c);b.state.zone='d1';tick(12100);b.state.zone='w';tick(13300);assert.deepEqual(events.filter(e=>e.t==='mob_damage').map(e=>e.to),['a']);tick(13320);assert.equal(events.filter(e=>e.t==='mob_damage').length,1);
console.log('WARNING1644: late join and zone return excluded from already warned attack; eligible target damaged once.');
