process.chdir(require("node:path").resolve(__dirname,".."));
// Тест графики v1.7: геометрия деревьев/камней/травы, земля, вода, небо, шейдеры.
// Запуск: node test-gfx.cjs  (нужны three и glslangValidator для проверки GLSL; без него шейдеры проверяются только по тексту)
const fs = require('fs'), os = require('os'), path = require('path'), cp = require('child_process');
const THREE = require('three');
let failed = 0;
const ok = (c, m) => { if (c) console.log('  ✓ ' + m); else { failed++; console.log('  ✗ ' + m); } };
const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
const a = html.indexOf('/* GFX-BEGIN'), b = html.indexOf('/* GFX-END */');
if (a < 0 || b < 0) { console.log('✗ блок GFX не найден'); process.exit(1); }
const code = html.slice(a, b + 13);

// окружение, как в игре
const BIOMES = ['равнины', 'леса', 'горы', 'пустыня', 'снега', 'болота', 'вулканы'];
const biomeColor = { 'равнины': 0x5c8a3f, 'леса': 0x2f5c33, 'горы': 0x7a7568, 'пустыня': 0xc9a860, 'снега': 0xe8ecf0, 'болота': 0x4a5c3f, 'вулканы': 0x3a2e2a };
const hashBiome = (cx, cz) => { const bx = Math.floor(cx / 7), bz = Math.floor(cz / 7), v = Math.sin(bx * 127.1 + bz * 311.7) * 43758.5453; return BIOMES[Math.floor((v - Math.floor(v)) * BIOMES.length)]; };
const noise = (x, z) => Math.sin(x * 0.05) * Math.cos(z * 0.05) * 2.2 + Math.sin(x * 0.13 + z * 0.07) * 0.8;
const WATER_Y = -1.6, CHUNK = 40;
const isWet = (x, z) => noise(x, z) < WATER_Y + 0.4;
const GAME_SETTINGS = { quality: 'high' };
const GFX = new Function('THREE', 'CHUNK', 'biomeColor', 'hashBiome', 'noise', 'WATER_Y', 'isWet', 'nearRoad', 'inCityZone', 'GAME_SETTINGS',
  code + '\nreturn GFX;')(THREE, CHUNK, biomeColor, hashBiome, noise, WATER_Y, isWet, () => false, () => false, GAME_SETTINGS);
const finite = arr => { for (let i = 0; i < arr.length; i++) if (!Number.isFinite(arr[i])) return false; return true; };

console.log('Геометрия');
const geos = { trunk: GFX.G.trunk, spruce: GFX.G.spruce, root: GFX.G.root, canopy0: GFX.G.canopy[0], canopy1: GFX.G.canopy[1], canopy2: GFX.G.canopy[2] };
for (let i = 0; i < 4; i++) { geos['rock' + i] = GFX.rockGeo(i, false); geos['rockMoss' + i] = GFX.rockGeo(i, true); }
for (const [n, g] of Object.entries(geos)) {
  const p = g.attributes.position.array, c = g.attributes.color && g.attributes.color.array;
  ok(p.length > 0 && finite(p) && c && c.length === p.length && finite(c), `${n}: ${p.length / 3} вершин, цвета без NaN`);
}
// ель: грани смотрят наружу
{ const g = GFX.G.spruce, p = g.attributes.position; let bad = 0, n = 0;
  for (let i = 0; i < p.count; i += 3) { const A = new THREE.Vector3().fromBufferAttribute(p, i), B = new THREE.Vector3().fromBufferAttribute(p, i + 1), C = new THREE.Vector3().fromBufferAttribute(p, i + 2);
    const nm = new THREE.Vector3().subVectors(B, A).cross(new THREE.Vector3().subVectors(C, A)), cen = A.add(B).add(C).divideScalar(3); cen.y -= .4; n++; if (nm.dot(cen) < 0) bad++; }
  ok(bad === 0, `ель: все ${n} граней ориентированы наружу`); }
// камень: размеры и «посадка»
{ const bb = new THREE.Box3(); let minW = 9, maxW = 0;
  for (let i = 0; i < 60; i++) { const m = GFX.boulder(0x8a8576, true); bb.setFromObject(m); const s = bb.getSize(new THREE.Vector3()); minW = Math.min(minW, s.x, s.z); maxW = Math.max(maxW, s.x, s.z); }
  ok(minW > 1.3 && maxW < 3.6, `валуны: ширина ${minW.toFixed(2)}–${maxW.toFixed(2)} м (коллайдер считается по этим размерам)`); }
ok(!!GFX.cactus(0x4a7a3a).geometry && !!GFX.iceCrystal(0xcfe8ee).geometry && GFX.reeds(0x5c6b3a).children.length >= 7 && GFX.lavaVent().children.length === 2, 'кактус, лёд, тростник, вулкан создаются');
for (const t of [GFX.roundTree(0x5a4028, 0x5c8a3f), GFX.pineTree(0x3a2a1a, 0x1f3d22, 3), GFX.deadTree(0x4a3324)]) {
  const bs = new THREE.Box3().setFromObject(t).getSize(new THREE.Vector3()); ok(bs.y > 1.5 && bs.y < 6 && Number.isFinite(bs.x), `одиночное дерево высотой ${bs.y.toFixed(1)} м`);
}

console.log('Земля');
for (const [cx, cz] of [[0, 0], [1, 0], [0, 1]]) {
  const m = GFX.terrain(cx, cz, hashBiome(cx, cz)); m.position.set(cx * CHUNK, 0, cz * CHUNK);
  const p = m.geometry.attributes.position, n = m.geometry.attributes.normal, c = m.geometry.attributes.color;
  let badN = 0, badH = 0; for (let i = 0; i < p.count; i++) { if (Math.abs(Math.hypot(n.getX(i), n.getY(i), n.getZ(i)) - 1) > 1e-3) badN++; if (Math.abs(p.getY(i) - noise(p.getX(i) + cx * CHUNK, p.getZ(i) + cz * CHUNK)) > 1e-5) badH++; }
  ok(p.count === 625 && finite(c.array) && badN === 0 && badH === 0, `чанк ${cx},${cz}: 625 вершин, цвета/нормали корректны, высоты = noise()`);
}
{ // швы: правая кромка чанка 0 и левая чанка 1 совпадают по высоте, нормали и цвету
  const A = GFX.terrain(0, 0, hashBiome(0, 0)).geometry.attributes, B = GFX.terrain(1, 0, hashBiome(1, 0)).geometry.attributes; let maxD = 0;
  for (let r = 0; r <= 24; r++) { const ia = r * 25 + 24, ib = r * 25; for (const k of ['position', 'normal', 'color']) for (let q = 0; q < 3; q++) { if (k === 'position' && q === 0) continue; maxD = Math.max(maxD, Math.abs(A[k].array[ia * 3 + q] - B[k].array[ib * 3 + q])); } }
  ok(maxD < 1e-5, `шов между чанками бесшовный (макс. расхождение ${maxD.toExponential(1)})`); }
{ const t0 = Date.now(); for (let i = 0; i < 49; i++) GFX.terrain(i % 7, Math.floor(i / 7), 'равнины'); const ms = (Date.now() - t0) / 49;
  ok(ms < 40, `генерация чанка земли ≈ ${ms.toFixed(1)} мс`); }

console.log('Растительность');
for (const biome of BIOMES) {
  const grp = new THREE.Group(); GFX.groundCover(5, 5, biome, grp);
  let inst = 0, bad = 0; const m = new THREE.Matrix4(), v = new THREE.Vector3();
  grp.traverse(o => { if (o.isInstancedMesh) { inst += o.count; for (let i = 0; i < o.count; i++) { o.getMatrixAt(i, m); v.setFromMatrixPosition(m); if (!Number.isFinite(v.x + v.y + v.z) || Math.abs(v.x - 5 * CHUNK) > CHUNK / 2 + .01 || Math.abs(v.z - 5 * CHUNK) > CHUNK / 2 + .01) bad++; } } });
  const need = { 'равнины': 150, 'леса': 60, 'вулканы': 5 }[biome] || 0;
  ok(bad === 0 && inst >= need, `${biome}: ${inst} экземпляров (трава/цветы/камешки/грибы), все в пределах чанка`);
}
{ GAME_SETTINGS.quality = 'low'; const g1 = new THREE.Group(); GFX.groundCover(5, 5, 'равнины', g1); let n1 = 0; g1.traverse(o => { if (o.isInstancedMesh) n1 += o.count; });
  GAME_SETTINGS.quality = 'high'; const g2 = new THREE.Group(); GFX.groundCover(5, 5, 'равнины', g2); let n2 = 0; g2.traverse(o => { if (o.isInstancedMesh) n2 += o.count; });
  ok(n1 < n2 * .6, `низкое качество вдвое реже: ${n1} против ${n2}`); }

console.log('Шейдеры');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'glsl-'));
const hasGlslang = (() => { try { cp.execSync('glslangValidator --version', { stdio: 'ignore' }); return true; } catch (e) { return false; } })();
function validate(name, stage, src) {
  if (!hasGlslang) return true;
  const f = path.join(tmp, name + '.' + stage); fs.writeFileSync(f, src);
  try { cp.execSync('glslangValidator ' + f, { stdio: 'pipe' }); return true; } catch (e) { console.log(String(e.stdout || e.stderr).slice(0, 600)); return false; }
}
const lambertVS = THREE.ShaderLib.lambert.vertexShader;
function patched(mat) { const sh = { uniforms: {}, vertexShader: lambertVS }; mat.onBeforeCompile(sh); return sh; }
for (const [n, m] of [['листва', GFX.MAT.leaf], ['хвоя', GFX.MAT.needle], ['трава', GFX.MAT.grass]]) {
  const sh = patched(m);
  ok(sh.vertexShader !== lambertVS && /uniform float uTime;/.test(sh.vertexShader) && /transformed\.x\+=sin/.test(sh.vertexShader) && sh.uniforms.uTime === GFX.U.uTime, `ветер (${n}) встроен в шейдер three`);
  // сниппет в минимальной обвязке
  const i0 = sh.vertexShader.indexOf('#ifdef USE_INSTANCING\nfloat wph'), i1 = sh.vertexShader.indexOf('transformed.z+=cos', i0), snip = sh.vertexShader.slice(i0, sh.vertexShader.indexOf('\n', i1));
  const wrap = '#version 300 es\n#define USE_INSTANCING\nprecision highp float;\nuniform float uTime;\nin vec3 position;\nin mat4 instanceMatrix;\nvoid main(){\nvec3 transformed=position;\n' + snip + '\ngl_Position=vec4(transformed,1.0);\n}\n';
  ok(validate('wind_' + n, 'vert', wrap), `GLSL ветра (${n}) компилируется`);
}
{ const w = GFX.waterMaterial(); const sh = patched(w);
  ok(/modelMatrix\*vec4\(transformed/.test(sh.vertexShader), 'волны воды встроены в шейдер');
  const snip = sh.vertexShader.slice(sh.vertexShader.indexOf('vec3 wpos'), sh.vertexShader.indexOf('0.025;') + 6);
  ok(validate('water', 'vert', '#version 300 es\nprecision highp float;\nuniform float uTime;\nuniform mat4 modelMatrix;\nin vec3 position;\nvoid main(){\nvec3 transformed=position;\n' + snip + '\ngl_Position=vec4(transformed,1.0);\n}\n'), 'GLSL воды компилируется'); }
{ const scene = new THREE.Scene(); GFX.initSky(scene); const dome = scene.children.find(o => o.material && o.material.isShaderMaterial);
  ok(!!dome && !!THREE.ShaderChunk.colorspace_fragment, 'небесный купол создан, чанк colorspace_fragment есть в three');
  const fs0 = dome.material.fragmentShader.replace('#include <colorspace_fragment>', 'gl_FragColor = vec4(gl_FragColor.rgb, 1.0);');
  ok(validate('sky', 'frag', '#version 300 es\nprecision highp float;\nout vec4 fragOut;\n' + fs0.replace(/gl_FragColor/g, 'fragOut').replace('varying vec3 vP;', 'in vec3 vP;')), 'GLSL неба компилируется');
  const vs0 = dome.material.vertexShader.replace('varying vec3 vP;', 'out vec3 vP;');
  ok(validate('skyv', 'vert', '#version 300 es\nprecision highp float;\nuniform mat4 projectionMatrix;\nuniform mat4 modelViewMatrix;\nin vec3 position;\n' + vs0), 'вершинный шейдер неба компилируется');
  const cam = new THREE.Vector3(10, 5, 10), sky = new THREE.Color(0x9fb8c9), sunP = new THREE.Vector3(30, 50, 20), tgt = new THREE.Vector3(10, 0, 10);
  let threw = false; try { for (const day of [0, .2, .5, 1]) GFX.update(.016, cam, sky, day, sunP, tgt, true); GFX.update(.016, cam, sky, 1, sunP, tgt, false); } catch (e) { threw = e; }
  ok(!threw, 'смена суток и скрытие в подземелье работают' + (threw ? ': ' + threw : ''));
  ok(dome.visible === false, 'в подземелье небо скрыто');
  GFX.update(.016, cam, sky, 0, sunP, tgt, true);
  const stars = scene.children.find(o => o.isPoints); ok(stars.material.opacity === 1 && dome.position.equals(cam), 'ночью звёзды видны, купол следует за камерой'); }

console.log('Чанки и освобождение памяти');
{ const grp = new THREE.Group(); GFX.groundCover(2, 2, 'леса', grp); const mesh = GFX.terrain(2, 2, 'леса'); let disp = 0;
  mesh.geometry.addEventListener('dispose', () => disp++); grp.traverse(o => { if (o.isInstancedMesh) o.addEventListener('dispose', () => disp++); });
  let n = 0; grp.traverse(o => { if (o.isInstancedMesh) n++; });
  GFX.disposeChunk({ mesh, group: grp }); ok(disp === n + 1, `disposeChunk освободил землю и ${n} instanced-мешей`); }
{ const keys = [...html.matchAll(/const parts=\{([^}]*)\}/g)][0][1].split(',').map(x => x.split(':')[0].trim()).sort().join();
  const fm = html.match(/const FMATS=\{([^}]*)\}/)[1].split(',').map(x => x.split(':')[0].trim()).sort().join();
  ok(keys === fm, 'части леса (' + keys + ') покрыты геометриями и материалами'); }
ok(!/MeshToonMaterial\(\{color:0xffffff\}\)/.test(html.slice(html.indexOf('function buildForest'), html.indexOf('function buildForest') + 300)), 'лес больше не на плоском Toon-материале');

console.log(failed ? '\nПРОВАЛЕНО: ' + failed : '\nOK — графика v1.7 прошла проверки.');
process.exit(failed ? 1 : 0);
