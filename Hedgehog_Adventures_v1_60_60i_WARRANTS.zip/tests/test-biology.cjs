process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const block=h.slice(h.indexOf('/* BIOLOGY-BEGIN */'),h.indexOf('/* BIOLOGY-END */'));
vm.runInNewContext(block+`
const a={ageDays:20*365},b={ageDays:20*365};bioInit(a,'a','human');bioInit(b,'b','elf');assert(bioLife(b)>bioLife(a)*5);
const old=a.biologicalAge;bioAgeDay(a);assert.equal(a.biologicalAge,old+1);b.bodyRank=10;const prev=b.biologicalAge;bioAgeDay(b);assert(Math.abs(b.biologicalAge-prev-.4)<1e-8);
for(let i=0;i<1000;i++){const c=bioInheritance(a,b,'child'+i);assert(['human','elf'].includes(c.race));assert(c.genes.lineages.includes('human')&&c.genes.lineages.includes('elf'));assert(c.genes.affinity>=0&&c.genes.affinity<=100);}
assert.equal(bioHit(a,0,100,'legL'),null);assert.equal(bioMove(a),1);bioHit(a,50,100,'legL');assert(a.body.parts.legL.fracture);assert(bioMove(a)<1);bioHit(a,50,100,'legL');assert(a.body.parts.legL.lost);assert.equal(bioFunction(a,'legL'),0);assert(!bioTreatment(a,'heal','legL'));assert(!bioTreatment(a,'regrow','legL'));assert(bioTreatment(a,'prosthesis','legL'));assert.equal(bioFunction(a,'legL'),.8);assert(!bioTreatment(a,'magic','legL'));bioHit(a,100,100,'legL');assert(!a.body.parts.legL.prosthesis);assert(bioTreatment(a,'magic','legL'));assert.equal(bioFunction(a,'legL'),.95);a.bodyRank=5;assert(bioTreatment(a,'regrow','legL'));assert.equal(bioMove(a),1);assert(!bioTreatment(a,'regrow','legL'));
bioHit(a,50,100,'armL');bioHit(a,50,100,'armR');assert(bioAttack(a)<1);assert(bioTreatment(a,'heal','armR'));assert.equal(bioAttack(a),1);assert(a.body.bleed>0);assert(bioTreatment(a,'bandage'));assert.equal(a.body.bleed,0);assert(!bioTreatment(a,'bandage'));
bioHit(a,100,100,'eyes');assert.equal(bioFunction(a,'eyes'),0);bioRecover(a,100);assert.equal(bioFunction(a,'eyes'),0);assert(bioTreatment(a,'heal','eyes'));assert.equal(bioFunction(a,'eyes'),1);
let found=false;for(let i=0;i<1000;i++){bioDiseaseDay(a,'a',i);if(a.body.infection){found=true;break;}}assert(found);assert(bioTreatment(a,'infection'));assert.equal(a.body.infection,0);
const restored=JSON.parse(JSON.stringify(a));bioInit(restored,'a');assert.equal(JSON.stringify(restored),JSON.stringify(a));assert.deepEqual(Object.keys(restored.body.parts),Object.keys(BIO_PARTS));
console.log('Biology: racial lifespans, aging, 1000 mixed lineages, wounds, fractures, blindness, bleeding, infection, prosthesis replacement, restoration, JSON round-trip OK.');`,{assert,console});
