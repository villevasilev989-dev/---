const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(h.slice(h.indexOf('  const DG_HAZARDS1654='),h.indexOf('  /* DG1656-END */'))+`
const player={hp:100,maxHp:100,speed:4,buffs:[],alive:true},dg={},activeSite={level:10},dungeonFloor=2;let damage=0;const totalDef=()=>100,updateHud=()=>{},addBuff=(name,t,o)=>{player.buffs.push({name,t,...o});},dgDamage=n=>{damage+=n;player.hp-=n;player.alive=player.hp>0;};
for(const id of [33,77,84]){assert(dgAnomaly1656d(id).pit);player.buffs=[];dgTrapEffect1656(DG_HAZARDS1654['t'+id]);assert(player.buffs.some(b=>b.spd===-2.6));}
for(const id of [49,69,82,96]){player.buffs=[];const a=dgAnomaly1656d(id);dgTrapEffect1656(DG_HAZARDS1654['t'+id]);assert.equal(player.buffs[0].t,a.time);assert.equal(player.buffs[0].spd,-3.2);}
assert.equal(damage,55);assert.equal(dgAnomaly1656d(1),null);console.log('7 anomaly profiles, movement penalties, bounded time damage OK');`,{assert,console});
