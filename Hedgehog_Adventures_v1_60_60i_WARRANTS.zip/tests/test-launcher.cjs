process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
// Mock npm tests installation plumbing, not actual Three.js or WebGL.
const base=fs.mkdtempSync(path.join(os.tmpdir(),'dc setup (2) '));
try{
 const root=path.join(base,'game (2)'),bin=path.join(base,'bin');fs.mkdirSync(root);fs.mkdirSync(bin);fs.copyFileSync(path.join(__dirname,'../prepare3d.js'),path.join(root,'prepare3d.js'));
 fs.mkdirSync(path.join(root,'.dc-runtime'));
 const mock=path.join(bin,'npm');fs.writeFileSync(mock,'#!/usr/bin/env node\n'+`const fs=require('fs');const p=JSON.parse(fs.readFileSync('package.json','utf8'));if(p.dependencies.three!=='0.160.0')process.exit(9);if(process.env.FAIL_NPM)process.exit(7);fs.mkdirSync('node_modules/three/build',{recursive:true});fs.writeFileSync('node_modules/three/build/three.module.js',"const REVISION = '160';\\n"+'class WebGLRenderer {}\\nclass Scene {}\\nexport { REVISION, WebGLRenderer, Scene };\\n'+' '.repeat(510000));fs.writeFileSync('node_modules/three/LICENSE','test fixture');`,{mode:0o755});
 const run=(fail=false)=>spawnSync(process.execPath,[path.join(root,'prepare3d.js')],{env:{...process.env,PATH:bin+path.delimiter+process.env.PATH,FAIL_NPM:fail?'1':''},encoding:'utf8'});
 let r=run(true);assert.equal(r.status,1);assert.match(r.stderr,/npm failed: exit 7/);assert.ok(fs.existsSync(path.join(root,'.dc-runtime','package.json')));
 r=run();assert.equal(r.status,0,r.stderr);assert.ok(fs.existsSync(path.join(root,'vendor','three.module.js')));
 r=run(true);assert.equal(r.status,0,r.stderr);assert.match(r.stdout,/already installed/);
 console.log('PASS: missing manifest repaired, npm failure reported, install in path with spaces and parentheses, offline restart (mock npm).');
}finally{fs.rmSync(base,{recursive:true,force:true});}
