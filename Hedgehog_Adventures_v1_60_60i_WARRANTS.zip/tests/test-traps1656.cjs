const fs=require('node:fs'),assert=require('node:assert/strict'),vm=require('node:vm');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const a=h.indexOf('  const DG_HAZARDS1654='),b=h.indexOf('  /* DG1656-END */',a);
vm.runInNewContext(h.slice(a,b)+`
assert.equal(DG_TRAPS1656.length,105);assert.equal(new Set(DG_TRAPS1656.map(r=>r[0])).size,105);
let count=0,seen=new Set();for(let tier=0;tier<6;tier++)for(let style=0;style<10;style++)for(let floor of [1,50,250])for(let j=0;j<100;j++){
const k=dgPick1656({tier1653:tier,style1653:style},floor,(j+.5)/100,((j*37)%100+.5)/100),t=DG_HAZARDS1654[k];assert(t&&t.id<100);if(tier===0)assert(t.tier<=2);seen.add(t.id);count++;}
for(const r of DG_TRAPS1656){const t=DG_HAZARDS1654['t'+r[0]];const d=dgScaledDamage1656(t,100,10000,0);assert(Number.isFinite(d)&&d>=0);if(!t.base||t.tier===0)assert.equal(d,0);else{assert(dgScaledDamage1656(t,100,10000,1000)<d);assert(dgScaledDamage1656(t,200,20000,0)>d);}}
assert.equal(dgScaledDamage1656(DG_HAZARDS1654.t1,1e6,1e12,0),0);console.log(count+' generation checks; '+seen.size+' selectable variants sampled; 105 IDs; scaling and armor OK');`,{assert,console});
