process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const code=h.slice(h.indexOf('  // v1.14: persistent estate'),h.indexOf('  const houseMats='));
vm.runInNewContext(code+`
const d={city:'Тенеград',name:'Дом 1',x:10,z:20,kind:'home',seed:3,W:3,D:4,s:2,doorOpen:true,setDoor(v){this.doorOpen=v;estateFor(this).open=v;}};
const p={gold:0};assert.equal(estateFor(d).owner,'vacant');assert.equal(estateBuy(d,p),false);assert.equal(p.gold,0);
p.gold=1000;const cost=estatePrice(d);assert(estateBuy(d,p));assert.equal(p.gold,1000-cost);assert.equal(estateBuy(d,p),false);assert.equal(p.gold,1000-cost);
assert.equal(estateLock(d,false),false);d.setDoor(false);assert.equal(estateLock(d,true),false);assert(estateLock(d,false));assert(estateFor(d).locked);
estateFor(d).stash.push({id:'sword',type:'weapon'});const json=JSON.stringify(estateRecords);for(const k of Object.keys(estateRecords))delete estateRecords[k];Object.assign(estateRecords,JSON.parse(json));d.doorOpen=true;estateRestore(d);assert.equal(d.doorOpen,false);assert.equal(d.stash[0].id,'sword');assert(estateLock(d,false));assert(!estateFor(d).locked);
const n={...d,name:'Дом 2',seed:4};assert.equal(estateFor(n).owner,'resident');assert.equal(estateFor(n).locked,true);assert.equal(estateBuy(n,p),false);assert.equal(estateLock(n,false),false);assert.notEqual(estateId(n),estateId(d));
const pub={...n,name:'Библиотека',kind:'library'};assert.equal(estateFor(pub).owner,'public');assert.equal(estateFor(pub).open,true);
`,{assert});
assert(h.includes('estates:estateRecords,estateLaw'));assert(h.includes('for(const house of doors)estateRestore(house)'));assert(h.includes('estateFor(d).locked)return false'));assert(h.includes('if((e.code===b.estate||e.shiftKey)&&!inDungeon&&!houseCtx&&player.alive)'));assert(h.includes('rec.debt+=fine'));assert(h.includes('rec.debt=0;save15()'));console.log('Estates: ownership, insufficient funds, double purchase, lock authorization, persisted lock and stash round trip, public/private separation and integration wiring OK.');
