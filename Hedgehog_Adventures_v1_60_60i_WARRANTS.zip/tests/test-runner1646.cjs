const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'dc-runner-'));
try{
 const dir=path.join(root,'tests');fs.mkdirSync(dir);fs.copyFileSync(path.join(__dirname,'run-tests.cjs'),path.join(dir,'run-tests.cjs'));
 fs.writeFileSync(path.join(dir,'test-new.cjs'),'console.log("discovered")');
 fs.writeFileSync(path.join(dir,'test-bad.cjs'),'process.exit(1)');
 fs.writeFileSync(path.join(dir,'test-server.cjs'),'throw Error("should not run without ws")');
 const run=(mode)=>spawnSync(process.execPath,[path.join(dir,'run-tests.cjs'),mode],{encoding:'utf8',timeout:10000,env:{...process.env,NODE_PATH:''}});
 let r=run('test:logic');assert.equal(r.status,1,r.stderr);assert.match(r.stdout,/PASS test-new.cjs/);assert.match(r.stdout,/FAIL test-bad.cjs/);assert.match(r.stdout,/"EXCLUDED": 1/);
 fs.unlinkSync(path.join(dir,'test-bad.cjs'));r=run('test:logic');assert.equal(r.status,0,r.stderr);
 if(!require('node:module').globalPaths.some(p=>fs.existsSync(path.join(p,'ws')))){r=run('test');assert.equal(r.status,2,r.stderr);assert.match(r.stdout,/BLOCKED test-server.cjs/);}
 r=run('typo');assert.equal(r.status,1);assert.match(r.stderr,/Unknown test suite/);
 console.log('PASS: discovery, failure, exclusions, unknown mode and missing dependency handling.');
}finally{fs.rmSync(root,{recursive:true,force:true});}
