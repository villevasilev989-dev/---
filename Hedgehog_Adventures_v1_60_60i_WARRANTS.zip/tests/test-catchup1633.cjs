const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const slice=(a,b)=>h.slice(h.indexOf(a),h.indexOf(b,h.indexOf(a)+a.length));
const batch=vm.runInNewContext(slice('// CATCHUP1633-BEGIN','// CATCHUP1633-END')+'\nbatchWorld1633');
(async()=>{
 let i=0,yields=0,last=0;const order=[];
 await batch(450,n=>{order.push(n);i++;},(n,total)=>{assert(n>=last);assert.equal(total,450);last=n;},()=>i*9,async()=>{yields++;});
 assert.equal(i,450);assert.equal(last,450);assert.equal(yields,449);assert.deepEqual(order,Array.from({length:450},(_,n)=>n));
 let fast=0; await batch(4000,()=>{},()=>{},()=>0,async()=>{fast++;});assert.equal(fast,124);
 let zero=0;await batch(0,()=>{throw Error('unexpected work');},(n,t)=>{assert.equal(n,0);assert.equal(t,0);zero++;},()=>0,async()=>{});assert.equal(zero,1);
 let processed=0;await assert.rejects(batch(450,n=>{if(n===17)throw Error('failure');processed++;},()=>{},()=>0,async()=>{}),/failure/);assert.equal(processed,17);
 const advance=vm.runInNewContext(slice('  function residentPhase(','  function residentOffline(')+'\nresidentAdvance');
 const a=Array.from({length:700},(_,n)=>({hunger:30,fatigue:40,simAt:360,offset:n%60-30,guard:n%2===0})), b=JSON.parse(JSON.stringify(a)),target=360+450*1440;
 a.forEach(r=>advance(r,target));await batch(b.length,n=>advance(b[n],target),()=>{},()=>0,async()=>{});assert.deepEqual(a,b);
 assert(h.includes('if(adminState.noSave||saveBlocked1615||worldCatchup1633)return;'));
 assert(h.includes('await load15();'));assert(h.includes('clockStep.days>1'));assert(h.includes('residentSweep=residentClock;save15();'));
 console.log('CATCHUP1633: 450 ordered days, 4000 items, 700 residents x 450 days exact equivalence, yield limits, zero and failure, save guard (VM/static).');
})().catch(e=>{console.error(e);process.exitCode=1;});
