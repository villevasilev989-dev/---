"""Exercise the actual production save helpers in real Chromium, independent of WebGL."""
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from threading import Thread
from tempfile import TemporaryDirectory
from playwright.sync_api import sync_playwright
import shutil, sys
root=Path(__file__).resolve().parent.parent
html=(root/'index.html').read_text(encoding='utf-8')
helpers=html.split('// SAVE-VALIDATION1615-BEGIN',1)[1].split('// SAVE-VALIDATION1615-END',1)[0]+html.split('// IDB1634-BEGIN',1)[1].split('// IDB1634-END',1)[0]
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.end_headers();self.wfile.write(b'<!doctype html><title>Save test</title>')
    def log_message(self,*a): pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);Thread(target=server.serve_forever,daemon=True).start()
try:
    with TemporaryDirectory() as profile,sync_playwright() as pw:
        opts={'headless':True,'args':['--no-sandbox']};exe=shutil.which('chromium')
        if exe: opts['executable_path']=exe
        url=f'http://127.0.0.1:{server.server_port}/'
        def launch():
            ctx=pw.chromium.launch_persistent_context(profile,**opts);page=ctx.pages[0];page.goto(url);page.add_script_tag(content=helpers);return ctx,page
        ctx,page=launch()
        page.evaluate('''async()=>{
            const check=(v,m)=>{if(!v)throw Error(m)};
            const raw=(t,hp)=>JSON.stringify({v:1,savedAt:t,data:{hp},sky:['hub'],equip:{},quests:[],residents:Object.fromEntries(Array.from({length:4000},(_,i)=>['npc'+i,{name:'Гном 🐉 '+i,city:'Рунный Зал',hp:100}]))});
            const a=raw(1,10),b=raw(2,20),c=raw(3,30),d=raw(4,40),key='hero';
            localStorage.setItem(key,a);localStorage.setItem(key+'_backup',packSave1618(c));
            check(readSave1615(localStorage,key).data.hp===30,'newer local backup');writeSave1617(localStorage,key,b);check(readSave1615(localStorage,key).data.hp===30,'stale local write');
            writeSave1617(localStorage,key,d);check(decodeSave1618(localStorage.getItem(key+'_backup')).data.hp===30,'preserve best local backup');
            const db=await openSaveDb1634(indexedDB);await writeDb1634(db,key,packSave1618(a));await writeDb1634(db,key,packSave1618(b));
            await new Promise((ok,no)=>{const tx=db.transaction('heroes','readwrite');tx.objectStore('heroes').put({primary:packSave1618(a),backup:packSave1618(c)},key);tx.oncomplete=ok;tx.onerror=no;});
            await writeDb1634(db,key,packSave1618(b));let row=await readDb1634(db,key);check(chooseSave1634(row,null).data.hp===30,'stale database write');
            await writeDb1634(db,key,packSave1618(d));row=await readDb1634(db,key);check(decodeSave1618(row.backup).data.hp===30,'preserve best database backup');
            db.close();
        }''');ctx.close()
        ctx,page=launch();page.evaluate('''async()=>{const db=await openSaveDb1634(indexedDB), row=await readDb1634(db,'hero');if(chooseSave1634(row,readSave1615(localStorage,'hero')).data.hp!==40)throw Error('restart persistence');await new Promise((ok,no)=>{const tx=db.transaction('heroes','readwrite');tx.objectStore('heroes').put({primary:'broken',backup:row.backup},'hero');tx.oncomplete=ok;tx.onerror=no;});if(chooseSave1634(await readDb1634(db,'hero'),null).data.hp!==30)throw Error('recovery');db.close();}''');ctx.close()
        print('PASS: production save helpers, real Chromium IndexedDB/localStorage, 4000 NPC, stale writes, newest backup, restart and corrupted primary recovery')
except Exception as e:
    if 'ERR_BLOCKED_BY_ADMINISTRATOR' in str(e):
        print('BLOCKED: browser navigation restricted by administrator; no storage assertions executed:',e)
        sys.exit(2)
    raise
finally:
    server.shutdown();server.server_close()
