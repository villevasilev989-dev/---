process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>{const i=h.indexOf(a),j=h.indexOf(b,i+a.length);assert(i>=0&&j>i);return h.slice(i,j)};
vm.runInNewContext(`const player={gold:1000,reputation:{}},residentRecords={},knownSites={},NetworkTransport={isOpen:()=>false};${part('  const CITY_FACTION=','  function realmSend(')}${part('  /* v1.16 economy','  function realmRows(')}${part('  /* CULTIVATION-BEGIN */','  /* CULTIVATION-END */')}
const a='Орден Золотого Льва',b='Гильдия Магов',city='Златобашня',key=pair(a,b);
assert.equal(civic('Тенеград').tax,0);assert(civicTax(city)>=.05);assert.equal(civicFine(city),15);assert.equal(civicFine('Святоград'),30);civicCollect(city,55);assert.equal(civic(city).treasury,55);realm.owners[city]='Церковь Света';assert.equal(civicFine(city),30);assert.equal(civic(city).treasury,55);realm.owners[city]=a;
assert(!diplomacyRequest(a,b,'embargo'));assert.equal(player.gold,1000);player.reputation[a]=1600;assert(!diplomacyRequest(a,b,'war'));assert(diplomacyRequest(a,b,'embargo'));assert.equal(player.gold,960);assert(!diplomacyRequest(a,b,'embargo'));assert(tradePermitted(a,b));realmDay();assert(tradePermitted(a,b));realmDay();assert(!tradePermitted(a,b));assert(diplomacyRequest(a,b,'lift'));realmDay();realmDay();assert(tradePermitted(a,b));
player.reputation[a]=2600;assert(diplomacyRequest(a,b,'war'));realmDay();realmDay();assert.equal(relation(a,b),-1);assert(!tradePermitted(a,b));assert(!diplomacyRequest(a,b,'trade'));assert(diplomacyRequest(a,b,'peace'));realmDay();realmDay();assert.equal(relation(a,b),0);assert(tradePermitted(a,b));
assert(diplomacyRequest(a,b,'trade'));const saved=JSON.parse(JSON.stringify(realm));Object.assign(realm,saved);realmDay();realmDay();assert(!diplomatic(a,b).pending);assert(realm.chronicle.length>=10);const count=realm.chronicle.length;diplomacyDay();assert.equal(realm.chronicle.length,count);assert(!diplomacyRequest(a,'Культ Бога Ежа','war'));assert(!diplomacyRequest(a,a,'war'));player.gold=0;assert(!diplomacyRequest(a,b,'embargo'));
realm.owners[city]=a;player.gold=1000;player.reputation[a]=2600;realm.treaties={};realm.relations[key]=0;
assert(diplomacyRequest(a,b,'war'));realm.relations[key]=1;realm.day+=2;diplomacyDay();assert.equal(relation(a,b),1);assert(!diplomatic(a,b).pending);
realm.relations[key]=-1;assert(diplomacyRequest(a,b,'peace'));realm.relations[key]=1;realm.day+=2;diplomacyDay();assert.equal(relation(a,b),1);
realm.relations[key]=0;assert(diplomacyRequest(a,b,'embargo'));for(const c of Object.keys(realm.owners))if(realm.owners[c]===b)realm.owners[c]=a;realm.day+=2;diplomacyDay();assert(!diplomatic(a,b).embargo);assert(!diplomatic(a,b).pending);
console.log('PASS: obsolete war, peace and extinct faction proposals cancelled');`,{assert,console});
