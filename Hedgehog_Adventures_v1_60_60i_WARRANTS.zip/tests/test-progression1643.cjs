const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const gain=h.slice(h.indexOf('  function gainXP('),h.indexOf('  function completeQuest('));
const validation=h.slice(h.indexOf('// SAVE-VALIDATION1615-BEGIN'),h.indexOf('// SAVE-VALIDATION1615-END'));
vm.runInNewContext(gain+validation+`
const player={lvl:10000,xp:0,xpNext:100,perk:{},maxHp:100,maxMp:100,skillPoints:0,attrPoints:0};
const log=()=>{},renderSkillTree=()=>{},updateHud=()=>{};
gainXP(100);assert.equal(player.lvl,10001);assert.equal(player.skillPoints,3);assert.equal(player.attrPoints,1);assert(player.xpNext>100);
for(const x of [NaN,Infinity,-1,1e100])gainXP(x);assert.equal(player.xp,0);assert.equal(player.lvl,10001);
player.xpNext=0;gainXP(100);assert.equal(player.lvl,10001);assert.equal(player.xp,0);
const save=data=>({v:1,data,sky:[],equip:{},quests:[]});
for(const data of [{lvl:0},{xp:-1},{xpNext:0},{lvl:1.2},{skillPoints:-1}])assert.throws(()=>validateSave1615(save(data)));
validateSave1615(save({lvl:100000,xp:3000000000,xpNext:4000000000,skillPoints:3000000000}));
`,{assert});
const legacy=h.slice(h.indexOf('      const lv=Number.isSafeInteger(d.lv)'),h.indexOf("      log('💾 Загружен прогресс созвездия"));
vm.runInNewContext(legacy+`assert.equal(player.lvl,3000000000);assert.equal(player.xp,4000000000);assert.equal(player.xpNext,5000000000);assert.equal(player.skillPoints,6000000000);`,{assert,d:{lv:3000000000,xp:4000000000,xn:5000000000,sp:6000000000},player:{maxHp:100,maxMp:100},spellOrder:[]});
console.log('Progression above level 10000, malformed XP, invalid saves, legacy migration above signed 32-bit range passed.');
