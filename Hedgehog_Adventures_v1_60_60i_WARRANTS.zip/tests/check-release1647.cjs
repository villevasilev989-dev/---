// Read-only release prerequisite check; never marks untested game features as passed.
const fs=require('node:fs'),path=require('node:path'),{valid}=require('../prepare3d');
const root=path.resolve(__dirname,'..'),pkg=require('../package.json');
const checks=[];const add=(name,ok,detail)=>checks.push({name,status:ok?'READY':'BLOCKED',detail});
add('Node.js >=18',Number(process.versions.node.split('.')[0])>=18,process.version);
const local=['vendor/three.module.js','node_modules/three/build/three.module.js','.dc-runtime/node_modules/three/build/three.module.js'].find(p=>valid(path.join(root,p)));
add('Three.js r160 module',!!local,local||'Run node prepare3d.js');
for(const dep of ['ws','three']){let version;try{let dir=path.dirname(require.resolve(dep,{paths:[root]}));while(dir!==path.dirname(dir)){const file=path.join(dir,'package.json');if(fs.existsSync(file)){const p=JSON.parse(fs.readFileSync(file,'utf8'));if(p.name===dep){version=p.version;break;}}dir=path.dirname(dir);}}catch{}add(dep+' npm package',version===pkg.dependencies[dep],version||'Run npm install');}
console.log(JSON.stringify({version:pkg.version,checks,manual:['Windows launch','Real WebGL gameplay','IndexedDB persistence','Two-client WebSocket session']},null,2));
process.exitCode=checks.some(c=>c.status==='BLOCKED')?2:0;
