process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>{const i=h.indexOf(a),j=h.indexOf(b,i+a.length);assert(i>=0&&j>i);return h.slice(i,j)};
vm.runInNewContext(`const player={gold:1000,reputation:{}},residentRecords={};${part('  const CITY_FACTION=','  function realmSend(')}${part('  /* v1.16 economy','  function realmRows(')}
const a='Златобашня',b='Звёздная Башня',f='Орден Золотого Льва',g='Гильдия Магов',loc=new Map([[a,{x:0,z:0}],[b,{x:500,z:0}]]);
Object.assign(realm,{day:0,owners:{[a]:f,[b]:g},population:{},markets:{},stock:{},military:{},armies:[],relations:{},chronicle:[]});
const pa=population(a),pb=population(b),sum=popTotal(pa)+popTotal(pb);assert.equal(popMove(pa,pb,30),30);assert.equal(popTotal(pa)+popTotal(pb),sum);assert.equal(pa.departures,30);assert.equal(pb.arrivals,30);
marketFor(a).shortage=4;marketFor(b).shortage=0;for(let i=0;i<30;i++){realm.day++;demographicDay(loc);}assert(pa.departures>30);assert.equal(pa.departures,pb.arrivals);
const balance=()=>Object.values(realm.population).reduce((n,p)=>n+popTotal(p)-p.births+p.deaths-p.arrivals+p.departures+(p.enlisted||0),0);assert.equal(balance(),sum);
residentRecords.m=familyInit({name:'Мэй Ли',age:24,city:b,hunger:0,fatigue:0,sex:'f',money:21,partner:'f',pregnancy:{father:'f',due:realm.day+1}},'m');residentRecords.f=familyInit({name:'Лин Рейн',age:25,city:b,hunger:0,fatigue:0,sex:'m',money:10,partner:'m'},'f');
realm.day++;familyDay();const id=residentRecords.m.children[0],child=residentRecords[id];assert(child);assert.deepEqual([...child.parents],['m','f']);assert.equal(child.age,0);assert(child.abstract);assert.equal(residentRecords.f.children[0],id);familyDay();assert.equal(residentRecords.m.children.length,1);assert(child.ageDays===1);assert(familyAncestors(id).has('m'));
residentRecords.m.lifeDays=residentRecords.m.ageDays+1;realm.day++;familyDay();assert(residentRecords.m.dead);assert.equal(child.money,21);assert(!residentRecords.f.partner);familyDay();assert.equal(child.money,21);
const snap=JSON.stringify({realm,residentRecords});const restore=JSON.parse(snap);assert.equal(restore.residentRecords[id].parents[0],'m');assert(restore.residentRecords.m.dead);
for(let i=0;i<450;i++){economyDay();demographicDay(loc);for(const p of Object.values(realm.population)){assert(p.child>=0&&p.adult>=0&&p.elder>=0);assert(Number.isInteger(popTotal(p)));}assert.equal(balance(),sum);}assert(pa.births+pb.births>0);assert(pa.deaths+pb.deaths>0);
console.log('Population: migration conservation, age cohorts, family birth, parent links, death, inheritance, JSON and 450-day balance OK.');`,{assert,console});
