const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(h.slice(h.indexOf('  const ROMANCE_VOICES1655f'),h.indexOf('  function romanceWalk1655f'))+`
assert.equal(ROMANCE_PERSONAL1657o.length,15);assert.equal(new Set(ROMANCE_PERSONAL1657o.flat()).size,60);
for(let i=0;i<15;i++){const r=romanceState1655f({},'npc');assert.equal(romanceMood1657o(r),'знакомство');assert.equal(romanceReply1657o(r,i,'kind'),ROMANCE_PERSONAL1657o[i][0]);assert(ROMANCE_REPLIES1655j.cautious.includes(romanceReply1657o(r,i,'flirt')));r.affinity=75;r.trust=45;assert.equal(romanceMood1657o(r),'близость');assert.equal(romanceReply1657o(r,i,'flirt'),ROMANCE_PERSONAL1657o[i][1]);r.history=[{action:'betray',minute:10}];assert(romanceReply1657o(r,i,'apology').includes('оскорбление'));r.history=[{action:'kind',minute:10},{action:'kind',minute:25}];assert(romanceReply1657o(r,i,'kind').includes('поступки'));r.feud=true;assert.equal(romanceMood1657o(r),'вражда');}
console.log('60 personal replies, context, relationship stages and legacy state OK');`,{assert,console});
assert(h.includes('const reply=key=>romanceReply1657o'));assert(h.includes('Отношения: '));
