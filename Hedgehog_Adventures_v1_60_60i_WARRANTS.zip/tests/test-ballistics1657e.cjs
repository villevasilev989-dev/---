const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');const h=fs.readFileSync(__dirname+'/../index.html','utf8');vm.runInNewContext(h.split('/* PROJECTILE1657D-BEGIN */')[1].split('/* PROJECTILE1657D-END */')[0]+`
const a={x:0,y:1,z:0},b={x:12,y:1,z:0};const make=(g)=>({p:{...a},dir:shotAim1657e(a,b,24,g),left:14,speed:24,gravity:g});
let q=make(9.81);shotStep1657d(q,.25,()=>true,()=>[]);assert(Math.abs(q.p.y-1.3065625)<1e-8);shotStep1657d(q,.25,()=>true,()=>[]);assert(Math.abs(q.p.y-1)<1e-8);assert(Math.abs(q.p.x-12)<1e-8);
q=make(0);shotStep1657d(q,.25,()=>true,()=>[]);assert.equal(q.p.y,1);
q=make(9.81);assert.equal(shotStep1657d(q,.5,()=>true,()=>[{enemy:'mob',p:b,radius:.48}]).hit,'mob');
q=make(9.81);assert.equal(shotStep1657d(q,.5,(a,b)=>b.x<5,()=>[{enemy:'mob',p:{x:6,y:1,z:0},radius:.48}]).hit,null);
q=make(9.81);let max=0;shotStep1657d(q,.5,(a,b)=>{max=Math.max(max,Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z));return true},()=>[]);assert(max<=.12000001);
assert.equal(SHOT_GRAVITY1657E.staff,0); console.log('Ballistic arc, compensation, straight magic, collision and step limit OK');`,{assert,console});
