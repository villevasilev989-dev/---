const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const a=h.indexOf('  const DG_HAZARDS1654='),b=h.indexOf('  /* DG1656-END */',a);
vm.runInNewContext(h.slice(a,b)+`
const player={hp:100,maxHp:100,speed:4,buffs:[],alive:true},dg={},activeSite={level:10},dungeonFloor=2,playerMesh={position:{x:1,z:0}};let damage=0;const totalDef=()=>100,updateHud=()=>{},addBuff=(name,t,o)=>{player.buffs.push({name,t,...o});player.speed+=o.spd||0;},dgMove=(p,x,z)=>{p.x+=x;p.z+=z;},dgDamage=n=>{damage+=n;};
for(const r of DG_TRAPS1656){const t=DG_HAZARDS1654['t'+r[0]],q=dgEffectProfile1656a(t);for(const v of Object.values(q))assert(Number.isFinite(v)&&v>=0);assert(q.dot<=5);}
const t=id=>DG_HAZARDS1654['t'+id];dgTrapEffect1656(t(4));assert.equal(player.speed,2);dgTrapEffect1656(t(4));assert.equal(player.speed,2);assert.equal(player.buffs.length,1);
dgTrapEffect1656(t(42));assert(player.buffs.some(b=>b.def<0));assert(dg.hazardDots.length===1);dgDots1656(10);assert.equal(dg.hazardDots.length,0);assert(damage>0);
dgTrapEffect1656(t(9),{x:0,z:0});assert.equal(playerMesh.position.x,6);dgTrapEffect1656(t(81),{x:0,z:0});assert.equal(playerMesh.position.x,1);
assert.equal(dgEffectProfile1656a(t(5)).dot,0);assert.equal(dgEffectProfile1656a(t(12)).dot,3);console.log('105 profiles; non-stacking debuffs; corrosion, timed damage, displacement OK');`,{assert,console});
