process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const house=h.slice(h.indexOf('  // v1.14: persistent estate'),h.indexOf('  function buildingInterior('));
const coll=h.slice(h.indexOf('  function addCollider('),h.indexOf('  function clearZone('));
const mock=`
class V{constructor(x=0,y=0,z=0){this.set(x,y,z)}set(x,y,z){Object.assign(this,{x,y,z});return this;}}
class N{constructor(g,m){this.geometry=g;this.material=m;this.position=new V();this.rotation=new V();this.scale=new V(1,1,1);this.children=[];this.userData={};}add(q){this.children.push(q)}clear(){this.children=[]}}
class G{constructor(...args){this.args=args}setAttribute(){}setIndex(){}computeVertexNormals(){}}
class S{moveTo(){}lineTo(){}closePath(){}}
const THREE={Group:N,Mesh:N,BoxGeometry:G,SphereGeometry:G,CylinderGeometry:G,Shape:S,ShapeGeometry:G,BufferGeometry:G,Float32BufferAttribute:G,MeshStandardMaterial:G,CanvasTexture:G};
const document={createElement:()=>({getContext:()=>({fillRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){}})})};
const colGrid=new Map(),CG=8,doors=[],noise=(x,z)=>Math.sin(x*.05)*Math.cos(z*.05)*2.2+Math.sin(x*.13+z*.07)*.8,seedCity=n=>[...n].reduce((a,c)=>(Math.imul(a,31)+c.charCodeAt(0))>>>0,7),playerMesh=new N();
`;
const cleanup=h.slice(h.indexOf('  function removeCampCols1614('),h.indexOf('  function campClear156('));
vm.runInNewContext(mock+coll+cleanup+house+`
let count=0;for(const style of ["east","masonry","log","timber"])for(const kind of ['home','herb','craft','shop','inn','bank','guild','library','guard','mill','storage','manor','farm','fish','temple','arsenal','supply','officers','stable','watch'])for(let i=0;i<20;i++){
 colGrid.clear();doors.length=0;for(const id of Object.keys(estateRecords))delete estateRecords[id];const h=new N();h.scale.x=i%2?1.65:2;h.rotation.y=i*Math.PI/10;h.position.set(10,0,-7);const d=registerDoor(h,[],30,20,kind,'Test '+i,style);estateFor(d).locked=false;d.setDoor(true);const at=(x,z)=>({x:d.x+d.s*(x*Math.cos(d.angle)+z*Math.sin(d.angle)),z:d.z+d.s*(-x*Math.sin(d.angle)+z*Math.cos(d.angle))});
 // Walk through the actual front wall opening and back, using the shipped collider resolver.
 for(let j=0;j<=100;j++){const z=d.D/2+1.1-j*.025;const p=at(0,z),orig={...p};resolveCollide(p,.45);assert(Math.hypot(p.x-orig.x,p.z-orig.z)<1e-6,kind+' blocked entrance');if(z<d.D/2-.05)assert.equal(houseGround(p),d.top);}
 // A point intersecting the front wall to the side must be pushed back out.
 const p=at(d.W/2-.25,d.D/2),orig={...p};resolveCollide(p,.45);assert(Math.hypot(p.x-orig.x,p.z-orig.z)>.1,'solid wall missing');
 // Closing cannot trap player inside the doorway.
 const put=(x,z)=>{const p=at(x,z);playerMesh.position.set(p.x,0,p.z);};
 put(0,d.D/2);assert.equal(d.toggleDoor(),false);assert.equal(d.doorOpen,true);
 put(0,d.D/2+.85);assert.equal(d.toggleDoor(),true);assert.equal(d.doorOpen,false);
 const blocked=at(0,d.D/2+.1),before={...blocked};resolveCollide(blocked,.45);assert(Math.hypot(blocked.x-before.x,blocked.z-before.z)>.1,'closed door not solid');
 assert.equal(d.toggleDoor(),true);assert.equal(d.doorOpen,true);const again=at(0,d.D/2+.1),a0={...again};resolveCollide(again,.45);assert(Math.hypot(again.x-a0.x,again.z-a0.z)<1e-6,'reopened door blocked');
 count++;
}console.log('Walk-in houses: '+count+' type/rotation/scale cases, clear centre entrance, solid side walls, closed/reopened door collision, safe closing and continuous interior height; geometry mock only.');`,{assert,console});
assert(!h.includes('if(d){enterHouse(d);return;}'));console.log('No button-triggered house teleport in interaction handler.');
