const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const code=h.slice(h.indexOf('  function population(city)'),h.indexOf('  function family',h.indexOf('  function population(city)')));
// Extract only the four demographic functions, not unrelated family declarations.
const end=code.indexOf('\n  }',code.indexOf('  function demographicDay('))+4;
vm.runInNewContext(`
let realm; const seedCity=()=>0, marketFor=c=>realm.markets[c], factionForCity=c=>realm.owners[c], relation=(a,b)=>a===b?0:-1, tradePermitted=()=>true, civicLog=()=>{},familyDay=()=>{};
const warNearest=(c,choices,loc)=>choices.find(x=>loc.has(x));
${code.slice(0,end)}
function run(source,dest,siege=false){
 realm={day:7,owners:{[source]:'A',[dest]:'B'},markets:{[source]:{shortage:siege?0:4},[dest]:{shortage:0}},military:{[dest]:{reserve:999}},armies:siege?[{target:source,phase:'siege',faction:'B'}]:[]};
 for(const c of [source,dest])Object.assign(population(c),{child:1000,adult:5000,elder:1000,base:7000,carry:{}});
 const loc=new Map([[source,{}],[dest,{}]]);demographicDay(loc);
 const a=population(source),b=population(dest);assert(a.departures>0);assert.equal(a.departures,b.arrivals);assert.equal(popTotal(a)+popTotal(b),14000+a.births+b.births-a.deaths-b.deaths);assert.equal(realm.military[dest].reserve,Math.min(999,Math.floor(b.adult*.25)));return JSON.stringify([a,b]);
}
assert.equal(run('A','Z'),run('Z','A'));assert.equal(run('A','Z',true),run('Z','A',true));
console.log('Demography: famine and siege migration independent of city sorting; conservation and reserve caps verified.');`,{assert,console});
