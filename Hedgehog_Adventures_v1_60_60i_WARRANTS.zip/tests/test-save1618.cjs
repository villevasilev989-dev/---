const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(h.slice(h.indexOf('// SAVE-VALIDATION1615-BEGIN'),h.indexOf('// SAVE-VALIDATION1615-END'))+`
const make=(hp,n=4000)=>JSON.stringify({v:1,data:{hp},sky:['hub'],equip:{},quests:[],residents:Object.fromEntries(Array.from({length:n},(_,i)=>['npc'+i,{name:'Дворф 🐉 '+i,hunger:40,fatigue:20,profession:'Инженер',city:'Рунный Зал'}]))});
const old=make(30),next=make(42),packed=packSave1618(next);assert(packed.length<next.length/2);assert.equal(unpackSave1618(packed),next);assert.throws(()=>unpackSave1618('DCZ1:\\0'));
const key='dc_full15_mage_dwarf',other='dc_full15_mage_human',m=new Map([[key,old],[other,'untouched']]);let limit=old.length+100;
const storage={getItem:k=>m.get(k)??null,removeItem:k=>m.delete(k),setItem(k,v){const size=[...m].filter(([x])=>x!==k).reduce((a,[x,y])=>a+x.length+y.length,0)+k.length+v.length;if(size>limit){const e=Error('quota');e.name='QuotaExceededError';throw e;}m.set(k,v);}};
assert.equal(readSave1615(storage,key).data.hp,30);assert.equal(writeSave1617(storage,key,next),true);assert.equal(readSave1615(storage,key).data.hp,42);assert.equal(m.get(other),'untouched');
limit=packed.length+100;assert.equal(writeSave1617(storage,key,make(43)),false);assert.equal(readSave1615(storage,key).data.hp,43);assert.equal(m.get(other),'untouched');
limit=1;const prior=m.get(key);assert.throws(()=>writeSave1617(storage,key,make(44)));assert.equal(m.get(key),prior);assert.equal(m.get(other),'untouched');
limit=old.length+100;writeSave1617(storage,key,next);m.set(key,'broken');assert.equal(readSave1615(storage,key).data.hp,43);
console.log('Compression: '+next.length+' -> '+packed.length+' UTF-16 units; quota, migration, other character isolation, backup recovery passed');
`,{assert,console});
