const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(html.split('/* MOB1621-BEGIN */')[1].split('/* MOB1621-END */')[0]+`
const e=mobInit1621({isBoss:true,hp:100,maxHp:100,atk:8},{name:'Повелитель Пламени',shape:'blob'},'вулканы');
assert.equal(e.affinity1622,'fire');assert.equal(mobDamage1622(e,100,['fire']),75);assert.equal(mobDamage1622(e,100,['ice']),120);assert.equal(mobDamage1622(e,100,['ice','fire']),100);assert.equal(mobDamage1622(e,100,[]),100);
assert.equal(mobPhase1622(e),0);e.hp=e.maxHp*.5;e.specialCd1621=8;assert.equal(mobPhase1622(e),2);assert.equal(e.specialCd1621,2.5);assert.equal(mobPhase1622(e),0);e.hp=e.maxHp*.25;assert.equal(mobPhase1622(e),3);assert.equal(mobTiming1622(e,MOB_SKILLS1621.fire).cd,6.5);assert.equal(mobTiming1622(e,MOB_SKILLS1621.fire).wind,1.3);e.hp=e.maxHp;assert.equal(mobPhase1622(e),0);assert.equal(e.phase1622,3);
assert.equal(mobPhase1622({isBoss:false,hp:1,maxHp:100,level1621:4}),0);assert.equal(mobPhase1622({isBoss:true,hp:0,maxHp:100,level1621:4}),0);
assert.equal(mobDamage1622({},100,['fire']),100);assert.equal(mobAffinity1622({name:'Волк',shape:'quadruped'},'равнины'),null);
`,{assert});console.log('BOSS1622: affinities, hybrid damage, irreversible phase thresholds, cooldown and unchanged telegraph verified');
