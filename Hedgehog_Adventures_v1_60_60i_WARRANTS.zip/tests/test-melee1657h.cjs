const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');const h=fs.readFileSync(__dirname+'/../index.html','utf8');vm.runInNewContext(h.split('/* MELEE1657H-BEGIN */')[1].split('/* MELEE1657H-END */')[0]+`
const c=[{target:'rear',d:1,dx:0,dz:1},{target:'front',d:2,dx:0,dz:-2},{target:'side',d:2,dx:2,dz:0},{target:'far',d:7,dx:0,dz:-7},{target:'front2',d:3,dx:0,dz:-3}];
assert.equal(meleeTargets1657h(c,{k:'spear',range:5.2},0).map(x=>x.target).join(','),'front,front2');
assert.equal(meleeTargets1657h(c,{k:'scythe',range:4.5},0).length,4);
assert.equal(meleeTargets1657h(c,{k:'axe',range:3.5},0).length,3);
assert.equal(meleeTargets1657h(c,{k:'dagger',range:2.4},0).length,1);
assert.equal(meleeTargets1657h(c,{k:'spear',range:5.2},0)[1].mul,.75);
assert.equal(meleeTargets1657h(c,{k:'legacy',range:4},0).length,0);
assert.equal(meleeTargets1657h(c,{k:'spear',range:5.2},Math.PI)[0].target,'rear');
console.log('Melee angles, falloff, caps, direction, range and fallback OK');`,{assert,console});
