process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const block=h.slice(h.indexOf('  const CITY_FACTION='),h.indexOf('  const realm='));
vm.runInNewContext(block+`
const valid=new Set(['human','elf','dwarf','angel','demon','beast']),styles=new Set(['east','masonry','log','timber']);
for(const city of Object.keys(CITY_FACTION)){
 const p=cityCulture(city);assert(styles.has(p.style),city);assert(p.name&&p.government&&p.tech&&p.food&&p.drink,city);assert(Number.isInteger(p.wall)&&Number.isInteger(p.roof));if(p.race)assert(valid.has(p.race),city);
 assert.equal(cityRuler(city),p.name);if(CITY_FACTION[city]!=='Test')assert.equal(cityRuler(city,'Test'),p.name);
}
assert.equal(cityCulture('Ледяная Крепость').tax,12);assert.equal(cityCulture('Крепость Семи Гномов').race,'dwarf');assert.equal(cityCulture('Сильвандрия').race,'elf');assert.equal(cityCulture('unknown').leader,'Управитель');
assert.equal(Object.keys(REGIONAL_DESIGN).length,24);console.log('Regional profiles: '+Object.keys(CITY_FACTION).length+' cities, styles, race keys, rulers, meals, fallback, preserved original profiles.');
function factionForCity(city){return originalOwners[city];}
`,{assert,console});
