const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8'), b=fs.readFileSync(__dirname+'/test.cjs','utf8');
const cut=(a,z)=>h.slice(h.indexOf(a),h.indexOf(z,h.indexOf(a)+a.length));
const generator=cut('  const DUNGEON_TILE=','  /* ---- Runtime dungeon ---- */');
const enemy=cut('  const ENEMY_TYPES = [','  /* MOB1621-BEGIN */');
const placement=cut('  function siteHash(','  function siteKey(');
vm.runInNewContext(generator+enemy+`
const CHUNK=40,BIOME_SCALE=7,BIOMES=['равнины','леса','горы','пустыня','снега','болота','вулканы'],WATER_Y=-1.6,CITY_ACCENTS=[1],VILLAGE_NAMES=['village'];let cityPlan=null;
`+cut('  const CITY_NAMES =','  const VILLAGE_NAMES =')+cut('  function hashBiome(','/* GFX-BEGIN:')+cut('  function lakeAmt(','  function clearZone2(')+h.match(/^  const settlementPrefixes1655i=[^\n]*/m)[0]+"\n"+placement+`
const sites=dgMakeSites1653(),old=[[-20,20],[-145,90],[175,-125],[-220,-180],[330,-330],[410,180],[-450,260],[-390,-420],[480,-180],[500,430]];
const blocked=(x,z)=>lakeNear(x,z,12)||reservedSettlement(x,z,12)||Math.hypot(x-45,z-45)<90||old.some(([a,b])=>Math.hypot(a-x,b-z)<95);
const place=()=>dgPlace1653(dgMakeSites1653(),blocked,(x,z)=>hashBiome(Math.floor(x/CHUNK),Math.floor(z/CHUNK)));
assert.equal(sites.length,77);assert.equal(new Set(sites.map(s=>s.name)).size,77);assert.equal(new Set(sites.map(s=>s.catalog1653)).size,77);assert.equal(sites[64].floors,null);assert.equal(sites[63].floors,1);assert.equal(sites[59].floors,300);assert.equal(sites[62].floors,400);
const placed=place();assert.equal(JSON.stringify(placed),JSON.stringify(place()));for(let i=0;i<placed.length;i++){const s=placed[i];assert(!blocked(s.x,s.z));assert(placed.slice(0,i).every(p=>Math.hypot(s.x-p.x,s.z-p.z)>=95));}
let layouts=0,profiles=0;for(const s of sites){for(const floor of new Set([1,5,10,s.floors||10000].filter(f=>!s.floors||f<=s.floors))){for(let seed=1;seed<=4;seed++){const d=generateDungeon(seed,floor,s),exit=d.rooms[d.exit];assert.equal(exit.kind==='boss',dgBossFloor1653(s,floor));for(const room of d.rooms.slice(1))assert(dgPath(d.tiles,'0,0',dgKey(room.tx,room.tz)).length>0);assert(dgWalkable(d.tiles,exit.tx*2,exit.tz*2+3));layouts++;}for(const boss of [false,true]){for(const r of [()=>0,()=>.999]){const t=dgEnemy1653(s,floor,boss,ENEMY_TYPES,r);assert(t.name&&t.hp>0&&t.atk>0&&t.skills1653.length===3);if(boss&&dgFinal1653(s,floor)&&s.catalog1653!==63)assert.equal(t.name,s.bossName);profiles++;}}}}
for(let f=5;f<=295;f+=5)assert.equal(dgEnemy1653(sites[59],f,true,ENEMY_TYPES).name,DG_CATALOG1653[f/5-1][4]);
for(let f=1;f<500;f++)assert.equal(dgBossFloor1653(sites[64],f),f%5===0);
console.log('77 entrances, deterministic dry placement with settlement clearance; '+layouts+' connected layouts, '+profiles+' themed enemy profiles, fixed final bosses, infinite and final boss sequence.');`,{assert,console});
const runtime=cut('  const DUNGEON_TILE=','  /* ---- Hedgehog statue');
const mock=b.slice(b.indexOf('const mock=`')+12,b.indexOf('`;\nvm.runInNewContext(mock+'));
vm.runInNewContext(mock+cut('  function exploration1655e','  function mapGate1655e')+cut('/* MOB1621-BEGIN */','/* MOB1621-END */')+runtime+`
const save15=()=>{};let online=false;const NetworkTransport={isOpen:()=>online};const sites=dgMakeSites1653();ENEMY_TYPES.push(...Array.from({length:12},()=>model));
for(const s of sites){const st=DG_STYLE1653[s.style1653];s.theme=DG_THEMES.length;DG_THEMES.push({n:s.name,floor:st[0],wall:st[1],trim:st[2],light:st[3]});}
player.lvl=200;playerMesh.position.set(12,0,20);const h=sites[63];enterDungeon(h);assert(inDungeon);assert.equal(enemies.length,1);const god=enemies[0];assert.equal(god.name,'Бог Ёж');assert.equal(god.hp,999);assert.equal(god.def1653,99);playerMesh.position.copy(dg.gate.pos);dgNearest().f();assert(inDungeon);assert.equal(dungeonFloor,1);spawnStairs();dgNearest().f();assert(!inDungeon);assert.equal(enemies.length,0);assert.equal(playerMesh.position.x,12);
const s=sites[0];enterDungeon(s);dungeonFloor=25;buildDungeonFloor();assert(enemies.some(e=>e.name==='Королева Крыс'&&e.isBoss));assert(enemies.some(e=>s.roster.some(r=>e.name===r[0])));playerMesh.position.copy(dg.gate.pos);spawnStairs();dgNearest().f();assert(!inDungeon);assert.equal(enemies.length,0);online=true;enterDungeon(s);assert(!inDungeon);console.log('Runtime mock: final gate, hedgehog stats, themed monsters, cleanup and online guard OK.');`,{assert,console});
