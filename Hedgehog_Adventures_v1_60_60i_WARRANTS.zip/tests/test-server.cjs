process.chdir(require("node:path").resolve(__dirname,".."));
// Интеграционный тест сервера: админ-пароль, лимиты, проверка урона и репутации.
// Запуск: node test-server.cjs   (нужен npm install)
const { spawn } = require('child_process');
const path = require('path');
const WebSocket = require('ws');

const PW = 'test-secret-ёж';
let failed = 0;
const ok = (c, m) => { if (c) console.log('  ✓ ' + m); else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

function startServer(port, env) {
  return new Promise((resolve, reject) => {
    const p = spawn(process.execPath, [path.join(__dirname, '../server.js')], { env: { ...process.env, PORT: String(port), ...env } });
    let out = '';
    p.stdout.on('data', d => { out += d; if (out.includes('Админ-режим')) resolve({ p, out: () => out }); });
    p.stderr.on('data', d => { out += d; });
    p.on('error', reject);
    setTimeout(() => reject(new Error('сервер не запустился: ' + out)), 5000);
  });
}

function connect(port, room, nick) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket('ws://127.0.0.1:' + port);
    const c = { ws, msgs: [], id: null };
    c.send = (type, payload = {}) => ws.send(JSON.stringify({ v: 1, room, sender: c.id, type, payload, ts: Date.now() }));
    ws.on('message', raw => { const m = JSON.parse(raw); c.msgs.push(m); if (m.type === 'welcome') c.id = m.payload.id; });
    ws.on('open', () => { c.send('hello', { nick }); setTimeout(() => resolve(c), 150); });
    ws.on('error', reject);
  });
}
const of = (c, type) => c.msgs.filter(m => m.type === type);
const stateOf = (x, z) => ({ nick: 'x', x, y: 0, z, yaw: 0, zone: 'w', lvl: 1, attack: 10, int: 10, hp: 50 });
const CAP = 552; // 40 + max(10*6, (10*.55 + 10*1.8 + 1*2.5 + 6)*16)

(async () => {
  // ---------- сервер БЕЗ пароля ----------
  console.log('Сервер без ADMIN_PASSWORD');
  const s0 = await startServer(18082, { ADMIN_PASSWORD: '' });
  const n = await connect(18082, 'room0', 'Nopass');
  n.send('admin_auth', { password: '' }); n.send('admin_auth', { password: 'anything' });
  await sleep(200);
  ok(of(n, 'admin_result').length === 2 && of(n, 'admin_result').every(m => m.payload.ok === false && m.payload.reason === 'disabled'), 'админ-режим отключён, пустой и любой пароль отклоняются');
  n.ws.close(); s0.p.kill();

  // ---------- сервер С паролем ----------
  console.log('Сервер с ADMIN_PASSWORD');
  const s = await startServer(18081, { ADMIN_PASSWORD: PW });
  ok(!s.out().includes(PW), 'пароль не печатается в логе сервера');

  const host = await connect(18081, 'r1', 'Host');
  const other = await connect(18081, 'r1', 'Other');
  host.send('state', stateOf(0, 0)); other.send('state', stateOf(0, 0));
  host.send('world_init', { zone: 'w', entities: Array.from({ length: 6 }, (_, i) => ({ id: 'e' + i, name: 'Крыса' + i, x: 1, y: 0, z: 1, hp: 100000, maxHp: 100000, atk: 1 })) });
  await sleep(250);

  console.log('Админ-доступ');
  other.send('admin_cmd', { cmd: 'killall' }); await sleep(150);
  ok(of(other, 'system').some(m => /Нет доступа/.test(m.payload.text)) && of(host, 'enemy_killed').length === 0, 'killall без входа отклонён, враги живы');
  other.send('admin_auth', { password: 'неверный' }); await sleep(150);
  ok(of(other, 'admin_result').at(-1).payload.reason === 'bad', 'неверный пароль отклонён');

  console.log('Урон');
  other.send('action', { action: 'attack', targetId: 'e0', damage: 25000, verb: 'Удар' }); await sleep(150);
  const hit = of(host, 'enemy_hit').at(-1);
  ok(hit && hit.payload.damage === CAP, 'удар 25000 у героя 1 ур./атака 10/инт 10 урезан до ' + (hit && hit.payload.damage) + ' (потолок ' + CAP + ')');
  for (let i = 0; i < 40; i++) other.send('action', { action: 'attack', targetId: 'e0', damage: 25000 });
  await sleep(300);
  const e0 = of(host, 'enemy_hit').filter(m => m.payload.id === 'e0');
  const total = e0.reduce((a, m) => a + m.payload.damage, 0);
  ok(total < CAP * 13, 'всплеск 40 ударов по 25000 ограничен бюджетом (нанесено суммарно ' + total + ' вместо 1 000 000)');
  // AoE: 5 разных целей подряд без задержки
  const before = of(host, 'enemy_hit').length;
  await sleep(1200);
  host.send('state', stateOf(0,0)); other.send('state', stateOf(0,0)); await sleep(30);
  for (const id of ['e1', 'e2', 'e3', 'e4', 'e5']) other.send('action', { action: 'attack', targetId: id, damage: 50 });
  await sleep(250);
  ok(of(host, 'enemy_hit').length - before === 5, 'AoE по 5 целям за один кадр засчитан полностью');

  console.log('Репутация и характеристики');
  other.send('state', { ...stateOf(0, 0), reputation: { 'Орден Золотого Льва': 0 }, lvl: 9999, attack: 9999999, int: 99999 }); await sleep(120);
  other.send('state', { reputation: { 'Орден Золотого Льва': 3000 } }); await sleep(150);
  const st = of(host, 'state').filter(m => m.sender === other.id).at(-1).payload;
  ok(st.reputation['Орден Золотого Льва'] <= 1500, 'рост репутации 0→3000 за раз урезан до ' + st.reputation['Орден Золотого Льва']);
  ok(st.lvl === 9999 && st.attack <= 5000 + st.lvl * 100 && st.int <= 50 + st.lvl * 5, 'заявленные уровень, атака и интеллект ограничены (lvl ' + st.lvl + ', атака ' + st.attack + ', инт ' + st.int + ')');

  console.log('Чат');
  const cb = of(host, 'chat').length;
  for (let i = 0; i < 10; i++) other.send('chat', { text: 'спам ' + i });
  await sleep(250);
  const got = of(host, 'chat').length - cb;
  ok(got <= 5 && got >= 1, 'спам из 10 сообщений ограничен лимитом (дошло ' + got + ')');

  console.log('Вход админа');
  const adm = await connect(18081, 'r1', 'Admin');
  adm.send('state', stateOf(0, 0));
  adm.send('admin_auth', { password: PW }); await sleep(150);
  ok(of(adm, 'admin_result').at(-1).payload.ok === true, 'верный пароль принят сервером');
  adm.send('admin_cmd', { cmd: 'killall' }); await sleep(250);
  ok(of(host, 'enemy_killed').length === 6 && of(host, 'enemy_killed').every(m => m.payload.xp === 0), 'админ: killall убил все 6 существ мира, без наград');
  adm.send('admin_logout'); adm.send('admin_cmd', { cmd: 'killall' }); await sleep(150);
  ok(of(adm, 'system').some(m => /Нет доступа/.test(m.payload.text)), 'после /admin off права сняты на сервере');

  console.log('Перебор пароля');
  const bf = await connect(18081, 'r2', 'Brute');
  for (let i = 0; i < 5; i++) bf.send('admin_auth', { password: 'x' + i });
  await sleep(200);
  bf.send('admin_auth', { password: PW }); await sleep(150);
  const last = of(bf, 'admin_result').at(-1).payload;
  ok(last.ok === false && last.reason === 'locked', 'после 5 неудачных попыток вход блокируется даже с верным паролем (' + last.reason + ')');

  [host, other, adm, bf].forEach(c => c.ws.close()); s.p.kill();
  console.log(failed ? '\nПРОВАЛЕНО: ' + failed : '\nOK — серверные проверки прошли.');
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
