const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>{const i=h.indexOf(a),j=h.indexOf(b,i+a.length);assert(i>=0&&j>i,a);return h.slice(i,j)};
vm.runInNewContext(`
let checks=0;class ChunkMap extends Map{has(k){checks++;return super.has(k)}}
const CHUNK=40,RADIUS=3,CG=12,colGrid=new Map(),chunks=new ChunkMap();let builds=0,disposals=0,scans=0;
const scene={remove(){}},GFX={disposeChunk(){disposals++}},document={getElementById(){return {textContent:''}}};
function ensureNearbyCities(){scans++}
function makeChunk(x,z){builds++;chunks.set(x+','+z,{biome:'лес',cols:[addCollider(x*CHUNK,z*CHUNK,3,5,0)]})}
${part('  function addCollider(','  function footOf(')}
${part('  function removeCampCols1614(','  function campClear156(')}
${part('  function dropChunk(','  function smoothRoad(')}
${part('  function updateChunks(','  /* ---- MODEL BUILDERS')}
updateChunks(0,0);assert.equal(builds,49);const first=colGrid.size;
for(let i=0;i<600;i++)updateChunks(0,0);assert.equal(builds,49);assert.equal(disposals,0);assert.equal(scans,601);assert.equal(checks,49);
const old=chunks.get('0,0').cols[0];dropChunk('0,0');assert(old.dead);assert(![...colGrid.values()].some(a=>a.includes(old)));updateChunks(0,0);assert.equal(builds,50);assert(chunks.has('0,0'));
for(let i=1;i<=100;i++){updateChunks(i*40,0);assert(chunks.size<=81);assert(colGrid.size<=first*3);assert([...colGrid.values()].every(a=>a.length&&!a.some(c=>c.dead)));}
updateChunks(-40000,20000);assert.equal(chunks.size,49);assert.equal(colGrid.size,first);console.log('Chunk lifecycle: 600 stationary updates, invalidation, 100 transitions, teleport, no dead colliders.');
`,{assert,console});
vm.runInNewContext(`
let unreg=0;const BLD={unregister(){unreg++}};const resource=()=>({n:0,dispose(){this.n++}});const shared=resource(),ownedG=resource(),ownedM=resource(),terrain=resource(),instance=resource();
const nodes=[{userData:{},geometry:shared,material:shared},{userData:{chunkGeometry1630:true,chunkMaterial1630:true},geometry:ownedG,material:ownedM},{userData:{chunkGeometry1630:true,chunkMaterial1630:true},geometry:ownedG,material:[ownedM]},{isInstancedMesh:true,userData:{},geometry:shared,dispose:()=>instance.dispose()}];
const root={traverse(fn){nodes.forEach(fn)}};
${part('  function disposeChunkGroup1630(','  return {U,G,MAT')}
disposeChunk({mesh:{geometry:terrain},group:root});assert.equal(shared.n,0);for(const r of [ownedG,ownedM,terrain,instance])assert.equal(r.n,1);assert.equal(unreg,1);console.log('Resource ownership: shared assets retained, owned assets deduplicated and freed.');
`,{assert,console});
