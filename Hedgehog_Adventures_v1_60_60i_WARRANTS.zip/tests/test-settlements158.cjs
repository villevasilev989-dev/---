process.chdir(require("node:path").resolve(__dirname,".."));
// Isolated generation test: actual parcel, entrance, paths and service code; geometry engine mocked.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const slice=(a,b)=>h.slice(h.indexOf(a),h.indexOf(b,h.indexOf(a)+a.length));
const house=slice('  // v1.14: persistent estate','  function buildingInterior('), coll=slice('  function addCollider(','  function clearZone('), village=slice('  function buildingInterior(','  /* ---- проработанный город'),city=slice('  function buildCityComplex(','  function buildMiniCity('),path=slice('  function residentClear(','  function residentDoorOccupied(');
let mock=fs.readFileSync(__dirname+'/test-walkin.cjs','utf8').split('const mock=`')[1].split('`;')[0];
mock+=`
V.prototype.clone=function(){return new V(this.x,this.y,this.z)};V.prototype.setScalar=function(s){return this.set(s,s,s)};
for(const k of ['SphereGeometry','ConeGeometry','OctahedronGeometry','MeshLambertMaterial','MeshBasicMaterial','MeshToonMaterial'])THREE[k]=G;
const fake=()=>new N(), buildMarket=fake,buildForge=fake,buildTavern=fake,buildTemple=fake,buildBank=fake,buildGuild=fake,buildTownHouse=fake,buildElfHouse=fake,buildFarmhouse=fake,buildMountainHut=fake,buildFishHut=fake,buildHut=fake,buildRoundTree=fake,buildFountain=fake,buildLamp=fake,buildPerson=fake,makeLabel=fake;
const HOUSE_BY_BIOME={},BLD={villageKinds:{},make:fake,makeProp:fake,pickKind:()=> 'town',PROP_POOLS:{town:['bench']}};
const PERSONALITIES=[{}], BS=2, CITY_MECH={}, CITY_CULTURES={}, scene=new N(),cityZones=[],clearZone2=()=>{},batchCityStatic=()=>{},lakeNear=()=>false,deepWater=()=>false, footOf=()=>[0,0,.4,.4],DIVINE_LOCAL={}, professionRole=()=> 'Фермер';
const originalOwners={'Тенеград':'Нейтралы','Тест Форт':'Легион Стали','Тест Порт':'Вольный Порт','Тест Роща':'Круг Друидов','Тест Шпиль':'Гильдия Магов'}; const factionForCity=c=>originalOwners[c]||'Нейтралы',cityCulture=()=>({leader:'Староста'});let menu=null;const openMenu=(title,build)=>{menu={title,build}},log=()=>{};
`;
// The mock already defines footOf after coll extraction, use the production version + geometry mock.
mock=mock.replace(', footOf=()=>[0,0,.4,.4]','');mock+=`THREE.Box3=class{setFromObject(){this.min={x:-.4,z:-.4};this.max={x:.4,z:.4};return this}};`;
vm.runInNewContext(mock+'const CHUNK=40,hashBiome=()=>"равнины";'+slice('  const settlementThemes1655h=','  function cityRuler(city)')+coll+house+path+village+city+`
function reset(){doors.length=0;settlementBoards158.length=0;colGrid.clear();scene.clear();for(const k of Object.keys(estateRecords))delete estateRecords[k];}
let vcount=0,ccount=0;
for(const b of ['равнины','леса','горы','пустыня','снега','болота','вулканы'])for(let i=0;i<8;i++){
 reset();const name='Деревня '+b+' '+i,g=buildVillage(b,1000,2000,name);const roles=g.userData.npcs.map(n=>n.name);for(const r of ['Торговец','Кузнец','Трактирщик','Жрец','Банкир','Глава гильдии'])assert(roles.includes(r),name+' '+r);assert.equal(doors.length,roles.length);assert.equal(settlementBoards158.length,1);for(const d of doors)assert(Number.isFinite(d.x+d.z+d.top)&&d.displayName&&d.W>0);const id=doors.map(estateId).join('|');reset();buildVillage(b,1000,2000,name);assert.equal(doors.map(estateId).join('|'),id);vcount++;
}
for(const name of Object.keys(originalOwners)){
 reset();const out=buildCityComplex(name,0x987654,1000,2000,9);for(const k of ['shop','craft','inn','temple','bank','guild'])assert(doors.some(d=>d.kind===k),name+' '+k);assert(out.npcs.length>=20);assert.equal(settlementBoards158.length,1);assert(doors.length>=12);const board=settlementBoards158[0];playerMesh.position.set(board.x,0,board.z);settlementBoardAction158(playerMesh.position).f();const rows=menu.build();assert(rows.some(q=>q.t.startsWith('Банк ·')));rows.find(q=>q.t.startsWith('Банк ·')).f();assert(settlementTarget158.name.startsWith('Банк ·'));ccount++;
}
console.log('Settlement generator: '+vcount+' villages / '+ccount+' cities; six services, deterministic estate IDs, finite doors and local directory verified (geometry mock, no WebGL).');
`,{assert,console});
