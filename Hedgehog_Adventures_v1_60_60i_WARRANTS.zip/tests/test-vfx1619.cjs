const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
const slice=(a,b)=>html.slice(html.indexOf(a),html.indexOf(b,html.indexOf(a)));
const mock=`
class V { constructor(x=0,y=0,z=0){this.set(x,y,z)} set(x,y,z){this.x=x;this.y=y;this.z=z;return this} copy(v){return this.set(v.x,v.y,v.z)} clone(){return new V(this.x,this.y,this.z)} add(v){return this.set(this.x+v.x,this.y+v.y,this.z+v.z)} sub(v){return this.set(this.x-v.x,this.y-v.y,this.z-v.z)} multiplyScalar(s){return this.set(this.x*s,this.y*s,this.z*s)} distanceTo(v){return Math.hypot(this.x-v.x,this.y-v.y,this.z-v.z)} lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z} length(){return Math.sqrt(this.lengthSq())} normalize(){const n=this.length()||1;return this.set(this.x/n,this.y/n,this.z/n)} setScalar(s){return this.set(s,s,s)} lerp(v,t){return this.lerpVectors(this,v,t)} lerpVectors(a,b,t){return this.set(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t)} }
let made=0,disposed=0;
class Mat {constructor(o){Object.assign(this,o);made++}dispose(){assert(!this.dead);this.dead=true;disposed++}}
class Geo {dispose(){throw Error('shared geometry disposed')}}
class N {constructor(g,m){this.geometry=g;this.material=m;this.children=[];this.position=new V();this.rotation=new V();this.scale=new V(1,1,1);this.userData={};this.quaternion={setFromUnitVectors:(a,b)=>assert(Number.isFinite(b.x+b.y+b.z))};}add(m){this.children.push(m)}traverse(f){f(this);this.children.forEach(c=>c.traverse(f))}}
const THREE={Vector3:V,Group:N,Mesh:N,MeshBasicMaterial:Mat,SphereGeometry:Geo,RingGeometry:Geo,CylinderGeometry:Geo,BoxGeometry:Geo,ConeGeometry:Geo};
const scene={items:[],add(n){this.items.push(n)},remove(n){this.items.splice(this.items.indexOf(n),1)}};
let gclock=0;const tones=[];function playTone(...args){tones.push(args);} let effectsEnabled=true, playerYaw=0;const playerMesh=new N();playerMesh.position.set(1,0,2);const cls={id:'mage'};const NetworkTransport={send(){}};
`;
const run=`
const defs=[];for(const [id,a] of Object.entries(CLASS_ABIL)){defs.push(a);CLASS_EXTRA[id].forEach(e=>defs.push({n:e[0],k:e[1],...e[2]}))}
assert.equal(defs.length,36);assert.equal(new Set(defs.map(d=>fxProfile1619(d).motifs[0])).size,36);for(const id of ['fireball','frost','meteor','whirl'])defs.push({id,k:id==='meteor'||id==='whirl'?'nova':'bolt'});
let generated=0;for(const id of Object.keys(CLASS_SKY)){for(const d of Object.values(getSkyNodes(id).spells)){defs.push(d);generated++;}}
for(const [id,a] of Object.entries(CLASS_ABIL)){const d={...a,id:'secondary_'+id};assert.equal(fxProfile1619(d).motifs[0],fxProfile1619(a).motifs[0]);defs.push(d);}
defs.push({id:'custom_test',k:'chain',tags:['ice','storm','fire'],color:'#af85eb'});
assert.equal(new Set(defs.map(d=>fxProfile1619(d).seed)).size,defs.length);
const enemies=Array.from({length:5},(_,i)=>{const mesh=new N();mesh.position.set(i+4,0,i+3);return {mesh}});
for(const d of defs){const p=fxProfile1619(d);assert(p.motifs.length&&p.motifs.every(m=>FX_SHAPE1619[m]));assert(Number.isFinite(p.color));assert.equal(fxProfile1619(d).seed,p.seed);fxAbility1619(d,enemies,new V(0,0,0));assert.equal(fxList.length,1);assert(playerMesh.userData.cast>0);const f=fxList[0];assert(f.mesh.children.length>0);for(let i=0;i<30;i++){fxUpdate(.05);for(const n of f.mesh.children){for(const v of [n.position,n.scale,n.rotation])assert(Number.isFinite(v.x+v.y+v.z),d.id||d.n);assert(n.material.opacity>=0&&n.material.opacity<=1);}}assert.equal(fxList.length,0);assert.equal(scene.items.length,0);}
for(let i=0;i<100;i++)fxAbility1619({id:'meteor',k:'nova',R:10},enemies);
assert(fxList.reduce((n,f)=>n+f.mesh.children.length,0)<=1100);while(fxList.length)fxUpdate(.1);
effectsEnabled=false;fxAbility1619(defs[0],[]);assert.equal(fxList.length,0);const rejected=new N(fxGeoS,fxMat(0));fxAdd(rejected,1);assert(rejected.material.dead);
effectsEnabled=true;fxAbility1619(defs[0],[]);effectsEnabled=false;fxUpdate(.01);assert.equal(fxList.length,0);assert.equal(made,disposed);
effectsEnabled=true;
const snapshots=[];for(const combo of [1,2,3]){combatFx1620('slash',new V(2,0,3),.6,combo);fxUpdate(.1);snapshots.push(JSON.stringify(fxList[0].mesh.children.map(n=>n.position)));while(fxList.length)fxUpdate(.1);}
assert.equal(new Set(snapshots).size,3);
for(const kind of ['block','parry','crit','death','hit','dodge']){combatFx1620(kind,new V(0,1,2));assert.equal(fxList.length,1);const f=fxList[0];while(fxList.length){fxUpdate(.05);for(const n of f.mesh.children){for(const v of [n.position,n.scale,n.rotation])assert(Number.isFinite(v.x+v.y+v.z));assert(n.material.opacity>=0&&n.material.opacity<=1);}}}
effectsEnabled=false;combatFx1620('death',new V());assert.equal(fxList.length,0);assert.equal(scene.items.length,0);assert.equal(made,disposed);
console.log('Combat1620: three distinct combo traces, six reaction profiles, disabled effects and cleanup verified.');
console.log('VFX1619: 36 distinct class motifs, 4 legacy skills/ultimates, '+generated+' generated spells, 12 secondary paths and a fusion sample; finite transforms, cleanup and disabled effects verified with mock Three.js.');
`;
vm.runInNewContext(mock+slice('const CLASS_ABIL={','const RACES=')+slice('  const CLASS_EXTRA={','  function scaleAb')+slice('  const SKY_C=','  // Слой совместимости:')+slice('  const FX_COL=','  function netEnemyFollow')+slice('  /* MOB1621-BEGIN */','  function enemyTypesFor(biome)')+`const log=()=>{};`+run+`
effectsEnabled=true;const distinct=new Set();for(const [key,a] of Object.entries(MOB_SKILLS1621)){
 const e={mesh:new N(),hp:100,special1621:key,aim1621:new V(4,0,5)};enemies.push(e);
 gclock+=1;mobWarning1621(e,key,e.aim1621);assert.equal(e.wind,a.wind);assert.equal(e.specialCd1621,a.cd);
 while(fxList.length)fxUpdate(.1);
 gclock+=1;mobImpact1621(e,a);fxUpdate(.1);const g=fxList.find(f=>f.mesh.children.length>0);assert(g);distinct.add(JSON.stringify(g.mesh.children.map(m=>m.position)));
 while(fxList.length)fxUpdate(.1);
 enemies.pop();
}assert.equal(distinct.size,8);assert.equal(tones.length,16);assert.equal(scene.items.length,0);assert.equal(made,disposed);
console.log('Enemy VFX1621: eight distinct impact patterns and warning/impact cleanup (mock).');
`,{assert,console});
