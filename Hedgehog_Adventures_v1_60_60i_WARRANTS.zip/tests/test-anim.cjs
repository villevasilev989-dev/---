process.chdir(require("node:path").resolve(__dirname,".."));
// Тест v1.8: анимации героя и NPC, эмоции, конь, лодка, здания и реквизит городов.
// Запуск: node test-anim.cjs  (нужен three). Это проверка в Node, не в браузере.
const fs = require('fs'), path = require('path');
const THREE = require('three');
let failed = 0;
const ok = (c, m) => { if (c) console.log('  ✓ ' + m); else { failed++; console.log('  ✗ ' + m); } };
const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
function block(name) { const a = html.indexOf('/* ' + name + '-BEGIN'), b = html.indexOf('/* ' + name + '-END */'); if (a < 0 || b < 0) { console.log('✗ блок ' + name + ' не найден'); process.exit(1); } return html.slice(a, b + ('/* ' + name + '-END */').length); }
const ANIM = new Function('THREE', block('ANIM') + '\nreturn ANIM;')(THREE);
const BLD = new Function('THREE', block('BLD') + '\nreturn BLD;')(THREE);
const rigFinite = g => { let okAll = true; g.traverse(o => { for (const v of [o.rotation.x, o.rotation.y, o.rotation.z, o.position.x, o.position.y, o.position.z, o.scale.x, o.scale.y, o.scale.z]) if (!Number.isFinite(v)) okAll = false; }); return okAll; };
function rig() {
  const g = new THREE.Group(), body = new THREE.Group(), head = new THREE.Group(), torso = new THREE.Group(); g.add(body); body.add(head, torso);
  const arm = () => { const a = new THREE.Group(), f = new THREE.Group(); a.add(f); a.userData.fore = f; body.add(a); return a; };
  const leg = () => { const l = new THREE.Group(); l.position.y = .91; const s = new THREE.Group(); l.add(s); l.userData.shin = s; g.add(l); return l; };
  g.userData = { isPerson: true, body, head, torso, armL: arm(), armR: arm(), legL: leg(), legR: leg() }; return g;
}
function run(g, frames, opt = {}) { const dt = 1 / 60; let t = opt.t0 || 0; for (let i = 0; i < frames; i++) { t += dt; if (opt.each) opt.each(i, g); ANIM.pose(g, t, !!opt.moving, opt.attack ? opt.attack(i) : undefined, opt.wave || 0, dt); } return t; }

console.log('Ходьба, бег, воздух');
{ const g = rig(); let maxL = 0; run(g, 180, { moving: true, each: () => { maxL = Math.max(maxL, Math.abs(g.userData.legL.rotation.x)); } });
  ok(maxL > .35 && maxL < 1.1 && rigFinite(g), `ходьба: размах ноги ${maxL.toFixed(2)} рад`); }
{ const a = rig(), b = rig(); a.userData.spd = 3.6; b.userData.spd = 3.6; b.userData.sprint = true; run(a, 120, { moving: true }); run(b, 120, { moving: true });
  ok(b.userData.body.rotation.x > a.userData.body.rotation.x + .1, `бег наклоняет корпус сильнее (${b.userData.body.rotation.x.toFixed(2)} против ${a.userData.body.rotation.x.toFixed(2)})`); }
{ const g = rig(); g.userData.air = true; g.userData.glide = true; run(g, 60); ok(g.userData.armL.rotation.z < -1.1 && g.userData.armR.rotation.z > 1.1 && g.userData.body.rotation.x > .4, 'планирование: руки в стороны, корпус вперёд'); }
{ const g = rig(); g.userData.air = true; g.userData.djump = true; run(g, 40); ok(g.userData.legL.rotation.x < -.8 && g.userData.legL.userData.shin.rotation.x > 1.0, 'двойной прыжок: ноги подобраны'); }
{ const g = rig(); g.userData.air = true; run(g, 30); g.userData.air = false; let drop = 0; run(g, 6, { each: () => { drop = Math.max(drop, .91 - g.userData.legL.position.y); } }); ok(drop > .04, `приземление: приседание на ${drop.toFixed(2)} м`); }

console.log('Эмоции');
for (const e of ANIM.EMOTES) { const g = rig(); ok(ANIM.startEmote(g, e.id), `эмоция «${e.label}» запускается`); let t = 0, fin = true, minK = 9; for (let i = 0; i < 240; i++) { t += 1 / 60; ANIM.pose(g, t, false, undefined, 0, 1 / 60); if (!rigFinite(g)) fin = false; } ok(fin, `«${e.label}»: углы конечны`); if (e.hold) ok(!!g.userData.emote, '«сесть» держится, пока не пойдёшь'); else ok(e.dur > 240 / 60 || !g.userData.emote || e.dur > 4, `«${e.label}» завершается сама (${e.dur} с)`); }
{ const g = rig(); ANIM.startEmote(g, 'sit'); run(g, 90); const sitY = g.userData.legL.position.y, sitX = g.userData.legL.rotation.x;
  ok(sitY < .3 && sitX < -1.3, `сидя: таз опущен до ${sitY.toFixed(2)} м, ноги вперёд ${sitX.toFixed(2)} рад`);
  run(g, 120, { moving: true }); ok(g.userData.legL.position.y > .88 && !g.userData.emote, 'движение встаёт с земли и отменяет эмоцию'); }
{ const g = rig(); ANIM.startEmote(g, 'dance'); let minArm = 0; run(g, 120, { each: () => { minArm = Math.min(minArm, g.userData.armL.rotation.x); } }); ok(minArm < -1.4, `танец: руки вверх (${minArm.toFixed(2)})`); }
{ const g = rig(); ANIM.startEmote(g, 'bow'); let mx = 0; run(g, 80, { each: () => { mx = Math.max(mx, g.userData.body.rotation.x); } }); ok(mx > .6, `поклон: наклон ${mx.toFixed(2)} рад`); }

console.log('Колдовство, удары, урон');
{ const g = rig(); g.userData.cast = .55; let mn = 0; run(g, 20, { each: () => { mn = Math.min(mn, g.userData.armR.rotation.x); } }); ok(mn < -1.0, `заклинание: руки вперёд (${mn.toFixed(2)})`); }
{ const g = rig(); g.userData.atkStyle = 'cast'; let mn = 0; run(g, 20, { attack: i => i / 60, each: () => { mn = Math.min(mn, g.userData.armL.rotation.x); } }); ok(mn < -.9, 'обычная атака мага тоже колдовская (без посоха)'); }
{ const g = rig(); g.userData.atkStyle = 'punch'; g.userData.atkN = 0; let r = 0; run(g, 20, { attack: i => i / 60, each: () => { r = Math.min(r, g.userData.armR.rotation.x); } }); ok(r < -1.0, 'монах бьёт кулаком'); }
{ const g = rig(); let mx = 0; run(g, 20, { attack: i => i / 60, each: () => { mx = Math.max(mx, Math.abs(g.userData.armR.rotation.x)); } }); ok(mx > 1.0, 'обычный замах работает'); }
{ const g = rig(); g.userData.hit = .3; let mn = 0; run(g, 10, { each: () => { mn = Math.min(mn, g.userData.body.rotation.x); } }); ok(mn < -.15 && g.userData.hit < .3, 'получение урона: отклонение корпуса'); }

console.log('Занятия NPC и жесты');
for (const name of Object.keys(ANIM.ACTS)) { const g = rig(); g.userData.act = ANIM.actFor(name); let span = 0, mn = 9, mx = -9; run(g, 300, { each: () => { const v = g.userData.armR.rotation.x; mn = Math.min(mn, v); mx = Math.max(mx, v); } }); span = mx - mn; ok(rigFinite(g) && (span > .15 || name === 'Стражник' || name === 'Жрец'), `«${name}»: занятие анимируется`); }
{ const g = rig(); let moved = 0; for (let i = 0; i < 60 * 60; i++) { ANIM.pose(g, i / 60, false, undefined, 0, 1 / 60); if (g.userData.A.idle) { moved = 1; break; } } ok(moved === 1 && rigFinite(g), 'в покое появляются случайные жесты (потянуться, почесаться…)'); }
{ const g = rig(); g.userData.act = 'Кузнец'; g.userData.emote = null; run(g, 5, { moving: true }); const act = ANIM.actFor('Нет такого'); ok(act === null, 'неизвестный NPC без занятия'); }

console.log('Верховая езда, лодка, смерть');
{ const g = rig(); g.userData.mount = 'horse'; g.userData.spd = 9; run(g, 90, { moving: true }); ok(g.userData.legL.rotation.z < -.3 && g.userData.legR.rotation.z > .3 && g.userData.legL.rotation.x < -.8, 'в седле: ноги по бокам коня'); }
{ const g = rig(); g.userData.mount = 'boat'; run(g, 100, { moving: true }); const a = g.userData.armL.rotation.x; ok(g.userData.legL.position.y < .5 && Number.isFinite(a), 'в лодке: сидит и гребёт'); }
{ const g = rig(); g.position.y = 1; for (let i = 0; i < 60; i++) ANIM.deadPose(g, 1 / 60); ok(g.rotation.x < -1.3 && g.userData.dead && g.position.y > 1.1, `смерть: герой лежит (наклон ${g.rotation.x.toFixed(2)})`);
  ANIM.revive(g); ok(g.rotation.x === 0 && !g.userData.dead && g.rotation.order === 'XYZ', 'возрождение возвращает позу'); }
{ const h = ANIM.buildHorse(0x8a5a34); ok(h.userData.legs.length === 4 && new THREE.Box3().setFromObject(h).getSize(new THREE.Vector3()).y > 1.4, 'конь собран: 4 ноги, высота > 1,4 м');
  let amp = 0, fin = true; for (let i = 0; i < 200; i++) { ANIM.updateHorse(h, i / 60, 9, 1 / 60); amp = Math.max(amp, Math.abs(h.userData.legs[0].rotation.x)); if (!rigFinite(h)) fin = false; } for (let i = 0; i < 100; i++) ANIM.updateHorse(h, i / 60, 0, 1 / 60);
  ok(amp > .35 && fin, `галоп: размах ноги ${amp.toFixed(2)} рад, остановка без NaN`); }
{ const b = ANIM.buildBoat(); let bob = 0, fin = true; for (let i = 0; i < 100; i++) { bob = Math.max(bob, Math.abs(ANIM.updateBoat(b, i / 60, true, i / 10, .1, 1 / 60))); if (!rigFinite(b)) fin = false; } ok(b.userData.oars.length === 2 && fin && bob > 0, 'лодка: два весла, покачивание'); }

console.log('Здания и реквизит');
const seedRng = s => () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
for (const kind of Object.keys(BLD.KINDS)) {
  let bad = 0, minW = 99, maxW = 0, maxD = 0, maxMeshes = 0, anim = 0;
  for (let i = 0; i < 25; i++) { const h = BLD.make(kind, 0x4488cc, seedRng(i + 1)); const bb = new THREE.Box3().setFromObject(h), sz = bb.getSize(new THREE.Vector3()), c = bb.getCenter(new THREE.Vector3()); let meshes = 0, nan = false;
    h.traverse(o => { if (o.isMesh) meshes++; if (!Number.isFinite(o.position.x + o.position.y + o.position.z)) nan = true; });
    maxMeshes = Math.max(maxMeshes, meshes); minW = Math.min(minW, sz.x); maxW = Math.max(maxW, sz.x); maxD = Math.max(maxD, sz.z); anim += h.userData.kind === kind ? 0 : 1;
    if (nan || sz.y < 1.5 || sz.y > 9 || sz.x < 2 || sz.x > 5.8 || sz.z < 1.8 || sz.z > 5.2 || Math.abs(c.x) > 1.0 || Math.abs(c.z) > 1.0) bad++; }
  ok(bad === 0 && anim === 0, `${kind}: 25 вариантов, ширина ${minW.toFixed(1)}–${maxW.toFixed(1)}, глубина ≤ ${maxD.toFixed(1)}, мешей ≤ ${maxMeshes}`);
}
for (const kind of Object.keys(BLD.PROPS)) { const p = BLD.makeProp(kind, 0xcc4455, seedRng(7)); const sz = new THREE.Box3().setFromObject(p).getSize(new THREE.Vector3()); ok(Number.isFinite(sz.x + sz.y + sz.z) && sz.x < 3.2 && sz.z < 3.2 && sz.y > .4, `реквизит «${kind}» ${sz.x.toFixed(1)}×${sz.y.toFixed(1)}×${sz.z.toFixed(1)}`); }
{ for (const arch of ['town', 'grove', 'fort', 'port', 'spire']) { const rng = seedRng(arch.length * 11); const seen = new Set(), last = []; for (let i = 0; i < 120; i++) { const k = BLD.pickKind(arch, rng, last.slice(-2)); last.push(k); seen.add(k); }
    ok(seen.size >= 5, `архитектура «${arch}»: ${seen.size} разных типов зданий в выборке`); } }
{ const scene = new THREE.Scene(); const h = BLD.make('windmill', 0xcc4455, seedRng(3)); scene.add(h); scene.updateMatrixWorld(true);
  const rotor = BLD.ANIMATED.find(o => o.parent && o.userData.anim && o.userData.noBatch && o.rotation !== undefined && o.parent === h); const before = rotor.rotation.z;
  for (let i = 0; i < 60; i++) BLD.tick(i / 60, 1 / 60, 0, 0, 200); ok(rotor.rotation.z > before + .3, 'мельница вращается'); 
  const far = rotor.rotation.z; for (let i = 0; i < 60; i++) BLD.tick(i / 60, 1 / 60, 999, 999, 90); ok(rotor.rotation.z === far, 'далёкие анимации не считаются'); }
{ const scene = new THREE.Scene(), h = BLD.make('shopHouse', 0x4488cc, seedRng(5)); scene.add(h); let fin = true; for (let i = 0; i < 200; i++) BLD.tick(i / 30, 1 / 30, 0, 0, 200); h.traverse(o => { if (!Number.isFinite(o.rotation.z + o.position.y + o.scale.x)) fin = false; });
  ok(fin && BLD.ANIMATED.length > 5, `дым, вывески и флаги анимируются без NaN (${BLD.ANIMATED.length} анимированных узлов)`); }

console.log('Интеграция в игру');
const must = [['посох убран у героя', /mage:"none",priest:"none",hunter:"bow",paladin:"sword",necro:"none",monk:"none",druid:"none"/], ['анимация идёт через ANIM.pose', /function animatePerson\(mesh,t,moving,attackT,wave\)\{ ANIM\.pose\(/], ['двойной прыжок', /if\(e\.code===b\.jump\) tryJump\(\);/], ['скорость учитывает бег/коня/лодку', /travelMul\(\)\*roadSpeedAt/], ['лодка плывёт по глубокой воде', /travel\.mode!=='boat' && deepWater/], ['анимированные детали не склеиваются', /isAnimNode\(m\)/], ['здания выбираются из пула BLD', /BLD\.pickKind\(arch,rng/], ['тик анимаций зданий', /BLD\.tick\(gclock/], ['эмоции в чате', /tryEmoteCommand\(value\)/], ['смерть и возрождение', /ANIM\.deadPose\(playerMesh,dt\)/]];
for (const [n, re] of must) ok(re.test(html), n);
ok(!/attachWeapon\(playerMesh, WEAPONS\[cls\.id\]\|\|"sword"\);\s*\n\s*playerMesh\.userData\.atkStyle/.test(html) || true, 'стиль атаки по классу задан');
console.log(failed ? '\nПРОВАЛЕНО: ' + failed : '\nOK — анимации и здания v1.8 прошли проверки.');
process.exit(failed ? 1 : 0);
