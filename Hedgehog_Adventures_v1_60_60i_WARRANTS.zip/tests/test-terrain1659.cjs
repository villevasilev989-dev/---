const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>h.slice(h.indexOf(a),h.indexOf(b,h.indexOf(a)));
const {lakeAmt,oldLake,resolveCollide,oldCollide,colGrid}=vm.runInNewContext(`const CG=12,colGrid=new Map();
  function oldLake(x,z){
    const cs=360, ix=Math.floor(x/cs), iz=Math.floor(z/cs); let m=0;
    for(let a=-1;a<=1;a++) for(let b=-1;b<=1;b++){
      const jx=ix+a, jz=iz+b, h=Math.sin(jx*91.3+jz*47.7)*43758.5453, f=h-Math.floor(h);
      if(f<0.45){
        const h2=Math.sin(jx*12.9+jz*78.2)*43758.5453, f2=h2-Math.floor(h2), h3=Math.sin(jx*39.1+jz*5.7)*43758.5453, f3=h3-Math.floor(h3);
        const d=Math.hypot(x-(jx+0.25+f2*0.5)*cs, z-(jz+0.25+f3*0.5)*cs), r=45+f*100;
        if(d<r){ const t=1-d/r; m=Math.max(m,t*t*(3-2*t)); }
      }
    }
    return m;
  }
  function oldCollide(p,r){
    const a=colGrid.get(Math.floor(p.x/CG)+','+Math.floor(p.z/CG)); if(!a) return;
    for(let i=a.length-1;i>=0;i--){
      const b=a[i]; if(b.dead){ a.splice(i,1); continue; }
      const dx=p.x-b.x, dz=p.z-b.z, lx=dx*b.c-dz*b.s, lz=dx*b.s+dz*b.c;
      const cx=Math.max(-b.hw,Math.min(b.hw,lx)), cz=Math.max(-b.hd,Math.min(b.hd,lz));
      const ox=lx-cx, oz=lz-cz, d2=ox*ox+oz*oz;
      if(d2>=r*r) continue;
      let nx,nz;
      if(d2>1e-8){ const d=Math.sqrt(d2); nx=lx+ox/d*(r-d); nz=lz+oz/d*(r-d); }
      else if(b.hw-Math.abs(lx) < b.hd-Math.abs(lz)){ nx=(lx>=0?1:-1)*(b.hw+r); nz=lz; }
      else { nx=lx; nz=(lz>=0?1:-1)*(b.hd+r); }
      p.x=b.x+nx*b.c+nz*b.s; p.z=b.z-nx*b.s+nz*b.c;
    }
  }
${part('  function lakeAmt(x,z){','  function lakeNear')}
${part('  function resolveCollide(p,r){','  function clearZone')}
;({lakeAmt,oldLake,resolveCollide,oldCollide,colGrid})`);
let seed=123456;const rng=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
for(let i=0;i<30000;i++){const x=(rng()-.5)*200000,z=(rng()-.5)*200000;assert.equal(lakeAmt(x,z),oldLake(x,z));}
for(let i=-12;i<=12;i++)for(let j=-12;j<=12;j++)for(const dx of [-1e-8,0,1e-8,180])assert.equal(lakeAmt(i*360+dx,j*360),oldLake(i*360+dx,j*360));
assert(lakeAmt.cache1659.size<=256);
for(let i=0;i<5000;i++){const p={x:rng()*12,z:rng()*12},q={...p},r=rng()*2+.01;const list=Array.from({length:40},()=>{const th=rng()*Math.PI*2;return {x:(rng()-.25)*24,z:(rng()-.25)*24,hw:rng()*8,hd:rng()*8,c:Math.cos(th),s:Math.sin(th),dead:rng()<.1}});colGrid.set('0,0',list.slice());oldCollide(p,r);colGrid.set('0,0',list.slice());resolveCollide(q,r);assert.deepEqual(q,p);}
const points=Array.from({length:120000},()=>[45+rng()*120,45+rng()*120]);
function bench(fn){let sum=0;const t=process.hrtime.bigint();for(const [x,z] of points)sum+=fn(x,z);return {ms:Number(process.hrtime.bigint()-t)/1e6,sum};}
const a=bench(oldLake),b=bench(lakeAmt);assert.equal(a.sum,b.sum);console.log('PASS: 32500 lake comparisons; 5000 collision scenarios; bounded cache. Local synthetic benchmark ms: old='+a.ms.toFixed(1)+', new='+b.ms.toFixed(1));
