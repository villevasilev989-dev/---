const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/server.js','utf8'),h=fs.readFileSync(root+'/index.html','utf8');
const events=[];let seq=0;const ctx={broadcast:(r,t,p)=>events.push({t,p}),sendTo:(peer,r,t,p)=>events.push({to:peer.id,t,p}),rid:()=>String(++seq)};vm.createContext(ctx);vm.runInContext(s.slice(s.indexOf('const NET_SKILLS1637='),s.indexOf('setInterval(()=>{for(const room of rooms.values())tickMobAttacks1637')),ctx);
const mob={id:'m',x:0,y:0,z:0,hp:100,maxHp:100,atk:20,skills:['fire']};const peer=(id,x)=>({id,stateAt:10000,state:{zone:'w',hp:100,x,y:0,z:0}});const a=peer('a',5),b=peer('b',6),c=peer('c',30);const room={hostId:'a',worldReady:true,worldAt:10000,peers:new Map([['a',a],['b',b],['c',c]]),entities:new Map([['m',mob]])};
const tick=t=>{room.worldAt=t;for(const p of room.peers.values())p.stateAt=t;ctx.tickMobAttacks1637(room,t,()=>0);};
tick(10000);tick(12000);assert.equal(events[0].t,'mob_warning');assert.equal(events[0].p.center.x,5);a.state.x=20;tick(13299);assert.equal(events.length,1);tick(13300);assert.equal(events.filter(e=>e.t==='mob_damage').length,1);assert.equal(events.find(e=>e.t==='mob_damage').to,'b');assert.equal(events.find(e=>e.t==='mob_damage').p.damage,33);tick(13400);assert.equal(events.length,3);tick(23300);assert.equal(events.length,4);room.entities.delete('m');tick(24600);assert.equal(events.length,5);assert.equal(events.at(-1).t,'mob_cancel');assert.equal(room.mobCasts.size,0);
room.entities.set('m',mob);tick(25000);tick(27000);assert.equal(events.length,6);a.state.zone='d1';tick(28300);assert.equal(events.length,7);assert.equal(events.at(-1).t,'mob_cancel');assert.equal(room.mobCasts.size,0);
assert(h.includes("if(packet.sender==='server')netMobEvent1637"));assert(h.includes('netMobSeen1637.has(d.castId)'));
console.log('COOP1637: server warnings, fixed area, evasion, damage once, cooldown, death and host zone cancellation');

assert(s.includes('setInterval(()=>{for(const room of rooms.values())tickMobAttacks1637(room);},20);'));
console.log('COOP1638: 20 ms scheduler interval');

// Host migration or stale world cancels pending casts without an impact.
a.state.zone='w';tick(30000);tick(32000);const before=events.length;ctx.cancelMobCasts1639(room);assert.equal(events.length,before+1);assert.equal(events.at(-1).t,'mob_cancel');assert.equal(room.mobCasts.size,0);
assert(h.includes("netMobWarnings1639.delete(d.castId)"));assert(s.includes('room.worldAt=0; cancelMobCasts1639(room);'));
console.log('COOP1639: cancellation packets and host migration guard');
// Client cancellation actually terminates the warning on the next FX update.
vm.runInNewContext(h.slice(h.indexOf('const netMobSeen1637='),h.indexOf('function receiveNetPacket('))+`
let fx,zone='w',open=true;const enemies=[{id:'m',hp:100}],MOB_SKILLS1621={fire:{color:1,radius:3,wind:1.3}},NetworkTransport={isOpen:()=>open},netZone=()=>zone,effectsEnabled=true,fxGeoR={},fxMat=()=>({}),mobSound1623=()=>{},fxRing=()=>{};
const THREE={Vector3:class{constructor(x,y,z){Object.assign(this,{x,y,z})}},Mesh:class{constructor(g,m){this.material=m;this.rotation={};this.position={copy(v){this.y=v.y}};this.scale={setScalar(){}}}}};
function fxAdd(mesh,life,upd){fx={mesh,life,t:0};fx.upd=upd;}
const d={id:'m',key:'fire',castId:'a',center:{x:0,y:0,z:0}};
netMobEvent1637('mob_warning',d);assert.equal(netMobWarnings1639.size,1);fx.upd(fx);assert.equal(fx.t,0);netMobEvent1637('mob_cancel',d);fx.upd(fx);assert.equal(fx.t,fx.life);assert.equal(netMobWarnings1639.size,0);
netMobEvent1637('mob_warning',d);open=false;fx.upd(fx);assert.equal(fx.t,fx.life);assert.equal(netMobWarnings1639.size,0);
`,{assert});
console.log('COOP1639: client warning cancellation and disconnect cleanup');
