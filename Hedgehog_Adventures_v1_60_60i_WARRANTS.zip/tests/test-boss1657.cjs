const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(h.split('/* MOB1621-BEGIN */')[1].split('/* MOB1621-END */')[0]+`
for(const [name,[key,label,mul,adds]] of Object.entries(BOSS_SIGNATURE1657)){
 const e={name,isBoss:true,isDungeon:true,catalogBoss1657:true,skills1621:['claw','slam','roar'],hp:100,maxHp:100,level1621:10,specialCd1621:0};
 bossInit1657(e);assert(e.skills1621.includes(key));assert.equal(e.skills1621.length,3);assert.equal(bossLabel1657(e,key),label);assert.equal(bossPower1657(e,key),mul);assert.equal(bossProfile1657(e).adds,adds);
 assert.equal(mobSelect1621(e,1,()=>0),key);e.hp=20;assert.equal(mobPhase1622(e),3);e.specialCd1621=0;assert.equal(mobSelect1621(e,1,()=>.6),key);assert.equal(mobSelect1621(e,100,()=>0),null);
 e.name='Аспект: '+name;assert.equal(bossProfile1657(e).key,key);e.isDungeon=false;assert.equal(bossProfile1657(e),null);assert.equal(bossPower1657(e,key),1);
}
const e={name:'Другое',isBoss:true,isDungeon:true,catalogBoss1657:true,skills1621:['fire','slam','roar']};assert.equal(bossProfile1657(e).key,'fire');
assert.equal(BOSS_SIGNATURE1657['Бог Ёж'][3],0);console.log('62 signature profiles, phase preference, range, aspects, fallback and sanctuary guard OK');`,{assert,console});
assert(h.includes('bossInit1657(e);}}enemies.push(e)'));assert(h.includes('bossPower1657(en,en.recoveryKey1623)'));assert(h.includes('bossProfile1657(en)?.adds??3'));
