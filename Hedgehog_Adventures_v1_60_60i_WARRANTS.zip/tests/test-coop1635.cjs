const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/server.js','utf8'),h=fs.readFileSync(root+'/index.html','utf8');
const cut=(s,a,b)=>{let i=s.indexOf(a),j=s.indexOf(b,i+a.length);assert(i>=0&&j>i);return s.slice(i,j)};
vm.runInNewContext(`const clean=(s,n)=>(typeof s==='string'?s:'').slice(0,n),num=(v,d)=>Number.isFinite(v)?v:d;`+cut(s,'function netMobProfile1635(','function leave(')+`
const e={id:'a',name:'mob',x:1,y:0,z:2,hp:100,maxHp:100,atk:4,boss:true,level:10001,skills:['fire','claw','claw','bad','roar','slam'],affinity:'fire'};
let r={entities:new Map(),killed:new Map()};assert(mergeWorld(r,[e]));let a=r.entities.get('a');assert.equal(a.level,10001);assert.equal(a.skills.join(','),'fire,claw,roar');assert.equal(a.affinity,'fire');a.hp=42;
assert(mergeWorld(r,[{...e,level:1,skills:['slam'],affinity:'frost'}]));a=r.entities.get('a');assert.equal(a.hp,42);assert.equal(a.level,10001);assert.equal(a.skills.join(','),'fire,claw,roar');assert.equal(a.affinity,'fire');
const malformed=sanitizeEntities([{...e,level:Infinity,skills:[{},null,'constructor'],affinity:'constructor'}])[0];assert.equal(malformed.level,1);assert.equal(malformed.skills.length,0);assert.equal(malformed.affinity,null);
markKilled(r,'a');assert(mergeWorld(r,[e]));assert.equal(r.entities.size,0);
`,{assert});
vm.runInNewContext(cut(h,'function netEnemySnapshot(','function removeNetEnemy(')+`
let netIsHost=true,inDungeon=false,houseCtx=null,calls=[];const NetworkTransport={isOpen:()=>true,send:(type,p)=>calls.push(p)};
const enemies=[{id:'a',mesh:{position:{x:1,y:0,z:2},scale:{x:1}},hp:45,maxHp:100,atk:4,level1621:103,skills1621:['fire'],affinity1622:'fire'},{id:'b',isDungeon:true},{id:'c',war:true}];
sendNetWorldSnapshot();assert.equal(calls.length,1);assert.equal(calls[0].entities.length,1);assert.equal(calls[0].entities[0].level,103);assert.equal(calls[0].entities[0].skills[0],'fire');inDungeon=true;sendNetWorldSnapshot();assert.equal(calls.length,1);inDungeon=false;houseCtx={};sendNetWorldSnapshot();assert.equal(calls.length,1);houseCtx=null;netIsHost=false;sendNetWorldSnapshot();assert.equal(calls.length,1);
`,{assert});
assert(h.includes("NetworkTransport.isOpen() && target.id){"));assert(h.includes('removeNetEnemy(d.id,true)'));assert(s.includes("peer.state?.zone!=='w'"));console.log('COOP1635: profile sanitization, immutable metadata, HP, tombstones, client snapshot and zone guards');
