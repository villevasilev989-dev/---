process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8'), base=fs.readFileSync(__dirname+'/test.cjs','utf8');
const runtime=html.slice(html.indexOf('  const DUNGEON_TILE='),html.indexOf('  /* ---- Hedgehog statue'));
const mock=base.slice(base.indexOf('const mock=`')+12,base.indexOf('`;\nvm.runInNewContext(mock+'));
const map=html.slice(html.indexOf("  function exploration1655e"),html.indexOf("  function mapGate1655e"));
vm.runInNewContext(mock+map+html.split("/* MOB1621-BEGIN */")[1].split("/* MOB1621-END */")[0]+runtime+`
THREE.TorusGeometry=Geo;THREE.CylinderGeometry=Geo;THREE.SphereGeometry=Geo;
const NetworkTransport={isOpen:()=>false},openMenu=(title,rows)=>{assert(rows().length>0);};
for(const spec of RUINS131){
 const d=ruinLayout(spec),target=dgKey(d.rooms[5].tx,d.rooms[5].tz);
 assert(dgPath(d.tiles,'0,0',target).length>0);
 for(const k of d.gateTiles)d.tiles.delete(k);
 assert.equal(dgPath(d.tiles,'0,0',target).length,0,spec.id+' gate bypass');
 for(const r of d.rooms.slice(0,5))if(r.id)assert(dgPath(d.tiles,'0,0',dgKey(r.tx,r.tz)).length>0);
 for(const input of [0,1,2]){const state={};if(input!==spec.order[0]){assert.equal(ruinPress(state,spec.order,input),'reset');assert(!state.solved);}}
 playerMesh.position.set(12,0,20);enterDungeon({name:spec.title,theme:spec.theme,level:6,mul:1,biomes:['test'],ruin:spec});assert(inDungeon);assert(!dg.key);assert(!dg.tiles.has(dg.gateTiles[1]));
 playerMesh.position.copy(dg.ruinPlaque);dgNearest().f();
 for(const i of spec.order){playerMesh.position.copy(dg.ruinControls[i].pos);dgNearest().f();}
 assert(ruinState(player,spec.id).solved);assert(dg.ruinDoor.visible===false);assert(dgPath(dg.tiles,'0,0',target).length>0);
 playerMesh.position.copy(dg.gate.pos);dgNearest().f();assert(!ruinState(player,spec.id).read);
 spawnStairs();dgNearest().f();assert(ruinState(player,spec.id).read);assert.equal(dungeonFloor,1);
 const site=activeSite;exitDungeon();player.ruins131=JSON.parse(JSON.stringify(player.ruins131));enterDungeon(site);assert(dg.key);assert(!enemies.some(e=>e.guardian));assert(dg.ruinDoor.visible===false);dgTick(.05);exitDungeon();assert.equal(enemies.length,0);
}console.log('Ruins: five physical layouts, gate isolation, wrong inputs, correct sequences, archive gating, reentry, serialization and cleanup OK (mock).');`,{assert,console});
