const fs=require('node:fs'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process'),path=require('node:path');
const root=path.resolve(__dirname,'..'),pkg=require('../package.json'),h=fs.readFileSync(path.join(root,'index.html'),'utf8');
assert(h.includes("const report={version:'"+pkg.version+"'"));assert(h.includes('id="buildVersion1561">v'+pkg.version));assert(h.includes('<title>Ежиные похождения v'+pkg.version));assert(h.includes('<h1>ЕЖИНЫЕ ПОХОЖДЕНИЯ</h1>'));assert(!h.includes('F8: /audit'));
for(const f of ['solo.js','server.js','prepare3d.js'])assert.equal(spawnSync(process.execPath,['--check',path.join(root,f)]).status,0,f);
for(const m of h.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)){const r=spawnSync(process.execPath,['--input-type='+(/type="module"/.test(m[1])?'module':'commonjs'),'--check'],{input:m[2],encoding:'utf8'});assert.equal(r.status,0,r.stderr);}
assert(fs.readFileSync(path.join(root,'solo.js'),'utf8').includes('undefined?8000:'));console.log('PASS coherent version and name, HUD, all script syntax, port 8000');
