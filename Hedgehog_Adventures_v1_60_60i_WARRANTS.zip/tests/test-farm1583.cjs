process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const slice=(a,b)=>{const i=h.indexOf(a),j=h.indexOf(b,i+a.length);assert(i>=0&&j>i);return h.slice(i,j)};
const code=slice('  /* FARM1591-BEGIN','  /* FARM1591-END');
vm.runInNewContext(code+`
let f={planted:null,lastDay:-1,harvested:0},stock={food:40},m={cash:50},p={alive:true,gold:7};
assert(farmWork1591(f,0,0,stock,m,p));assert.equal(stock.food,39);assert.equal(m.cash+p.gold,57);
assert(!farmWork1591(f,0,0,stock,m,p));assert(!farmWork1591(f,0,3,stock,m,p));assert(farmWork1591(f,0,4,stock,m,p));assert.equal(stock.food,47);assert(!farmWork1591(f,0,4,stock,m,p));
assert.equal(farmDaily1591(f,5,stock,0,false),0);assert.equal(farmDaily1591(f,6,stock,3,true),0);assert.equal(farmDaily1591(f,7,stock,3,false),3);assert.equal(stock.food,44);assert.equal(JSON.parse(JSON.stringify(f)).lastDay,7);console.log('Farm: active crop implementation, inputs, maturity, replay, payment, worker and blockade.');`,{assert,console});
const diplomacy=slice('  function autonomousDiplomacy157(','  /* DIPLOMACY157-END');
vm.runInNewContext(`const pair=(a,b)=>[a,b].sort().join('|'),warFaction=f=>f!=='Нейтралы',warDistance=(a,b,l)=>Math.abs(l.get(a).x-l.get(b).x);`+diplomacy+`
const r={day:7,relations:{},spy154:{incidents:{x:{attacker:'A',defender:'B',count:2,last:7}}}}; const loc=new Map([['X',{x:0}],['Y',{x:600}]]),owner=c=>c==='X'?'A':'B',relation=(a,b)=>r.relations[pair(a,b)]||0;let logs=[];const run=()=>autonomousDiplomacy157(r,loc,owner,relation,()=>({treasury:100}),t=>logs.push(t));assert(run());assert(r.treaties['A|B'].embargo);assert(!run());r.day=21;assert(!run());r.day=28;r.spy154.incidents.x.count=3;r.spy154.incidents.x.last=27;assert(run());assert.equal(r.relations['A|B'],-1);assert.equal(logs.length,2);console.log('Diplomacy: two recorded exposures => embargo; new exposure after cooldown => war; no war from passage of time alone.');`,{assert,console});
assert(h.includes('!NetworkTransport.isOpen()&&!crime148(player).custody&&!(realm.armies||[])'));
assert(h.includes('farmSeed1583();updateChunks'));assert(h.includes('if(typeof farmDay1583===\'function\')farmDay1583()'));assert(h.includes("n.workBuilding=null;n.workPoint.set(farm.x-parent.position.x"));assert(h.includes("n:'Каталог и исследовательский архив'"));assert(h.includes("concat(storyRows({city:d.city,name:'library'}))"));console.log('Runtime hooks: global farm setup, daily processing, farmer destination, physical library archive, existing story flow.');
