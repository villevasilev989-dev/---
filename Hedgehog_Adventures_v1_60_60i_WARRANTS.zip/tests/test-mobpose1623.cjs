const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(html.split('/* MOBPOSE1623-BEGIN */')[1].split('/* MOBPOSE1623-END */')[0]+`
const poses=new Set();
for(const key of Object.keys(MOB_POSES1623)){
 const e={mesh:{rotation:{x:0,y:1.5,z:0},userData:{}},special1621:key,wind:.2,windMax:1,stun:0};
 for(let i=0;i<20;i++)mobPose1623(e,.016);
 poses.add([e.mesh.rotation.x.toFixed(3),e.mesh.rotation.z.toFixed(3)].join(','));
 assert.equal(e.mesh.rotation.y,1.5);assert.ok(Number.isFinite(e.mesh.rotation.x));
 e.special1621=null;e.recoveryKey1623=key;e.wind=0;e.recover=.35;mobPose1623(e,.1);
 assert.ok(Number.isFinite(e.mesh.rotation.z));e.recover=0;
 for(let i=0;i<100;i++)mobPose1623(e,.016);
 assert.equal(e.mesh.rotation.x,0);assert.equal(e.mesh.rotation.z,0);assert.equal(e.recoveryKey1623,null);
 e.phasePose1623=.8;mobPose1623(e,.1);assert.ok(e.mesh.rotation.x<0);e.stun=.3;mobPose1623(e,.1);assert.ok(Number.isFinite(e.mesh.rotation.z));
}
assert.equal(poses.size,8);assert.equal(Object.keys(MOB_SOUNDS1623).length,8);
`,{assert});assert.ok(html.includes('mobPose1623(en,dt)'));console.log('MOBPOSE1623: eight distinct poses, recovery, phase, stun and neutral reset');
