const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const code=h.split('/* RACE1628-BEGIN */')[1].split('/* RACE1628-END */')[0];
vm.runInNewContext(code+`
const loc=new Map([['A',{x:0,z:0}],['B',{x:100,z:0}],['C',{x:5000,z:0}]]), logs=[];
const fresh=()=>({day:0,relations:{},treaties:{}});let r=fresh();let bias=-2;
const tick=day=>{r.day=day;return raceConflictDay1628(r,loc,c=>c,(a,b)=>r.relations[pair(a,b)]||0,()=>({treasury:100}),(a,b)=>a==='A'&&b==='B'?bias:-2,s=>logs.push(s));};
assert(!tick(0));assert(tick(7));assert(r.treaties['A|B'].embargo);assert(!tick(7));assert(!tick(14));assert(!tick(21));assert(tick(28));assert.equal(r.relations['A|B'],-1);assert(!tick(35));assert(!tick(63));assert(tick(70));assert.equal(r.relations['A|B'],0);assert(!r.treaties['A|B'].embargo);assert(!tick(77));assert(!r.treaties['A|C']);
r=JSON.parse(JSON.stringify(r));assert(!tick(84));assert(!tick(119));
r=fresh();r.treaties['A|B']={trade:true};for(let d=0;d<100;d+=7)assert(!tick(d));
r=fresh();r.relations['A|B']=-1;for(let d=0;d<100;d+=7)assert(!tick(d));assert.equal(r.relations['A|B'],-1);
r=fresh();tick(0);tick(7);r.day=8;raceManualTreaty1628(r,'A|B','lift');r.treaties['A|B'].embargo=false;for(let d=14;d<36;d+=7)assert(!tick(d));
r=fresh();bias=1;assert(!tick(0));assert(tick(28));assert(r.treaties['A|B'].trade);assert(!tick(77));assert(tick(84));assert.equal(r.relations['A|B'],1);
`,{assert,pair:(a,b)=>[a,b].sort().join('|'),warFaction:f=>!!f,warDistance:(a,b,l)=>Math.hypot(l.get(a).x-l.get(b).x,l.get(a).z-l.get(b).z)});
console.log('RACE1628: embargo, war, peace, truce, trade, distance, replay, serialization, manual treaties.');
