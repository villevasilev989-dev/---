const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8'),b=fs.readFileSync(__dirname+'/test.cjs','utf8');
const cut=(a,z)=>h.slice(h.indexOf(a),h.indexOf(z,h.indexOf(a)+a.length));
const mock=b.slice(b.indexOf('const mock=`')+12,b.indexOf('`;\nvm.runInNewContext(mock+'));
vm.runInNewContext(mock+cut('  function exploration1655e','  function mapGate1655e')+cut('/* MOB1621-BEGIN */','/* MOB1621-END */')+cut('  const DUNGEON_TILE=','  /* ---- Hedgehog statue')+`
const NetworkTransport={isOpen:()=>false},soundVoice1625=()=>{},bioPlayerHit=()=>{},chestLoot1655=()=>null;
ENEMY_TYPES.push(...Array.from({length:12},()=>model));
let found=0;const site=dgMakeSites1653()[0];site.theme=0;player.lvl=100;
for(let seed=0;seed<2000;seed++){const layout=generateDungeon(seed,1,site),q=dgSecretPlan1656c(layout,seed,1,site);if(!q)continue;found++;assert(!layout.tiles.has(q.gate));assert.equal(q.cells.length,9);assert(q.cells.every(([x,z])=>!layout.tiles.has(dgKey(x,z))));assert.equal(dgSecretPlan1656c(layout,seed,1,{catalog1653:64}),null);}
assert(found>100);let tested=false;for(let i=0;i<100&&!tested;i++){enterDungeon(site);const q=dg.secret1656c;if(!q){exitDungeon();continue;}assert(!dg.tiles.has(q.gate));playerMesh.position.copy(q.lever.position);const a=dgNearest();assert.equal(a.n,'Осмотреть расшатанный камень');a.f();a.f();assert(!dg.tiles.has(q.gate));dgSecretTick1656c(1);assert(dg.tiles.has(q.gate));assert(!q.wall.visible);playerMesh.position.copy(q.cache.position);const b=dgNearest();assert.equal(b.n,'Открыть тайник');q.cursed=false;const gold=player.gold;b.f();b.f();assert.equal(player.gold,gold+38);assert(q.claimed);exitDungeon();assert.equal(dg,null);tested=true;}assert(tested);console.log('2000 layouts, '+found+' secret candidates; gate collision, animation, single reward and cleanup OK (mock).');`,{assert,console});
