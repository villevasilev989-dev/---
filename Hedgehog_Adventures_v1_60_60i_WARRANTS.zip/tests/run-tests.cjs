// Discover every top-level Node test. Missing prerequisites must not count as success.
const {spawnSync}=require('node:child_process'),fs=require('node:fs'),path=require('node:path');
const mode=process.argv[2]||'test';
if(!['test','test:logic','test:quick'].includes(mode)){console.error('Unknown test suite:',mode);process.exit(1);}
const deps={'test-server.cjs':'ws','test-gfx.cjs':'three','test-anim.cjs':'three'};
const root=path.resolve(__dirname,'..');
const files=fs.readdirSync(__dirname).filter(f=>/^test(?:-[\w-]+)?\.cjs$/.test(f)).sort();
if(!files.length){console.error('No tests found');process.exit(1);}
const results=[];
for(const file of files){
 const dep=deps[file];
 if(dep&&mode!=='test'){results.push({file,status:'EXCLUDED'});continue;}
 if(dep){try{require.resolve(dep,{paths:[root]});}catch(e){if(e.code!=='MODULE_NOT_FOUND')throw e;console.log('BLOCKED',file,'missing',dep);results.push({file,status:'BLOCKED',reason:'missing '+dep});continue;}}
 const start=Date.now();const r=spawnSync(process.execPath,[path.join(__dirname,file)],{cwd:root,stdio:'inherit',timeout:180000});
 const status=r.status===0?'PASS':'FAIL';results.push({file,status,ms:Date.now()-start,reason:r.error?.message||r.signal||undefined});console.log(status,file);
}
const counts=Object.fromEntries(['PASS','FAIL','BLOCKED','EXCLUDED'].map(s=>[s,results.filter(r=>r.status===s).length]));
console.log(JSON.stringify({mode,counts,results},null,2));
process.exitCode=counts.FAIL?1:counts.BLOCKED?2:0;
