process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>h.slice(h.indexOf(a),h.indexOf(b,h.indexOf(a)+a.length));
vm.runInNewContext(part('// SAVE-VALIDATION1615-BEGIN','// SAVE-VALIDATION1615-END')+`
const good={v:1,data:{hp:0},sky:['hub'],equip:{},quests:[],realm:{day:1,owners:{A:'B'},stock:{A:{food:10,ore:10,cloth:10}},relations:{},caravans:[]}};
assert.equal(validateSave1615(good),good);
for(const bad of [{sky:[null]},{equip:{weapon:42}},{realm:{...good.realm,reserve1608:{A:{parts:4,history:[],lastDay:0}}}},{realm:{...good.realm,parts1609:{pending:{A:null},history:[],lastDay:0}}},{realm:{...good.realm,engineers1607:{A:{trained:{x:'tomorrow'},history:[],lastDay:0}}}},{realm:{...good.realm,farms1583:{A:{beds1591:[null,null,null]}}}}])assert.throws(()=>validateSave1615({...good,...bad}));
`,{assert});
vm.runInNewContext(`let realm={reserve1608:{A:{parts:3},B:{parts:0}}};const m={A:{cash:100},B:{cash:100}},t={A:{enabled:true,condition:90},B:{enabled:true,condition:50}},st={A:{ore:10},B:{ore:0}};const NetworkTransport={isOpen:()=>false},industryCities1606=()=>['A','B'],industrySiege1606=()=>false,marketFor=c=>m[c],techState=c=>t[c],supply=c=>st[c],factionForCity=c=>c,tradePermitted=()=>true;`+part('// PARTS1609-BEGIN','// PARTS1609-END')+`
partsTrade1609(1);assert.equal(m.B.cash,88);t.B.condition=80;partsTrade1609(2);assert.equal(m.B.cash,100);assert.equal(realm.reserve1608.A.parts,3);assert(!realm.parts1609.pending.B);partsTrade1609(3);assert.equal(m.B.cash,100);
`,{assert});
vm.runInNewContext(`let realm={engineers1607:{A:{trained:{a:1},history:[]}},reserve1608:{A:{lastDay:-1,parts:2,made:2,used:0,history:[]}}};const m={cash:100},st={ore:3},t={enabled:true,condition:70},residentRecords={a:{city:'A',profession:'Инженер',age:30,money:10}};const NetworkTransport={isOpen:()=>false},industryCities1606=()=>['A'],industryProtected1606=()=>true,industrySiege1606=()=>false,marketFor=()=>m,supply=()=>st,techState=()=>t;`+part('// RESERVE1608-BEGIN','// RESERVE1608-END')+`
reserveDay1608(1);assert.equal(t.condition,78);assert.equal(realm.reserve1608.A.parts,1);assert.equal(st.ore,3);assert.equal(m.cash+residentRecords.a.money,110);
`,{assert});
assert(h.includes("throw new Error('Загрузка остановлена:"));assert(h.includes('player.alive=player.hp>0'));assert(!h.includes('function farmCycle1583('));console.log('FIX1616: nested malformed save rejection, cancelled unnecessary order, preventive repair with ore, static fail-closed/death guards.');
