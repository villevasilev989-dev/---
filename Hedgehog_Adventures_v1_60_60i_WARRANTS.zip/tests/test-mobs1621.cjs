const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
const section=html.split('/* MOB1621-BEGIN */')[1].split('/* MOB1621-END */')[0];
vm.runInNewContext(section+`
const wolf={name:'Волк',shape:'quadruped'}, mage={name:'Культист',shape:'humanoid'}, fire={name:'Повелитель Пламени',shape:'blob'};
let seed=123;const rng=()=>((seed=Math.imul(seed,1664525)+1013904223|0)>>>0)/4294967296;
const levels=new Set(), loadouts=new Set();for(let i=0;i<1000;i++){
 const p=mobProfile1621(wolf,'равнины',false,false,null,1,rng);levels.add(p.level);loadouts.add(p.skills.join(','));assert(p.level>=1&&p.level<=4);assert(p.hpFactor>=1&&p.atkFactor>=1);assert(p.skills.every(k=>['claw','roar'].includes(k)));
 const b=mobProfile1621(fire,'вулканы',true,false,null,1,rng);assert(b.level>=16&&b.level<=20);assert.equal(b.skills.length,3);assert.equal(new Set(b.skills).size,3);assert(b.skills.every(k=>MOB_SKILLS1621[k]));
 const d=mobProfile1621(mage,'равнины',true,false,{level:20},40,rng);assert(d.level>=62&&d.level<=66);assert(d.hpFactor<=1.4);
}assert(levels.size>=3);assert(loadouts.size===2);
const e=mobInit1621({hp:20,maxHp:20,atk:3},wolf,'равнины');assert(e.hp===e.maxHp&&e.baseAtk===e.atk);assert.equal(mobSelect1621(e,1),null);e.specialCd1621=0;assert.equal(mobSelect1621(e,99),null);assert(e.skills1621.includes(mobSelect1621(e,1)));
const o={x:0,y:0,z:0},a={x:8,y:0,z:0},line=()=>true;
assert(mobHit1621(MOB_SKILLS1621.fire,o,a,{x:9,y:0,z:0},line));assert(!mobHit1621(MOB_SKILLS1621.fire,o,a,{x:12,y:0,z:0},line));assert(!mobHit1621(MOB_SKILLS1621.fire,o,a,{x:8,y:4,z:0},line));assert(!mobHit1621(MOB_SKILLS1621.fire,o,a,a,()=>false));assert(mobHit1621(MOB_SKILLS1621.slam,o,a,{x:1,y:0,z:0},line));assert(!mobHit1621(MOB_SKILLS1621.slam,o,a,a,line));
`,{assert});
assert(html.includes('enemies.push(mobInit1621(spawned1621,t,'));assert(html.includes('mobWarning1621(en,skill,tp)'));assert(html.includes('en.special1621=null;en.aim1621=null;if(landed'));console.log('MOB1621: 1000 randomized profiles, levels, unique skills, cooldown, range, AoE escape, vertical separation and blocked line verified.');
