const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');const cut=(a,b)=>h.slice(h.indexOf(a),h.indexOf(b,h.indexOf(a)));
const ctx=vm.createContext({assert});vm.runInContext(cut('  function dgDispose(root)','  function dgBox')+cut('  function fxDispose1619','  function fxAdd')+`
const res=()=>({n:0,dispose(){this.n++;assert.equal(this.n,1)}}),g=res(),m=res(),t=res(),shared=res();
const root=(...nodes)=>({traverse(f){nodes.forEach(f)}}),a={geometry:g,material:[m,m],userData:{ownGeometry:true}},b={geometry:g,material:m,userData:{ownGeometry:true}};
dgDisposeMany1658([root(a,b),root(a),null]);assert.equal(g.n,1);assert.equal(m.n,1);
const g2=res(),m2=res();m2.map=t;fxDispose1619(root({geometry:g2,material:[m2,m2],userData:{ownGeometry:true}},{geometry:shared,material:m2,userData:{}}));assert.equal(g2.n,1);assert.equal(m2.n,1);assert.equal(t.n,1);assert.equal(shared.n,0);
`,ctx);
assert(h.includes('if(!effectsEnabled)return; n=Math.min(n,Math.max(0,700-fxList.length))'));assert(h.includes('if(!effectsEnabled||fxList.length>=700)return;const cv='));console.log('Cleanup1658: overlapping roots, material arrays, textures and shared FX geometry verified.');
