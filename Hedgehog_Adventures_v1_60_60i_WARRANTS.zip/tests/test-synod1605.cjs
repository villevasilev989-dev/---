process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const block=h.slice(h.indexOf('/* STORY124-BEGIN'),h.indexOf('/* STORY124-END'));
vm.runInNewContext(`let player,realm,gameTime=120,online=false,saves=0;const stocks={},markets={},taxes={};const NetworkTransport={isOpen:()=>online};const supply=c=>stocks[c]??={food:60,ore:60,cloth:60};const marketFor=c=>markets[c]??={cash:1000};const civicCollect=(c,n)=>taxes[c]=(taxes[c]||0)+n;const civicLog=()=>{};const log=()=>{};const save15=()=>saves++;const changeRep=(f,n)=>player.reputation[f]=(player.reputation[f]||0)+n;const marketFaction=n=>n.faction;const marketAllowed=n=>(player.reputation[n.faction]||0)>-2500;const marketFactor=(c,k)=>Math.max(.65,1.65-supply(c)[k]/100);const repBuyFactor=f=>(player.reputation[f]||0)<0?1.6:1;const civicTax=()=>.1;const reset=()=>{player={alive:true,gold:1000,herbs:3,reputation:{},hp:20,maxHp:100,mp:10,maxMp:50,stamina:10};realm={day:1};};
${block}
${h.slice(h.indexOf('  function techSpec('),h.indexOf('  function techQuote('))}
const relation=()=>-1,factionForCity=()=> 'Гильдия Инженеров';
const a=SYNOD1605[0],b=SYNOD1605[1];const city='Рунный Зал';
for(let prior=0;prior<3;prior++)for(let outcome=0;outcome<3;outcome++){
 reset();for(const k of Object.keys(stocks))delete stocks[k];for(const k of Object.keys(markets))delete markets[k];
 assert(!storyGate(a));player.story124={synod1604:{step:7,end:SYNOD1604[0].steps[6].choice[prior][1]}};assert(storyGate(a));assert(!storyGate(b));assert(allStories().includes(a));
 for(const st of a.steps){assert(!storyAdvance(a,'wrong',st.role));assert(storyRows({city:st.city,name:st.role}).some(r=>r.t===a.name+': '+st.text));if(st.puzzle)assert(!storyAdvance(a,st.city,st.role,0));if(st.project){const qty=supply(st.city).ore;const cash=player.gold;supply(st.city).ore=0;assert(!storyAdvance(a,st.city,st.role));supply(st.city).ore=qty;const cost=ancientProjectPrice(st.city,st.project);assert(storyAdvance(a,st.city,st.role));assert.equal(supply(st.city).ore,qty-3);assert.equal(player.gold,cash-cost);continue;}assert(storyAdvance(a,st.city,st.role,st.choice?outcome:st.puzzle?1:null));}
 assert.equal(storyGate(b),outcome===0);const m=marketFor(city);m.produced={};m.consumed={};const t=techState(city);techDay(city);assert.equal(t.condition,outcome===0?99:98);assert(t.last>0);const cond=t.condition;realm.armies=[{target:city,phase:'siege',faction:'enemy'}];techDay(city);assert.equal(t.condition,cond);assert.equal(t.last,0);realm.armies=[];
 if(outcome===0){for(const st of b.steps){assert(storyAdvance(b,st.city,st.role,st.choice?0:null));}const d='Крепость Семи Гномов',n=marketFor(d);n.produced={};n.consumed={};techDay(d);assert.equal(techState(d).condition,99);assert(!storyAdvance(b,d,'leader',0));assert.equal(JSON.parse(JSON.stringify(n)).ancientWorks.synod1605transfer.wearReduction,1);}
 player.story124=JSON.parse(JSON.stringify(player.story124));assert(storyStep(a).end);assert.equal(storyStep(a).notes.length,6);assert(!storyAdvance(a,city,'leader',0));
}console.log('Synod safety: 9 paths, choices, costs, real production wear, siege, transfer, persistence OK');`,{assert,console});
