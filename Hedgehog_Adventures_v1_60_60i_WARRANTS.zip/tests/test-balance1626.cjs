const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
const section=(start,end)=>html.slice(html.indexOf(start),html.indexOf(end,html.indexOf(start)));
vm.runInNewContext(section('const CLASSES = [','const CLASS_ABIL=')+section('const RACES=[','let chosenRace=')+section('const BASE_ATTR = {','const SKILL_TREE = [')+section('const ENEMY_TYPES = [','/* MOB1621-BEGIN */')+section('const BOSS_TYPES = [','function spawnBoss')+section('const MOB_SKILLS1621=','function mobSelect1621')+`
for(const c of CLASSES)for(const r of RACES){
 const atk=c.atk+(r.atk||0)+2+Math.floor((BASE_ATTR[c.id].str+(r.attr.str||0))*.6);
 for(const t of ENEMY_TYPES){assert(t.hp>atk*2, c.id+' '+r.id+' '+t.name+' single critical');assert(t.hp>=atk*3,'at least three normal hits');}
}
for(const t of ENEMY_TYPES){assert(t.atk>=11);for(const biome of t.biomes){const e=mobInit1621({hp:t.hp,maxHp:t.hp,atk:t.atk},t,biome);assert(e.hp>=t.hp&&e.atk>=t.atk&&e.hp===e.maxHp);}}
for(const t of BOSS_TYPES){assert(t.hp>=850&&t.atk>=24);const e=mobInit1621({hp:t.hp,maxHp:t.hp,atk:t.atk,isBoss:true},t,t.biomes[0]);assert(e.hp>=t.hp&&e.baseAtk===e.atk&&e.skills1621.length===3);}
`,{assert,mobAffinity1622:()=>null});
console.log('BALANCE1626: all 72 class/race combinations, ordinary and critical first hits, all enemy types and boss scaling.');
