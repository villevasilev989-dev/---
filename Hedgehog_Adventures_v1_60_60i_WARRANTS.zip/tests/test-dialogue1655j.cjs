const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(h.slice(h.indexOf('  const ROMANCE_VOICES1655f'),h.indexOf('  function romanceWalk1655f'))+`
assert.equal(ROMANCE_TOPICS1655j.length,15);assert.equal(new Set(ROMANCE_TOPICS1655j.flat()).size,60);
for(let i=0;i<15;i++){const r=romanceState1655f({},'npc');const seen=new Set();for(let m=1;m<=7;m++){r.met=m;seen.add(romanceGreeting1655f(r,i,false));}assert.equal(seen.size,7);for(let p=0;p<5;p++)assert(ROMANCE_TOPICS1655j[i].includes(romanceLine1655j(r,i,'chat',p)));r.feud=true;assert(ROMANCE_REPLIES1655j.feud.includes(romanceGreeting1655f(r,i,true)));r.feud=false;r.affinity=-50;assert(ROMANCE_REPLIES1655j.distant.includes(romanceGreeting1655f(r,i,false)));r.affinity=90;assert(ROMANCE_REPLIES1655j.spouse.includes(romanceGreeting1655f(r,i,true)));}
assert.equal(Object.values(ROMANCE_REPLIES1655j).flat().length,27);console.log('15 NPC, 105 individual lines, 27 contextual replies, greeting rotation and relationship priority OK');`,{assert,console});
assert(h.includes('topicOpen?ROMANCE_TOPICS1655j[n.index].map'));assert(h.includes("answer('chat',text)"));
