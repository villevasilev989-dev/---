const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');const h=fs.readFileSync(__dirname+'/../index.html','utf8');vm.runInNewContext(h.split('/* WEAPON1657B-BEGIN */')[1].split('/* WEAPON1657B-END */')[0]+`
for(const k of Object.keys(WEAPON_COMBAT1657B)){const p=weaponCombat1657b({family:k});assert(p.range>0&&p.cd>0&&p.stamina>0&&p.mul>0);}
assert(weaponCombat1657b({family:'dagger'}).cd<weaponCombat1657b({family:'hammer'}).cd);
assert.equal(weaponCombat1657b({family:'bow',form:'Гномий арбалет'}).k,'crossbow');
assert.equal(weaponCombat1657b({family:'exotic',form:'Чакрам'}).k,'thrown');
assert.equal(weaponCombat1657b({joke:true}).k,'spoon');
assert.equal(weaponCombat1657b({family:'bow'},true).range,4);
assert.equal(weaponCombat1657b({family:'bow'},true).cd,.5);
assert.equal(weaponCombat1657b({family:'__proto__'}).k,'legacy');
assert(weaponFacing1657b(0,-8,0,weaponCombat1657b({family:'bow'}),false));
assert(!weaponFacing1657b(0,8,0,weaponCombat1657b({family:'bow'}),false));
console.log('Weapon profiles, legacy and network fallback, ranged aiming OK');`,{assert,console});
