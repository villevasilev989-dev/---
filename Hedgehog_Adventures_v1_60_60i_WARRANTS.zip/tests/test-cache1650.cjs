const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'dc-cache-'));
try{
 fs.copyFileSync(path.join(__dirname,'../prepare3d.js'),path.join(root,'prepare3d.js'));
 const fixture="const REVISION = '160';\nclass WebGLRenderer {}\nclass Scene {}\nexport { REVISION, WebGLRenderer, Scene };\n"+' '.repeat(510000);
 const broken=path.join(root,'node_modules/three/build');fs.mkdirSync(broken,{recursive:true});fs.writeFileSync(path.join(broken,'three.module.js'),fixture);
 const cached=path.join(root,'.dc-runtime/node_modules/three');fs.mkdirSync(path.join(cached,'build'),{recursive:true});fs.writeFileSync(path.join(cached,'build/three.module.js'),fixture);fs.writeFileSync(path.join(cached,'LICENSE'),'fixture license');
 const r=spawnSync(process.execPath,[path.join(root,'prepare3d.js')],{env:{...process.env,PATH:''},encoding:'utf8',timeout:20000});assert.equal(r.status,0,r.stderr);assert.equal(fs.readFileSync(path.join(root,'vendor/three.module.js'),'utf8'),fixture);assert.equal(fs.readFileSync(path.join(root,'vendor/THREE-LICENSE.txt'),'utf8'),'fixture license');console.log('PASS: recover vendor from intact runtime cache despite incomplete root package, without npm.');
}finally{fs.rmSync(root,{recursive:true,force:true});}
