const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const s=fs.readFileSync(path.join(__dirname,'../server.js'),'utf8');
const cut=(a,b)=>s.slice(s.indexOf(a),s.indexOf(b,s.indexOf(a)+a.length));
let now=10000;const events=[];const ctx={assert,Date:{now:()=>now},broadcast:(r,t,p)=>events.push({t,p}),sendTo:(p,r,t,v)=>events.push({t,p:v}),rid:()=> 'test', LIMITS:{adminHit:25000},maxHit:()=>100,take:()=>true,num:(v,d)=>Number.isFinite(v)?v:d,refill:()=>{},markKilled:()=>{},events};vm.createContext(ctx);
vm.runInContext(cut('function elementalDamage1636(','function handle(')+cut('const NET_SKILLS1637=','setInterval(()=>{for(const room of rooms.values())tickMobAttacks1637')+`
const e={id:'m',hp:1000,maxHp:1000,atk:20,x:0,y:0,z:0,skills:['fire']},p={id:'p',stateAt:10000,state:{hp:100,zone:'w',x:1,y:0,z:0},dmgBucket:{t:1000}},r={hostId:'p',worldReady:true,worldAt:10000,peers:new Map([['p',p]]),entities:new Map([['m',e]]),mobCasts:new Map([['m',{key:'fire',castId:'a',until:10001,ready:12000}]])};
attack(r,p,{targetId:'m',damage:10,interrupt:true});assert.equal(e.hp,990);assert.equal(e.stunUntil,10450);assert.equal(events[0].t,'mob_cancel');assert.equal(r.mobCasts.get('m').key,undefined);
attack(r,p,{targetId:'m',damage:10,interrupt:true});assert.equal(e.stunUntil,10450);assert.equal(events.filter(x=>x.t==='mob_cancel').length,1);
attack(r,p,{targetId:'m',damage:-1});attack(r,p,{targetId:'m',damage:NaN});assert.equal(e.hp,980);
p.stateAt=7999;attack(r,p,{targetId:'m',damage:10});assert.equal(e.hp,980);p.stateAt=10000;r.worldAt=6999;attack(r,p,{targetId:'m',damage:10});assert.equal(e.hp,980);
r.worldAt=10000;r.mobCasts.set('m',{ready:0});tickMobAttacks1637(r,10001,()=>0);assert.equal(r.mobCasts.get('m').key,undefined);
tickMobAttacks1637(r,10450,()=>0);assert.equal(r.mobCasts.get('m').key,'fire');
`,ctx);
console.log('COOP1640: interrupt, cooldown, stale snapshots, invalid damage, resume after stun');
