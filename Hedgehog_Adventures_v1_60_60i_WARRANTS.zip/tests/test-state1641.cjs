const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const s=fs.readFileSync(path.join(__dirname,'../server.js'),'utf8');
const cut=(a,b)=>s.slice(s.indexOf(a),s.indexOf(b,s.indexOf(a)+a.length));
const events=[];const ctx={assert,events,broadcast:(r,t,p)=>events.push({t,p}),sendTo:()=>{},rid:()=> 'test'};
vm.runInNewContext(`const LIMITS={maxLvl:1e9,atkBase:5000,atkPerLvl:100};const owners={};const clean=(v,n)=>typeof v==='string'?v.slice(0,n):'';const num=(v,d)=>Number.isFinite(v)?v:d;`+cut('function combatSnapshot1641(','function leave(')+cut('const NET_SKILLS1637=','setInterval(()=>{for(const room of rooms.values())tickMobAttacks1637')+`
const peer={id:'p'},full={zone:'w',hp:100,x:1,y:0,z:0};
updatePeerState1641(peer,{nick:'new'},10000);assert.equal(peer.stateAt,undefined);
updatePeerState1641(peer,full,10001);assert.equal(peer.stateAt,10001);assert.equal(peer.state.x,1);
updatePeerState1641(peer,{nick:'changed'},12002);assert.equal(peer.stateAt,10001);assert.equal(peer.state.nick,'changed');
for(const bad of [{x:9},{...full,x:Infinity},{...full,y:1e7},{...full,z:'0'},{...full,hp:-1},{...full,zone:'invalid'}]){
 updatePeerState1641(peer,full,13000);updatePeerState1641(peer,bad,13001);assert.equal(peer.stateAt,0);assert.equal(peer.state.x,1);assert.equal(peer.state.zone,'w');
}
updatePeerState1641(peer,full,14000);assert.equal(peer.stateAt,14000);
const mob={id:'m',x:0,y:0,z:0,hp:100,maxHp:100,atk:20,skills:['fire'],boss:true,name:'Boss',shape:'wolf',color:10,scale:2};
const room={hostId:'p',worldReady:true,worldAt:14000,peers:new Map([['p',peer]]),entities:new Map(),killed:new Map(),mobCasts:new Map()};
assert(mergeWorld(room,[mob],14000));assert(mergeWorld(room,[{...mob,boss:false,name:'changed',shape:'rat',color:20,scale:1,x:2}],14001));
const m=room.entities.get('m');assert.equal(m.boss,true);assert.equal(m.name,'Boss');assert.equal(m.shape,'wolf');assert.equal(m.color,10);assert.equal(m.scale,2);assert.equal(m.x,2);
room.mobCasts.set('m',{key:'fire',castId:'one',ready:16000,until:15000,center:{x:1,y:0,z:0}});room.worldAt=16001;
tickMobAttacks1637(room,16001,()=>0);assert.equal(events.length,1);assert.equal(events[0].t,'mob_cancel');assert.equal(room.mobCasts.size,0);
`,ctx);
console.log('COOP1641: full combat snapshots only, malformed coordinates fail closed, stable boss metadata, stale host cancellation');
