"""Real game smoke test. Never stubs Three.js or treats a blocked renderer as a pass.
Use an isolated Playwright profile and a short-lived local server on a separate port.
Exit codes: 0 passes, 1 tested failure, 2 blocked prerequisites/environment.
"""
import json, os, shutil, socket, subprocess, sys, time, urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent.parent
out=root/'tests'/'3d-test-output';out.mkdir(exist_ok=True)
version=json.loads((root/'package.json').read_text(encoding='utf-8'))['version']
report={'version':version,'status':'BLOCKED','steps':[], 'pageErrors':[]}
server=None
try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        executable=os.environ.get('DC_CHROMIUM') or shutil.which('chromium')
        options={'args':['--disable-dev-shm-usage']}
        if executable: options['executable_path']=executable
        if os.environ.get('DC_SOFTWARE_GL')=='1': options['args']+=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']
        browser=pw.chromium.launch(**options)
        context=browser.new_context(viewport={'width':1280,'height':800},device_scale_factor=1,accept_downloads=True)
        page=context.new_page();page.on('pageerror',lambda e:report['pageErrors'].append(str(e)))
        # Exact production boot script, not a fake renderer. Test diagnostics separately from HTTP navigation.
        html=(root/'index.html').read_text(encoding='utf-8');boot=html.split('<script>')[1].split('</script>')[0]
        page.set_content('<meta charset=utf-8><div id="boot1571"></div><button id="diagMenu1571">Отчёт диагностики</button><script>'+boot+'</script>')
        report['status']='FAIL'
        page.locator('#diagMenu1571').click();diag=json.loads(page.locator('#diag1571 pre').inner_text());report['webgl']=diag['webgl'];assert diag['version']==version
        with page.expect_download() as d: page.locator('[data-save]').click()
        d.value.save_as(str(out/'diagnostic-probe.json'));assert json.loads((out/'diagnostic-probe.json').read_text(encoding='utf-8'))['version']==version
        page.screenshot(path=str(out/'diagnostic-probe.png'));page.locator('[data-close]').click();assert not page.locator('#diag1571').is_visible();report['steps'].append({'name':'Actual diagnostic UI and JSON download','status':'PASS'})
        vendor=root/'vendor'/'three.module.js';installed=root/'node_modules'/'three'/'build'/'three.module.js'
        if not vendor.is_file() and not installed.is_file(): report['steps'].append({'name':'Local Three.js r160','status':'BLOCKED','detail':'Run node prepare3d.js'} )
        if not diag['webgl']['ok']: report['steps'].append({'name':'WebGL framebuffer probe','status':'BLOCKED','detail':diag['webgl']})
        else: report['steps'].append({'name':'WebGL framebuffer probe','status':'PASS'})
        if any(s['status']=='BLOCKED' for s in report['steps']):
            report['status']='BLOCKED';raise RuntimeError('Graphics prerequisites unavailable')
        with socket.socket() as s: s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        server=subprocess.Popen(['node','solo.js'],cwd=root,env={**os.environ,'SOLO_PORT':str(port)},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        url=f'http://127.0.0.1:{port}/index.html'
        for _ in range(100):
            try:
                with urllib.request.urlopen(url,timeout=1) as r: assert r.status==200
                break
            except OSError: time.sleep(.1)
        else: raise RuntimeError('Local HTTP server unavailable')
        pageErrors=report['pageErrors'];pageErrors.clear()
        try: page.goto(url,timeout=30000)
        except Exception as e: report['steps'].append({'name':'Browser navigation','status':'BLOCKED','detail':str(e)});raise RuntimeError('Navigation unavailable')
        report['status']='FAIL'
        page.wait_for_selector('.classCard',timeout=30000)
        page.locator('.classCard').first.click();page.locator('#startBtn').click(timeout=120000)
        report['status']='FAIL'
        def rendered(after=0):
            page.wait_for_function('n=>D1571.report.frames>n+3 && D1571.report.metrics?.triangles>0',arg=after,timeout=120000)
            return page.evaluate('JSON.parse(JSON.stringify(D1571.report))')
        def record(name,r):
            assert not any(e['kind'] in ('init','frame','context','promise','error') for e in r['errors']),r['errors']
            report['steps'].append({'name':name,'status':'PASS','metrics':r['metrics'],'frames':r['frames']});page.screenshot(path=str(out/(name+'.png')),timeout=120000)
        r=rendered();record('01-spawn',r)
        page.keyboard.press('i');page.wait_for_selector('#inventoryPanel:visible');page.keyboard.press('i');page.wait_for_selector('#inventoryPanel',state='hidden');report['steps'].append({'name':'Inventory open/close','status':'PASS'})
        def cmd(line):
            page.locator('#adminInput').fill(line);page.locator('#adminInput').press('Enter')
        page.keyboard.press('F8');page.wait_for_selector('#adminInput:visible');cmd('/adminpass set browser-test-1658');page.wait_for_function("document.getElementById('adminOutput').textContent.includes('Пароль сохранён')",timeout=15000);cmd('/admin browser-test-1658');page.wait_for_function("document.getElementById('adminPanelStatus1658e').textContent.includes('Авторизован')",timeout=15000);cmd('/tp city Крепость Семи Гномов');page.keyboard.press('Escape');r=rendered(r['frames']);record('02-dwarf-fortress',r)
        page.keyboard.press('F8');cmd('/tp city Рунный Зал');page.keyboard.press('Escape');r=rendered(r['frames']);record('03-rune-hall',r)
        assert not pageErrors,pageErrors
        report['status']='PASS';context.close();browser.close()
except Exception as e:
    report['reason']=str(e)
finally:
    if server: server.terminate();server.wait(timeout=5)
    (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit({'PASS':0,'FAIL':1,'BLOCKED':2}[report['status']])
