const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
vm.runInNewContext(h.slice(h.indexOf('// SAVE-VALIDATION1615-BEGIN'),h.indexOf('// SAVE-VALIDATION1615-END'))+h.slice(h.indexOf('// IDB1634-BEGIN'),h.indexOf('// IDB1634-END'))+`
(async()=>{
const raw=(t,hp)=>packSave1618(JSON.stringify({v:1,savedAt:t,data:{hp},sky:['hub'],equip:{},quests:[]}));
const a=raw(1,10),b=raw(2,20),c=raw(3,30);
assert.equal(chooseSave1634({primary:b,backup:a},null).data.hp,20);
assert.equal(chooseSave1634({primary:'broken',backup:a},null).data.hp,10);
assert.equal(chooseSave1634({primary:b},decodeSave1618(c)).data.hp,30);
const records=new Map();const db={transaction(name,mode){const tx={objectStore(){return {get(k){const req={};queueMicrotask(()=>{req.result=records.get(k);req.onsuccess();queueMicrotask(()=>tx.oncomplete());});return req;},put(v,k){records.set(k,v);}};}};return tx;}};
await writeDb1634(db,'hero',a);await writeDb1634(db,'hero',b);await writeDb1634(db,'hero',a);assert.equal(records.get('hero').primary,b);assert.equal(records.get('hero').backup,a);assert.equal((await readDb1634(db,'hero')).primary,b);
records.set('hero',{primary:a,backup:c});await writeDb1634(db,'hero',b);assert.equal(records.get('hero').backup,c);assert.equal(chooseSave1634(records.get('hero'),null).data.hp,30);const d=raw(4,40);await writeDb1634(db,'hero',d);assert.equal(records.get('hero').backup,c);assert.equal(records.get('hero').primary,d);
const local=new Map([['hero',a],['hero_backup',c]]);const storage={getItem:k=>local.get(k)??null,setItem:(k,v)=>local.set(k,v)};assert.equal(readSave1615(storage,'hero').data.hp,30);writeSave1617(storage,'hero',b);assert.equal(local.get('hero_backup'),c);writeSave1617(storage,'hero',d);assert.equal(local.get('hero'),d);assert.equal(local.get('hero_backup'),c);assert.throws(()=>decodeSave1618(JSON.stringify({v:1,savedAt:'invalid',data:{},sky:[],equip:{},quests:[]})));
let release;const seen=[];const enqueue=saveQueue1634(async x=>{seen.push(x);if(x===a)await new Promise(r=>release=r);},()=>assert.fail());enqueue(a);enqueue(b);enqueue(c);release();await new Promise(r=>setTimeout(r,10));assert.deepEqual(seen,[a,c]);await assert.rejects(openSaveDb1634(null));console.log('IDB selection, recovery, transactional adapter and queue passed');
})().catch(e=>{console.error(e);process.exitCode=1;});`,{assert,console,process,setTimeout,clearTimeout,queueMicrotask});
