const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {valid}=require('../prepare3d');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dc-module-'));try{
 const p=path.join(dir,'three.module.js'),head="const REVISION = '160';\nclass WebGLRenderer {}\nclass Scene {}\n"+'// padding '+ 'x'.repeat(510000)+'\n';
 assert.equal(valid(p),false);fs.writeFileSync(p,head+'export { REVISION, WebGLRenderer, Scene };');assert.equal(valid(p),true);
 fs.writeFileSync(p,head+'export {');assert.equal(valid(p),false);
 fs.writeFileSync(p,head.replace("'160'","'159'"));assert.equal(valid(p),false);
 console.log('PASS: missing, syntactically valid fixture, truncated module, wrong revision.');
}finally{fs.rmSync(dir,{recursive:true,force:true});}
