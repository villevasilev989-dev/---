const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync(__dirname+'/../index.html','utf8');
const part=(a,b)=>h.slice(h.indexOf(a),h.indexOf(b));
vm.runInNewContext(part('  function dgMirrorCount1656e','  function dgTrapEffect1656')+part('  function dgEventPlan1656e','  function buildDungeonFloor')+`
const rooms=[{id:0,kind:'entry'},{id:1,kind:'combat',tx:3,tz:4}],site={catalog1653:1};
assert.equal(dgEventPlan1656e(rooms,site,.01).kind,'statue');assert.equal(dgEventPlan1656e(rooms,site,.2).kind,'ambush');assert.equal(dgEventPlan1656e(rooms,site,.32),null);assert.equal(dgEventPlan1656e(rooms,{catalog1653:64},0),null);assert.equal(dgEventPlan1656e(rooms,{ruin:true,catalog1653:1},0),null);
const player={alive:true,maxHp:100},playerMesh={position:{}},enemies=[],dg={tiles:{has:()=>true}},dgTile=()=>'',dgLocal=()=>[0,0],dgLineWorld=()=>true,dgPos=()=>({}),fxBurst=()=>{},totalAtk=()=>100,SHAPE_BUILD={humanoid:()=>({})};
const spawnDungeonMob=()=>enemies.push({isDungeon:true,maxHp:100,atk:100,mesh:{children:[],add(){}}});
for(const [id,n] of [[50,2],[70,3],[83,4],[97,6]]){enemies.length=0;dgMirrorSpawn1656e(id);assert.equal(enemies.length,n);assert(enemies.every(e=>e.extra1656e==='mirror'&&e.hp===18&&e.atk===35));dgMirrorSpawn1656e(id);assert(enemies.length<=6);}
let logs=0;const log=()=>logs++,soundVoice1625=()=>{};enemies.length=0;dg.event1656e={kind:'ambush',x:0,z:0,room:1};dgEventTick1656e();dgEventTick1656e();assert.equal(enemies.length,2);assert.equal(logs,1);assert(dg.event1656e.used);console.log('mirror caps, bounded stats, event eligibility and single activation OK');`,{assert,console});
assert(h.includes("if(target.extra1656e){log(target.name+' рассеян.');return;}"));
