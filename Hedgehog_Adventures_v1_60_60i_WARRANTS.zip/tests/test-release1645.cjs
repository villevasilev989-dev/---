const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),server=path.join(root,'server.js');
for(const port of ['0','-1','65536','abc','1.5','']){
 const r=spawnSync(process.execPath,[server],{env:{...process.env,PORT:port},encoding:'utf8',timeout:5000});
 assert.equal(r.status,1);assert.match(r.stderr,/PORT must be an integer/);
}
// Simulated WebSocketServer lifecycle, not real transport.
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'dc-release-'));
try{
 const dir=path.join(tmp,'node_modules','ws');fs.mkdirSync(dir,{recursive:true});fs.copyFileSync(server,path.join(tmp,'server.js'));
 fs.writeFileSync(path.join(dir,'index.js'),`const {EventEmitter}=require('node:events');class WebSocketServer extends EventEmitter{constructor(){super();this.clients=new Set();process.nextTick(()=>{if(process.env.TEST_BIND_FAIL){this.emit('error',new Error('simulated bind failure'));return;}this.emit('listening');const ws=new EventEmitter();ws.readyState=1;ws.bufferedAmount=0;ws.send=s=>{const m=JSON.parse(s);if(m.type==='welcome')console.log('WELCOME');};ws.close=()=>{};ws.terminate=()=>{};this.clients.add(ws);this.emit('connection',ws,{});ws.emit('message',JSON.stringify({v:1,type:'state',room:'test',payload:{}}));console.log('BEFORE_HELLO');ws.emit('message',JSON.stringify({v:1,type:'hello',room:'test',payload:{nick:'test'}}));process.exit(0);});}}module.exports={WebSocketServer};`);
 const run=fail=>spawnSync(process.execPath,[path.join(tmp,'server.js')],{env:{...process.env,PORT:'8080',TEST_BIND_FAIL:fail?'1':''},encoding:'utf8',timeout:5000});
 let r=run(true);assert.equal(r.status,1);assert.match(r.stderr,/simulated bind failure/);assert.doesNotMatch(r.stdout,/Сервер кооператива запущен/);
 r=run(false);assert.equal(r.status,0,r.stderr);assert.match(r.stdout,/Сервер кооператива запущен/);assert.match(r.stdout,/BEFORE_HELLO\s+WELCOME/);assert.equal((r.stdout.match(/WELCOME/g)||[]).length,1);
}finally{fs.rmSync(tmp,{recursive:true,force:true});}
console.log('RELEASE1645: invalid ports, simulated bind failure, readiness and hello-only handshake.');
