process.chdir(require("node:path").resolve(__dirname,".."));
const assert=require('node:assert/strict'),{spawn,spawnSync}=require('node:child_process'),net=require('node:net');
const start=port=>spawn(process.execPath,[__dirname+'/../solo.js'],{env:{...process.env,SOLO_PORT:String(port)},stdio:['ignore','pipe','pipe']});
(async()=>{
 const probe=net.createServer();await new Promise((r,j)=>{probe.once('error',j);probe.listen(0,'127.0.0.1',r);});const port=probe.address().port;await new Promise(r=>probe.close(r));
 const p=start(port);try{
 let ready=false;for(let i=0;i<100;i++){try{const r=await fetch('http://127.0.0.1:'+port+'/');if(r.status===200){assert((await r.text()).includes("v"+require("../package.json").version));ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,40));}assert(ready,'HTTP server failed to start');
 const root='http://127.0.0.1:'+port;const get=await fetch(root+'/index.html');assert.equal(get.status,200);assert.match(get.headers.get('content-type'),/text\/html/);assert.equal(get.headers.get('x-content-type-options'),'nosniff');
 const head=await fetch(root+'/index.html',{method:'HEAD'});assert.equal(head.status,200);assert.equal(await head.text(),'');
 for(const url of ['/constructor','/toString','/__proto__','/server.js','/package.json','/missing'])assert.equal((await fetch(root+url)).status,404,url);
 assert.equal((await fetch(root+'/',{method:'POST'})).status,404);
 const duplicate=spawnSync(process.execPath,[__dirname+'/../solo.js'],{env:{...process.env,SOLO_PORT:String(port)},encoding:'utf8',timeout:5000});assert.equal(duplicate.status,1);assert.match(duplicate.stderr,/is busy/);assert.equal((await fetch(root+'/')).status,200);
 const bad=spawnSync(process.execPath,[__dirname+'/../solo.js'],{env:{...process.env,SOLO_PORT:'not-a-port'},encoding:'utf8',timeout:5000});assert.equal(bad.status,1);assert.match(bad.stderr,/SOLO_PORT/);
 console.log('SOLO1617: real loopback HTTP, HEAD, route allowlist, unsupported method, busy and invalid port handling.');
 }finally{p.kill();await new Promise(r=>p.once('exit',r));}
})().catch(e=>{console.error(e);process.exitCode=1;});
