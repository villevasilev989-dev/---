const assert=require('node:assert/strict'),http=require('node:http'),net=require('node:net'),{spawn}=require('node:child_process'),path=require('node:path');
(async()=>{
 const probe=net.createServer();await new Promise(r=>probe.listen(0,'127.0.0.1',r));const port=probe.address().port;await new Promise(r=>probe.close(r));
 const child=spawn(process.execPath,[path.join(__dirname,'../solo.js')],{env:{...process.env,SOLO_PORT:String(port)},stdio:'ignore'});
 const req=host=>new Promise((resolve,reject)=>{const q=http.get({hostname:'127.0.0.1',port,path:'/',headers:{Host:host}},r=>{r.resume();r.on('end',()=>resolve(r.statusCode));});q.on('error',reject);q.setTimeout(3000,()=>q.destroy(new Error('timeout')));});
 try{let ready=false;for(let i=0;i<100;i++){try{ready=await req('127.0.0.1:'+port)===200;if(ready)break;}catch{}await new Promise(r=>setTimeout(r,30));}assert(ready);assert.equal(await req('localhost:'+port),200);for(const h of ['evil.example','127.0.0.1.evil.example:'+port,'127.0.0.1:1','localhost.evil.example'])assert.equal(await req(h),421,h);assert.equal(await req('127.0.0.1:'+port),200);console.log('PASS: real HTTP host allowlist and continued service after rejection');}finally{child.kill();await new Promise(r=>child.once('exit',r));}
})().catch(e=>{console.error(e);process.exitCode=1;});
