process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
const block=n=>html.slice(html.indexOf('/* '+n+'-BEGIN */'),html.indexOf('/* '+n+'-END */'));
vm.runInNewContext(block('BIOLOGY')+block('CULTIVATION')+`
const ready=(rank=4)=>{const c=cultNew(),x=c.paths.qi;x.rank=rank;x.energy=x.insight=cultNeed(rank);return c;};
const legacy=cultNormalize({path:'mana',paths:{mana:{rank:7,energy:12,insight:14}}});assert.equal(legacy.paths.mana.rank,7);assert.equal(legacy.paths.mana.core,1);assert.equal(legacy.paths.mana.energy,12);assert.equal(legacy.technique,'balanced');
const bad=cultNormalize({technique:'__proto__',attempts:-1,paths:{qi:{core:-99,channels:Infinity,purity:99,strain:4}}});assert.equal(bad.paths.qi.core,0);assert.equal(bad.paths.qi.channels,1);assert.equal(bad.paths.qi.strain,1);assert.equal(bad.paths.qi.purity,1);
const a=cultNew(),b=cultNew(),c=cultNew();cultLearn(b,'refine','test');cultLearn(c,'force','test');b.technique='refine';c.technique='force';for(const q of [a,b,c])cultPractice(q,15,'равнины',1);assert(c.paths.qi.energy>a.paths.qi.energy&&a.paths.qi.energy>b.paths.qi.energy);assert(b.paths.qi.purity>a.paths.qi.purity&&a.paths.qi.purity>c.paths.qi.purity);assert(c.paths.qi.strain>a.paths.qi.strain);assert(b.paths.qi.insight>a.paths.qi.insight);
const forced=cultNew();cultLearn(forced,'force','test');forced.technique='force';for(let i=0;i<200;i++)cultPractice(forced,1,'равнины',1);assert(forced.paths.qi.channels<1);const old=forced.paths.qi.channels;cultRecover(forced,200);assert(forced.paths.qi.channels>old);assert.equal(forced.paths.qi.strain,0);
const fail=ready(),x=fail.paths.qi;const result=cultAttempt(fail,1,0);assert.equal(result.status,'failed');assert(result.trial&&result.severe);assert.equal(x.rank,3);assert(x.core<1&&x.channels<1);assert.equal(x.energy,0);assert.equal(cultAttempt(fail,1,0).status,'not-ready');
const win=ready();assert.equal(cultAttempt(win,1,1).status,'success');assert.equal(win.paths.qi.rank,5);assert.equal(win.attempts,1);assert.equal(cultAttempt(win,1,1).status,'not-ready');
const impure=ready(),pure=ready();impure.paths.qi.purity=.3;pure.paths.qi.purity=.98;assert(cultRisk(impure)>cultRisk(pure));assert(cultBonus(impure,'qi')<cultBonus(pure,'qi'));assert(cultRisk(pure,.3)>cultRisk(pure,1));
const mixed=ready();mixed.paths.qi.strain=.4;mixed.paths.mana.rank=4;mixed.paths.mana.strain=.4;assert(cultConflict(mixed)>0);mixed.paths.mana.rank=1;assert.equal(cultConflict(mixed),0);
const hurt=ready();hurt.paths.qi.channels=.2;assert(!cultReady(hurt));const huge=ready(1000);assert.equal(cultAttempt(huge,1,1).status,'success');assert.equal(huge.paths.qi.rank,1001);
let practiced=0;for(let i=0;i<30;i++){const id='mage'+i,r={age:100,profession:'Боевой маг',hunger:0,fatigue:0};bioInit(r,id,'human');const copy=JSON.parse(JSON.stringify(r));for(let j=0;j<450;j++){cultNpcDay(r,id,j);cultNpcDay(copy,id,j);}assert.equal(JSON.stringify(r),JSON.stringify(copy));if(r.cultivation.paths.mana.rank>0)practiced++;assert.equal(JSON.stringify(cultNormalize(JSON.parse(JSON.stringify(r.cultivation)))),JSON.stringify(r.cultivation));}assert(practiced>0);
const child={age:5,profession:'Боевой маг',race:'human'};cultNpcDay(child,'child',1);assert(!child.cultivation);const dead={age:100,profession:'Боевой маг',race:'human',dead:true};cultNpcDay(dead,'dead',1);assert(!dead.cultivation);
`,{assert});
console.log('Deep cultivation: legacy migration, techniques, purity, damage/recovery, conflict, failure/success, trial, 30 NPC ×450 days deterministic, no fixed rank cap, save roundtrip OK.');
