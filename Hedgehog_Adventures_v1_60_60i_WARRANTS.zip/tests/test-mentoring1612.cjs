process.chdir(require("node:path").resolve(__dirname,".."));
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');const h=fs.readFileSync(__dirname+'/../index.html','utf8');const block=h.slice(h.indexOf('// ENGINEERS1607-BEGIN'),h.indexOf('// ENGINEERS1607-END'));
vm.runInNewContext(`let realm,online=false,blocked=false;const m={cash:100},st={cloth:4,ore:20},t={enabled:true,condition:90};const residentRecords={a:{city:'A',profession:'Инженер',age:30,money:10,name:'Мастер',engineering1607:10},b:{city:'A',profession:'Кузнец',age:30,money:10,name:'Ученик'}};const NetworkTransport={isOpen:()=>online},industryCities1606=()=>['A'],industryProtected1606=()=>true,industrySiege1606=()=>blocked,marketFor=()=>m,supply=()=>st,techState=()=>t;
${block}
function reset(){realm={day:5,engineers1607:{A:{lastDay:4,trained:{a:1},repairs:0,history:[]}}};m.cash=100;st.cloth=4;residentRecords.a.money=residentRecords.b.money=10;residentRecords.a.engineering1607=10;delete residentRecords.a.justice149;blocked=online=false;}
reset();engineerDay1607(5);let e=realm.engineers1607.A;assert.equal(e.trained.b,7);assert.equal(e.lessons1612.length,1);assert.equal(m.cash,96);assert.equal(st.cloth,3);assert.equal(residentRecords.b.money,14);engineerDay1607(5);assert.equal(e.lessons1612.length,1);realm=JSON.parse(JSON.stringify(realm));assert(engineerRows1607('A').some(x=>x.t.includes('Мастер → Ученик')));assert.equal(realm.engineers1607.A.trained.b,7);
reset();residentRecords.a.engineering1607=9;engineerDay1607(5);assert.equal(realm.engineers1607.A.trained.b,8);assert(!realm.engineers1607.A.lessons1612);
reset();residentRecords.a.justice149={detained:8};engineerDay1607(5);assert.equal(realm.engineers1607.A.trained.b,8);
reset();realm.engineers1607.A.trained.a=6;engineerDay1607(5);assert.equal(realm.engineers1607.A.trained.b,8);
reset();blocked=true;engineerDay1607(5);assert(!realm.engineers1607.A.trained.b);blocked=false;online=true;engineerDay1607(5);assert(!realm.engineers1607.A.trained.b);
console.log('Mentoring: accelerated training, costs, daily lock, serialization, UI, fallback, detention, unfinished training, siege, online OK');`,{assert,console});
