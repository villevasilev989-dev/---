@echo off
cd /d "%~dp0"
if not exist "prepare3d.js" (echo Extract the entire ZIP to a folder before starting. & pause & exit /b 1)
if not exist "index.html" (echo Missing index.html. Extract the entire ZIP first. & pause & exit /b 1)
where node >nul 2>nul || (echo Install Node.js first. & pause & exit /b 1)
node -e "if(!(Number(process.versions.node.split('.')[0])>=18)) process.exit(1)"
if errorlevel 1 (echo Node.js 18 or newer is required. & pause & exit /b 1)
node prepare3d.js
if errorlevel 1 (pause & exit /b 1)
if /I "%~1"=="--public" (
  node solo.js --open --public
) else (
  node solo.js --open
)
set "DC_EXIT=%ERRORLEVEL%"
pause
exit /b %DC_EXIT%
