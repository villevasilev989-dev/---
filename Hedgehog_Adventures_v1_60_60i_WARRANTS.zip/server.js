// Сервер кооператива «Покоритель Подземелий» (v1.6)
// Запуск:  npm install ws   →   ADMIN_PASSWORD=секрет node server.js     (порт: PORT=8080)
// Без ADMIN_PASSWORD админ-режим на сервере выключен (пароля по умолчанию нет).
const crypto = require('crypto');
const PORT = process.env.PORT === undefined ? 8080 : Number(process.env.PORT);
if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) { console.error('PORT must be an integer 1–65535.'); process.exit(1); }
let WebSocketServer;
try { ({ WebSocketServer } = require('ws')); } catch (e) { console.error('Cannot load ws: '+e.message+'\nRun npm install in the game folder.'); process.exit(1); }
const MAX_PLAYERS = 4, V = 1;
const rooms = new Map();

// ---------- Защита: админ-пароль, лимиты, проверка урона ----------
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const sha = x => crypto.createHash('sha256').update(String(x)).digest();
if(ADMIN_PASSWORD.length>128)throw new Error("ADMIN_PASSWORD: maximum 128 characters");
const ADMIN_HASH = ADMIN_PASSWORD ? sha(ADMIN_PASSWORD) : null;
const checkPassword = x => !!ADMIN_HASH && typeof x==='string' && x.length<=128 && crypto.timingSafeEqual(sha(x), ADMIN_HASH);
const LIMITS = {
  maxLvl: Number(process.env.MAX_LVL) > 0 ? Math.min(Number.MAX_SAFE_INTEGER,Math.floor(Number(process.env.MAX_LVL))) : Number.MAX_SAFE_INTEGER,        // потолок уровня, принимаемый от клиента
  atkBase: 5000, atkPerLvl: 100,                     // потолок заявленной атаки: base + lvl*perLvl
  hitBase: 40, meleeMul: 6, spellMul: 16,            // потолок удара: 40 + max(атака*6, (атака*.55+инт*1.8+ур*2.5+6)*16) — с запасом на заклинания и модификаторы
  repPerMin: 600, repBurst: 1500,                    // рост репутации за минуту / «запас» роста
  adminHit: 25000,
};
const makeBucket = (cap, perSec, start = cap) => ({ t: start, cap, perSec, last: Date.now() });
function refill(b) { const now = Date.now(); b.t = Math.min(b.cap, b.t + (now - b.last) / 1000 * b.perSec); b.last = now; return b; }
const take = (b, n = 1) => { refill(b); if (b.t < n) return false; b.t -= n; return true; };
const ipFails = new Map();                           // ip -> {n, until}: перебор пароля
function maxHit(peer) {
  const st = peer.state || {}, lvl = Math.min(LIMITS.maxLvl, Math.max(1, st.lvl || 1)), atk = Math.max(0, st.attack || 0), int = Math.max(0, st.int ?? 10);
  const spellBase = atk * .55 + int * 1.8 + lvl * 2.5 + 6;
  return Math.round(LIMITS.hitBase + Math.max(atk * LIMITS.meleeMul, spellBase * LIMITS.spellMul));
}
const owners={'Тенеград':'Нейтралы','Златобашня':'Орден Золотого Льва','Порт Заката':'Вольный Порт','Ледяной Приют':'Легион Стали','Крепость Железный Горн':'Легион Стали','Святоград':'Церковь Света','Ветроград':'Нейтралы','Сильвандрия':'Круг Друидов','Звёздная Башня':'Гильдия Магов','Лунная Роща':'Круг Друидов','Солнечный Чертог':'Церковь Света','Каменная Твердь':'Братство Камня','Искрящийся Горн':'Гильдия Инженеров','Рунный Зал':'Гильдия Инженеров','Пивная Крепость':'Вольный Порт','Мёртвый Шпиль':'Круг Некромантов','Теневая Гавань':'Братство Тени','Бездонная Цитадель':'Легион Хаоса','Город Проклятых':'Легион Хаоса','Призрачный Город':'Нейтралы','Парящий Монастырь':'Церковь Света','Караван-Град':'Вольный Порт','Подводное Царство':'Глубинный Орден','Небесный Город':'Орден Феникса','Город-Лабиринт':'Глубинный Орден','Город Вне Времени':'Нейтралы'};
const seedCity=n=>[...n].reduce((a,c)=>(Math.imul(a,31)+c.charCodeAt(0))>>>0,7);
const pair=(a,b)=>[a,b].sort().join('|');
const resources=['food','ore','cloth'];
function newRealm(){return {day:0,owners:{...owners},relations:{},stock:Object.fromEntries(Object.keys(owners).map(c=>[c,{food:60,ore:60,cloth:60}])),caravans:[]};}
function tickRealm(r){r.day++;const names=Object.keys(r.owners);r.caravans=[];for(const c of names)for(const k of resources)r.stock[c][k]=Math.max(0,Math.min(100,r.stock[c][k]+(k===resources[seedCity(c)%3]?18:-7)));for(let i=0;i<names.length;i++){const a=names[i],b=names[(i+1)%names.length],k=resources[seedCity(a)%3];if(r.relations[pair(r.owners[a],r.owners[b])]<0)continue;const n=Math.min(8,r.stock[a][k],100-r.stock[b][k]);r.stock[a][k]-=n;r.stock[b][k]+=n;r.caravans.push(a+' → '+b+' : '+n+' '+k);}}
setInterval(()=>{for(const room of rooms.values()){tickRealm(room.realm);broadcast(room,'realm_state',room.realm);}},5760000);

const rid = () => crypto.randomUUID();
const clean = (s, n) => (typeof s==='string'?s:'').replace(/[\u0000-\u001f<>]/g, '').slice(0, n);
const num = (v, d = 0) => ((typeof v==='number'||(typeof v==='string'&&v.trim()!==''))&&Number.isFinite(Number(v)) ? Number(v) : d);

const pkt = (room, type, payload, sender = 'server') => JSON.stringify({ v: V, room: room.name, sender, type, payload, ts: Date.now() });
const sendTo = (p, room, type, payload, sender) => { if(p.ws.bufferedAmount>1024*1024){p.ws.terminate();return;} if (p.ws.readyState === 1) p.ws.send(pkt(room, type, payload, sender)); };
const broadcast = (room, type, payload, except = null, sender = 'server') => { for (const p of room.peers.values()) if (p !== except) sendTo(p, room, type, payload, sender); };

// Only a complete valid position report may refresh combat eligibility.
function combatSnapshot1641(p){
  return typeof p.zone==='string'&&/^(w|h(?:_[a-z0-9]{1,8})?|d[0-9]{1,7}(?:_[a-z0-9]{1,8})?)$/.test(p.zone)&&
    ['x','y','z'].every(k=>typeof p[k]==='number'&&Number.isFinite(p[k])&&Math.abs(p[k])<=1e6)&&
    typeof p.hp==='number'&&Number.isFinite(p.hp)&&p.hp>=0;
}
function updatePeerState1641(peer,p,now=Date.now()){
  const valid=combatSnapshot1641(p);
  // Partial non-combat updates (nick, reputation etc.) remain supported.
  // A malformed or incomplete combat update cannot alter the last known combat position.
  if(!valid){
    const partial={...p};
    for(const k of ['x','y','z','zone','inDungeon','hp'])delete partial[k];
    if(['x','y','z','zone','inDungeon','hp'].some(k=>Object.hasOwn(p,k)))peer.stateAt=0;
    peer.state=sanitizeState(partial,peer.state||{},peer);
  }else{peer.state=sanitizeState(p,peer.state||{},peer);peer.stateAt=now;}
}
function sanitizeState(p = {}, old = {}, peer = null) {
  const s = { ...old }, isAdmin = !!(peer && peer.admin);
  for (const k of ['x', 'y', 'z', 'yaw', 'hp', 'lvl', 'attack', 'int', 'critChance', 'skin']) if (k in p) s[k] = num(p[k], s[k] ?? 0);
  for (const k of ['nick', 'classId', 'className']) if (k in p) s[k] = clean(p[k], 24);
  if ('color' in p) s.color = num(p.color);
  if ('inDungeon' in p) s.inDungeon = !!p.inDungeon;
  if (typeof p.zone==='string' && /^(w|h(?:_[a-z0-9]{1,8})?|d[0-9]{1,7}(?:_[a-z0-9]{1,8})?)$/.test(p.zone)) s.zone=p.zone;
  if (!isAdmin) {                                    // заявленные клиентом числа ограничиваем
    s.lvl = Math.max(1, Math.min(LIMITS.maxLvl, Math.floor(s.lvl ?? 1)));
    s.attack = Math.max(0, Math.min(LIMITS.atkBase + s.lvl * LIMITS.atkPerLvl, s.attack ?? 0));
    s.int = Math.max(0, Math.min(50 + s.lvl * 5, s.int ?? 10));
    s.hp = Math.max(0, Math.min(1e6, s.hp ?? 0));
    s.critChance = Math.max(0, Math.min(.75, s.critChance ?? 0));
  }
  if (p.reputation && typeof p.reputation === 'object' && !Array.isArray(p.reputation)) {
    const prev = old.reputation || {}, bucket = peer && peer.repBucket, next = Object.assign(Object.create(null),prev);
    if (bucket) refill(bucket);
    for (const [k, v] of Object.entries(p.reputation).slice(0, 20)) {
      const key = clean(k, 60); if(!Object.values(owners).includes(key))continue; let val = Math.max(-3000, Math.min(3000, num(v)));
      if (prev && !isAdmin && bucket) {              // после первого отчёта репутация растёт не быстрее лимита
        const was = prev[key] ?? 0;
        if (val > was) { const allowed = Math.min(val - was, Math.floor(bucket.t)); bucket.t -= allowed; val = was + allowed; }
      }
      next[key] = val;
    }
    s.reputation = next;
  }
  if(Array.isArray(p.quests))s.quests=p.quests.slice(0,100).filter(q=>q&&typeof q==='object'&&!Array.isArray(q)).map(q=>({id:clean(q.id,80),done:!!q.done,stage:num(q.stage)}));
  return s;
}
// Reject malformed entities and keep authoritative health across host snapshots.
function netMobProfile1635(e){
  const allowed=['claw','slam','venom','frost','fire','shadow','lightning','roar'];
  const level=Number.isSafeInteger(e.level)&&e.level>0?e.level:1;
  const skills=Array.isArray(e.skills)?[...new Set(e.skills.filter(k=>allowed.includes(k)))].slice(0,e.boss?3:2):[];
  const affinity=['fire','frost','storm','shadow','venom'].includes(e.affinity)?e.affinity:null;
  return {level,skills,affinity};
}
function sanitizeEntities(list) {
  if (!Array.isArray(list)) return [];
  const result=new Map(), finite=(n,min,max)=>typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max;
  for(const e of list.slice(0,150)){
    if(!e||typeof e.id!=='string'||!e.id||e.id.length>40||result.has(e.id)||![e.x,e.y,e.z].every(n=>finite(n,-1e6,1e6))||!finite(e.maxHp,1,1e6)||!finite(e.hp,0,e.maxHp)||!finite(e.atk,0,1e5))continue;
    result.set(e.id,{...netMobProfile1635(e),id:e.id,name:clean(e.name,60),x:e.x,y:e.y,z:e.z,hp:e.hp,maxHp:e.maxHp,atk:e.atk,boss:!!e.boss,dungeon:!!e.dungeon,shape:clean(e.shape,20),color:Math.max(0,Math.min(0xffffff,num(e.color,0x777777))),scale:Math.max(.1,Math.min(20,num(e.scale,1)))});
  }return [...result.values()];
}
function markKilled(room,id,now=Date.now()){
  room.killed.set(id,now+600000);
  // Bound tombstone memory; genuinely new spawns have fresh ids.
  if(room.killed.size>20000)room.killed.delete(room.killed.keys().next().value);
}
function mergeWorld(room,list,now=Date.now()){
  if(!Array.isArray(list))return false;
  const valid=sanitizeEntities(list);if(list.length&&!valid.length)return false;
  for(const [id,until] of room.killed)if(until<=now)room.killed.delete(id);
  const next=new Map();for(const e of valid){if(e.dungeon||e.hp<=0||room.killed.has(e.id))continue;
    const old=room.entities.get(e.id);if(old){e.hp=Math.min(old.hp,e.hp);e.maxHp=old.maxHp;e.atk=old.atk;e.level=old.level;e.skills=old.skills;e.affinity=old.affinity;e.boss=old.boss;e.name=old.name;e.shape=old.shape;e.color=old.color;e.scale=old.scale;e.stunUntil=old.stunUntil||0;e.interruptReady=old.interruptReady||0;e.hp=Math.min(e.hp,e.maxHp);}
    if(e.hp>0)next.set(e.id,e);
  }room.entities=next;return true;
}
function leave(peer) {
  const room = peer.room; if (!room || !room.peers.delete(peer.id)) return;
  broadcast(room, 'leave', {}, null, peer.id);
  if (room.hostId === peer.id) {
    const next = room.peers.values().next().value;
    room.hostId = next ? next.id : null;
    room.worldAt=0; cancelMobCasts1639(room);
    if (next) broadcast(room, 'host_changed', { hostId: next.id });
  }
  if (!room.peers.size) rooms.delete(room.name);
}
function join(ws, roomName) {
  let room = rooms.get(roomName);
  if (!room&&rooms.size>=128){ws.close(1013,'Room limit');return null;}
  if (!room) { room = { name: roomName, peers: new Map(), hostId: null, entities: new Map(), killed:new Map(), zone: 'w', worldReady: false, realm:newRealm() }; rooms.set(roomName, room); }
  if (room.peers.size >= MAX_PLAYERS) { ws.send(pkt(room, 'system', { text: 'Комната заполнена (' + MAX_PLAYERS + ').' })); ws.close(); return null; }
  const peer = { id: rid(), ws, room, nick: 'Искатель', state: null, ip: ws.ip || '?', admin: false,
    hitBucket: makeBucket(30, 30), dmgBucket: makeBucket(0, 0, Infinity), chatBucket: makeBucket(5, 0.5),
    repBucket: makeBucket(LIMITS.repBurst, LIMITS.repPerMin / 60) };
  room.peers.set(peer.id, peer);
  if (!room.hostId) room.hostId = peer.id;
  sendTo(peer, room, 'welcome', {
    id: peer.id, isHost: room.hostId === peer.id, worldReady: room.worldReady, zone: room.zone, maxPlayers: MAX_PLAYERS,
    entities: [...room.entities.values()],
    peers: [...room.peers.values()].filter(p => p !== peer && p.state).map(p => ({ id: p.id, state: p.state })),
  });
  sendTo(peer,room,'realm_state',room.realm);
  return peer;
}
// Apply the same elemental affinity rules as solo combat, using the server mob profile.
function elementalDamage1636(e, damage, tags) {
  const elements={fire:['fire'],frost:['ice'],storm:['storm'],shadow:['shadow','death','curses'],venom:['poison']};
  const opposite={fire:'frost',frost:'fire',storm:'shadow',shadow:'storm',venom:'fire'};
  if(!Object.hasOwn(elements,e.affinity)||!Array.isArray(tags)||!(damage>0))return damage;
  const valid=tags.slice(0,16).filter(t=>typeof t==='string');
  const resist=elements[e.affinity].some(t=>valid.includes(t));
  const weak=elements[opposite[e.affinity]].some(t=>valid.includes(t));
  return Math.max(1,Math.round(damage*(resist===weak?1:resist?.75:1.2)));
}
function attack(room, peer, p) {
  if(typeof p.targetId!=='string')return;const e = room.entities.get(p.targetId); if (!e || !peer.state || peer.state.zone!=='w' || e.dungeon) return;
  const now=Date.now();
  if(!room.worldReady||now-(room.worldAt||0)>3000||now-(peer.stateAt||0)>2000||typeof p.damage!=='number'||!Number.isFinite(p.damage)||p.damage<=0)return;
  if (!take(peer.hitBucket)) return;                                          // не больше 30 ударов в секунду (хватает на AoE)
  if (!(peer.state.hp>0)||![peer.state.x,peer.state.y,peer.state.z].every(Number.isFinite)||Math.hypot(peer.state.x - e.x,peer.state.y-e.y, peer.state.z - e.z) > 20) return;       // слишком далеко
  const cap = peer.admin ? LIMITS.adminHit : Math.min(LIMITS.adminHit, maxHit(peer));
  let damage = Math.max(1, Math.min(cap, Math.round(num(p.damage, peer.state.attack || 10))));
  damage = Math.min(cap, elementalDamage1636(e, damage, p.tags));
  if (!peer.admin) {                                                          // бюджет урона: ~5 «максимальных ударов» в секунду
    const b = peer.dmgBucket; b.cap = cap * 10; b.perSec = cap * 5; refill(b);
    damage = Math.min(damage, Math.floor(b.t)); if (damage < 1) return; b.t -= damage;
  }
  e.hp -= damage;
  // Client reports the existing lightning control effect; server bounds duration and frequency.
  let stun=0;
  if(e.hp>0&&p.interrupt===true&&now>=(e.interruptReady||0)){
    stun=e.boss?.25:.45;e.stunUntil=now+Math.round(stun*1000);e.interruptReady=now+5000;
    const cast=room.mobCasts?.get(e.id);
    if(cast?.key){broadcast(room,'mob_cancel',{id:e.id,key:cast.key,castId:cast.castId});room.mobCasts.set(e.id,{ready:Math.max(cast.ready,e.stunUntil)});}
  }
  broadcast(room, 'enemy_hit', { id: e.id, hp: Math.max(0, e.hp), damage, stun, crit: /Крит/.test(typeof p.verb==='string'?p.verb:''), attackerNick: peer.nick });
  if (e.hp <= 0) {
    room.entities.delete(e.id);markKilled(room,e.id);
    broadcast(room, 'enemy_killed', { id: e.id, name: e.name, killerId: peer.id,
      xp: Math.round((e.boss ? 200 : 15)*(1+Math.max(0,e.level-1)*.035)), gold: e.boss ? 40 + Math.floor(Math.random() * 60) : 2 + Math.floor(Math.random() * 6) });
  }
}
function handle(peer, msg) {
  const room = peer.room, p = msg.payload && typeof msg.payload === 'object' && !Array.isArray(msg.payload) ? msg.payload : {};
  switch (msg.type) {
    case 'hello': case 'state':
      updatePeerState1641(peer,p); peer.nick = peer.state.nick || peer.nick;
      broadcast(room, msg.type, peer.state, peer, peer.id); break;
    case 'world_init': case 'world_sync': {
      if (peer.id !== room.hostId || p.zone!=='w' || peer.state?.zone!=='w'||Date.now()-(peer.stateAt||0)>2000) return;
      if(!mergeWorld(room,p.entities))return;room.zone = 'w'; room.worldReady = true; room.worldAt=Date.now();
      broadcast(room, 'world_state', { zone: room.zone, entities: [...room.entities.values()] }, peer); break; }
    case 'realm_action': {
      const r=room.realm, factions=Object.values(owners), rep=peer.state?.reputation||{};
      if(p.kind==='buy'&&typeof p.city==='string'&&Object.hasOwn(r.stock,p.city)&&resources.includes(p.resource)&&r.stock[p.city][p.resource]>0&&peer.state?.hp>0)r.stock[p.city][p.resource]--;
      else if(p.kind==='relation'&&factions.includes(p.a)&&factions.includes(p.b)&&p.a!==p.b&&[1,-1].includes(p.value)&&rep[p.a]>=500)r.relations[pair(p.a,p.b)]=p.value;
      else if(p.kind==='capture'&&typeof p.city==='string'&&Object.hasOwn(r.owners,p.city)&&factions.includes(p.a)&&rep[p.a]>=1500&&r.relations[pair(p.a,r.owners[p.city])]===-1)r.owners[p.city]=p.a;
      else return;
      broadcast(room,'realm_state',r);break;}
    case 'action':
      if (p.action === 'attack') attack(room, peer, p);
      else if (p.action === 'cast' && peer.state?.hp>0 && take(peer.hitBucket)) broadcast(room, 'action', { action: 'cast', fx: clean(p.fx, 16) }, peer, peer.id);
      break;
    case 'chat':
      if (!take(peer.chatBucket)) { sendTo(peer, room, 'system', { text: 'Слишком часто. Подождите пару секунд.' }); break; }
      broadcast(room, 'chat', { nick: peer.nick, text: clean(p.text, 120) }, peer, peer.id); break;
    case 'admin_auth': {
      if (!ADMIN_HASH) { sendTo(peer, room, 'admin_result', { ok: false, reason: 'disabled' }); break; }
      const rec = ipFails.get(peer.ip) || { n: 0, until: 0 };
      if (Date.now() < rec.until) { sendTo(peer, room, 'admin_result', { ok: false, reason: 'locked', retry: Math.ceil((rec.until - Date.now()) / 1000) }); break; }
      if (checkPassword(p.password)) { peer.admin = true; ipFails.delete(peer.ip); sendTo(peer, room, 'admin_result', { ok: true }); console.log('[admin] вход: ' + peer.nick + ' (' + peer.ip + ')'); }
      else { if (++rec.n >= 5) { rec.until = Date.now() + 300000; rec.n = 0; } rec.expires=Date.now()+600000;if(ipFails.size>=4096&&!ipFails.has(peer.ip))ipFails.delete(ipFails.keys().next().value);ipFails.set(peer.ip, rec); sendTo(peer, room, 'admin_result', { ok: false, reason: 'bad' }); console.log('[admin] неверный пароль от ' + peer.ip); }
      break; }
    case 'admin_logout': peer.admin = false;if(peer.state)peer.state=sanitizeState({},peer.state,peer);break;
    case 'admin_cmd': {
      if (!peer.admin) { sendTo(peer, room, 'system', { text: 'Нет доступа: админ-режим не подтверждён сервером.' }); break; }
      if (!peer.adminCmdBucket) peer.adminCmdBucket=makeBucket(5,1);
      if (!take(peer.adminCmdBucket)) break;
      if(p.cmd==='players'){sendTo(peer,room,'system',{text:[...room.peers.values()].map(q=>q.nick+' ['+q.id+']').join(' · ')});break;}
      if(p.cmd==='announce'&&typeof p.value==='string'&&p.value.trim()&&p.value.length<=120){broadcast(room,'system',{text:'Администратор: '+clean(p.value,120)});console.log('[admin] announce '+peer.id);break;}
      if(p.cmd==='kick'&&typeof p.value==='string'){const target=room.peers.get(p.value);if(target&&target!==peer){console.log('[admin] kick '+peer.id+' → '+target.id);target.ws.close(1008,'Removed by room administrator');}else sendTo(peer,room,'system',{text:'Игрок не найден или выбран собственный ID.'});break;}
      if (p.cmd === 'killall') {
        let k = 0;
        for (const e of [...room.entities.values()]) { if (e.dungeon) continue; room.entities.delete(e.id);markKilled(room,e.id); k++; broadcast(room, 'enemy_killed', { id: e.id, name: e.name, killerId: null, xp: 0, gold: 0 }); }
        sendTo(peer, room, 'system', { text: 'Админ: убито существ в мире — ' + k + '.' });
        console.log('[admin] killall от ' + peer.nick + ': ' + k);
      }
      break; }
    case 'leave': peer.ws.close(); break;
  }
}

const NET_SKILLS1637={
    claw:{name:'Разрывающий удар',color:0xe6a16b,range:2.8,radius:2.8,wind:.85,cd:7,mul:1.45,kind:'melee'},
    slam:{name:'Сотрясение земли',color:0xdb9548,range:4,radius:3.8,wind:1.15,cd:9,mul:1.6,kind:'self'},
    venom:{name:'Ядовитый плевок',color:0x93df42,range:9,radius:2.2,wind:1,cd:8,mul:1.35,kind:'target'},
    frost:{name:'Ледяной взрыв',color:0x86ddff,range:10,radius:2.6,wind:1.25,cd:10,mul:1.5,kind:'target'},
    fire:{name:'Огненный взрыв',color:0xff632e,range:11,radius:3,wind:1.3,cd:10,mul:1.65,kind:'target'},
    shadow:{name:'Теневой разлом',color:0xb47aff,range:10,radius:2.5,wind:1.15,cd:9,mul:1.5,kind:'target'},
    lightning:{name:'Грозовой разряд',color:0xb4caff,range:11,radius:2.2,wind:1,cd:9,mul:1.55,kind:'target'},
    roar:{name:'Сокрушительный рёв',color:0xffba60,range:4,radius:4,wind:1.1,cd:11,mul:1.4,kind:'self'}
  };
  
function cancelMobCasts1639(room){
  if(!room.mobCasts)return;
  for(const [id,c] of room.mobCasts)if(c.key)broadcast(room,'mob_cancel',{id,key:c.key,castId:c.castId});
  room.mobCasts.clear();
}
// Fixed area and server clock; no client cast requests.
function tickMobAttacks1637(room,now=Date.now(),rng=Math.random){
  const casts=room.mobCasts||(room.mobCasts=new Map());
  for(const [id,c] of casts)if(!room.entities.has(id)||room.entities.get(id).hp<=0){if(c.key)broadcast(room,'mob_cancel',{id,key:c.key,castId:c.castId});casts.delete(id);}
  const host=room.peers.get(room.hostId);
  if(!room.worldReady||host?.state?.zone!=='w'||now-(host.stateAt||0)>2000||now-(room.worldAt||0)>3000){cancelMobCasts1639(room);return;}
  const players=[...room.peers.values()].filter(p=>p.state?.zone==='w'&&p.state.hp>0&&now-(p.stateAt||0)<=2000&&[p.state.x,p.state.y,p.state.z].every(Number.isFinite));
  const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
  for(const e of room.entities.values()){
    if(e.hp<=0||e.dungeon||!e.skills?.length||now<(e.stunUntil||0))continue;
    let c=casts.get(e.id);
    if(c?.key){
      // Only players who could receive the warning and remained combat-eligible may be hit.
      const active=new Set(players.map(p=>p.id));
      if(c.warned)for(const id of c.warned)if(!active.has(id))c.warned.delete(id);
      if(now<c.until)continue;
      const a=NET_SKILLS1637[c.key];
      broadcast(room,'mob_impact',{id:e.id,key:c.key,castId:c.castId,center:c.center});
      for(const p of players)if(c.warned?.has(p.id)&&Math.abs(p.state.y-c.center.y)<2.8&&distance(p.state,c.center)<=a.radius){
        const phase=e.boss?(e.hp/e.maxHp<=.25?1.92:e.hp/e.maxHp<=.5?1.6:1):1;
        sendTo(p,room,'mob_damage',{id:e.id,key:c.key,castId:c.castId,damage:Math.max(1,Math.round(e.atk*a.mul*phase))});
      }
      casts.set(e.id,{ready:c.ready});continue;
    }
    if(!c){casts.set(e.id,{ready:now+2000+Math.floor(rng()*4000)});continue;}
    if(now<c.ready)continue;
    let target=null,nearest=Infinity;
    for(const p of players){if(Math.abs(p.state.y-e.y)>=2.8)continue;const d=distance(p.state,e);if(d<nearest){target=p;nearest=d;}}
    if(!target)continue;
    const keys=(e.skills||[]).filter(k=>Object.hasOwn(NET_SKILLS1637,k)&&nearest<=NET_SKILLS1637[k].range);
    if(!keys.length)continue;
    const key=keys[Math.floor(rng()*keys.length)],a=NET_SKILLS1637[key],pos=a.kind==='target'?target.state:e;
    const center={x:pos.x,y:pos.y,z:pos.z},until=now+Math.round(a.wind*1000),phase=e.boss?(e.hp/e.maxHp<=.25?.65:e.hp/e.maxHp<=.5?.8:1):1;
    c={key,center,until,ready:until+Math.round(a.cd*phase*1000),castId:rid(),warned:new Set(players.map(p=>p.id))};casts.set(e.id,c);
    broadcast(room,'mob_warning',{id:e.id,key,center,castId:c.castId,wind:a.wind});
  }
}
setInterval(()=>{for(const room of rooms.values())tickMobAttacks1637(room);},20);


const wss = new WebSocketServer({ port: PORT, maxPayload: 256 * 1024 });
wss.on('error', err => { console.error('Coop server failed: '+err.message); process.exit(1); });
wss.on('connection', (ws, req) => {
  if(wss.clients.size>512){ws.close(1013,'Connection limit');return;}
  ws.ip = (req && req.socket && req.socket.remoteAddress) || '?'; ws.bucket = makeBucket(100, 50); ws.dropped = 0;
  let peer = null;const handshake=setTimeout(()=>{if(!peer)ws.terminate();},15000); ws.isAlive = true; ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', raw => {
    if (!take(ws.bucket)) { if (++ws.dropped > 300) ws.terminate(); return; }   // лимит сообщений на соединение
    ws.dropped = 0;
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    if (!msg || msg.v !== V || typeof msg.type !== 'string') return;
    try{if (!peer) {
      if(msg.type !== 'hello') return;
      const roomName = clean(msg.room, 24).replace(/[^\w-]/g, ''); if (!roomName) return;
      peer = join(ws, roomName); if (!peer) return;clearTimeout(handshake);
    }
    handle(peer, msg);}catch(e){console.warn('Rejected packet',e.message);ws.close(1008,'Invalid packet');}
  });
  ws.on('close', () => {clearTimeout(handshake); if (peer) leave(peer); });
  ws.on('error', () => {});
});
setInterval(() => {for(const [ip,r] of ipFails)if(r.expires<Date.now())ipFails.delete(ip); for (const ws of wss.clients) { if (!ws.isAlive) { ws.terminate(); continue; } ws.isAlive = false; ws.ping(); } }, 30000);
wss.once('listening', () => {
console.log('Сервер кооператива запущен: ws://localhost:' + PORT + '  (для других игроков — ws://<IP этого компьютера>:' + PORT + ')');
console.log(ADMIN_HASH ? 'Админ-режим: включён (пароль из ADMIN_PASSWORD).' : 'Админ-режим: ВЫКЛЮЧЕН — задайте ADMIN_PASSWORD, чтобы включить.');

});
